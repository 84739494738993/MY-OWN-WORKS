# Raspberry Pi: ready-made modules for sensors

Every device from the old `for_rasbery_py.py` is now a separate file with simple commands.
The libraries are already connected inside, so you don't have to write anything from scratch:

```python
import led
led.on(17)          # the LED on GPIO17 lights up
led.pins()          # how to wire it
led.help()          # all LED commands
```

## How to use it

1. Copy the **whole folder** `raspberry_pi` to the Raspberry Pi, for example with a flash drive or like this:
   `scp -r raspberry_pi pi@raspberrypi.local:~/`
2. Put your own programs **in the same folder**, next to `led.py`, `button.py` and so on —
   then `import led` works right away.
3. The first time on the board:
   - `python3 pi.py` — checks the board: are I2C/SPI on, which libraries and programs are missing;
   - if something is missing — `bash libs/pi_install/install_on_pi.sh` (installs what's missing and turns on I2C/SPI).
4. Run your program: `python3 my_program.py`.

## Main rules

- **Pin numbers are GPIO (BCM)**, like in the old code: `led.on(17)` is GPIO17 = physical pin 11.
  Map of all 40 pins: `pi.pinout()`.
- **`<module>.pins()`** prints the wiring diagram. If a contact can go anywhere it says
  "ANY GPIO", if only into a specific pin — "ONLY GPIO2 (phys. pin 3)".
- **`<module>.help()`** prints all commands of the module with explanations.
- A device on **one pin** — the pin comes first: `button.is_pressed(4)`, `servo.angle(18, 90)`.
- A device on **several pins** — call `connect(...)` once, then no pins: `distance.connect(23, 24)`,
  then `distance.cm()`. Without `connect` the pins from the old code are used.
- `start_...` and `on_...` commands run **in the background** and the program keeps going. When the program
  reaches its end while something runs in the background (blinking, watching a button, PWM brightness),
  it doesn't exit and waits for **Ctrl+C**.
- A simple switch-on (`led.on`, `rgb.color("red")`) stays on even after the program exits.
  Turn everything off at once: `pi.cleanup()`.
- Almost every `wait_...` has a `timeout` — the most seconds to wait. If nothing happened it returns `False` / `None`.

## Which file is which device

| In the old file | Module | Example |
|---|---|---|
| led | `led.py` | `led.on(17)` |
| rgb | `rgb.py` | `rgb.color("red")` |
| button | `button.py` | `button.is_pressed(4)` |
| button_2 | `touch.py` | `touch.is_touched(21)` |
| servo | `servo.py` | `servo.angle(18, 90)` |
| buzer | `buzzer.py` | `buzzer.play(23, "birthday")` |
| foto | `light.py` | `light.is_dark(24)` |
| potencyometr | `potentiometer.py` | `potentiometer.percent(25)` |
| ground | `soil.py` | `soil.is_dry(16)` |
| water | `water.py` | `water.is_water(20)` |
| ir_sensor | `ir_sensor.py` | `ir_sensor.is_obstacle(5)` |
| rfid, rfid_read, rfid_write | `rfid.py` | `rfid.read_id()`, `rfid.write("text")` |
| joystick | `joystick.py` + `adc.py` | `joystick.direction()` |
| motion_sensor | `motion.py` | `motion.is_motion(18)` |
| distance_sensor | `distance.py` | `distance.cm()` |
| led_8x8 | `matrix.py` | `matrix.text("Hello")` |
| lcd | `lcd.py` | `lcd.write("Hello")` |
| dht11 / dht22 | `dht11.py` / `dht22.py` | `dht11.temperature(4)` |
| time, time_colibrowka | `clock.py` | `clock.time_str()`, `clock.sync()` |
| ir_remote, ir_read, ir_send | `ir.py` | `ir.read_code()`, `ir.send("power")` |
| display | `display.py` | `display.text("HELLO!")` |
| dynamic (music, voice) | `speaker.py` | `speaker.say("Hello")` |
| dynamic (BMP280 + AHT20) | `weather.py` | `weather.show()` |
| nrf | `nrf.py` | `nrf.send("Hello")` |
| — | `pi.py` | `pi.pinout()`, `pi.check()`, `pi.i2c_scan()` |

Files starting with an underscore (`_core.py`, `_digital.py`, `_dht.py`) are the shared "insides" — you don't need to touch or import them.
`example.py` is a small example: a button turns an LED on and off.

## What's in `libs/`

- **Pure Python, works on any board:** `smbus2` (I2C), `mfrc522` (RFID), `gtts` + `requests` and their
  dependencies (Google voice).
- **`libs/fonts/`:** the DejaVu font with Cyrillic for the color display and a 5x8 font with Cyrillic for the matrix.
- **`libs/pi_binary/`:** `Pillow` (64-bit, Python 3.9–3.13) and `pyrf24` (32 and 64 bit, Python 3.9–3.13)
  built for the Raspberry Pi. They are used only if the board doesn't have its own.
- **`libs/pi_install/`:** the `RPi.GPIO` and `spidev` sources and the `install_on_pi.sh` script. Raspberry Pi OS
  usually has them already.

The modules themselves need no extra libraries: the MAX7219 matrix, the 1602 screen, the DS3231 clock,
BMP280/AHT20, the ADC, the distance sensor and DHT talk to the hardware directly over GPIO/I2C/SPI.

The modules create settings files next to themselves when you use them: `rfid_cards.json`
(remembered cards), `ir_codes.json` (remote buttons), `*_calibration.json` (sensor calibrations).

## If something doesn't work

- `python3 pi.py` — shows what's turned off or not installed.
- An I2C device doesn't answer — `pi.i2c_scan()` shows who is on the bus.
- **Raspberry Pi 5:** instead of RPi.GPIO it needs the `python3-rpi-lgpio` package (the install script installs it).
  On a Pi 5 a lit LED may go out when the program ends.
- **DHT11/DHT22** sometimes don't answer the first time — the module retries by itself. The most reliable
  way is the line `dtoverlay=dht11,gpiopin=4` in `/boot/firmware/config.txt` (details in `dht11.pins()`).

## All commands
The same thing is printed by `<module>.help()`. A pin is always a GPIO (BCM) number.

### LED — `led.py`
```python
import led
led.on(17)            # turn on the LED on GPIO17
led.blink(17, 5)      # blink 5 times
led.brightness(17, 30)  # brightness 30 %
```

| Command | What it does |
|---|---|
| `led.on(pin)` | Turn the LED on. |
| `led.off(pin)` | Turn the LED off (also stops blinking and smooth effects on this pin). |
| `led.toggle(pin)` | Toggle: if it was on it goes off, if it was off it goes on. |
| `led.is_on(pin)` | Is the LED on right now (True / False). |
| `led.on_for(pin, seconds)` | Turn on for seconds seconds, then off. |
| `led.blink(pin, times=3, speed=0.5)` | Blink times times. speed — how many seconds it's on and off. The program waits until the blinking ends. |
| `led.start_blink(pin, speed=0.5)` | Blink in the background non-stop while the program keeps going. Stop it: led.off(pin). |
| `led.brightness(pin, percent)` | Brightness from 0 to 100 %. Holds while the program runs (Ctrl+C — exit). |
| `led.get_brightness(pin)` | Current brightness 0..100 %. |
| `led.fade_in(pin, seconds=1.0)` | Fade in over seconds seconds. |
| `led.fade_out(pin, seconds=1.0)` | Fade out over seconds seconds. |
| `led.pulse(pin, times=3, speed=1.0)` | "Breathing": fade in and out times times. speed — seconds per breath. |
| `led.start_pulse(pin, speed=2.0)` | "Breathe" in the background non-stop. Stop it: led.off(pin). |
| `led.morse(pin, text, speed=0.15)` | Send text in Morse code (Latin, Cyrillic, digits). speed — length of a dot in seconds. |
| `led.pins(pin=None)` | Show how to wire the LED. |
| `led.help()` | Show all commands of this module. |

### RGB LED (any color mixed from red, green and blue) — `rgb.py`
```python
import rgb
rgb.color("red")          # or "lime", (255, 120, 0), "#FF7800"
rgb.rainbow(5)            # rainbow for 5 seconds
rgb.connect(5, 6, 13)     # if you didn't wire it to 17/27/22
```

| Command | What it does |
|---|---|
| `rgb.connect(red=17, green=27, blue=22, common_anode=False)` | Set the R, G, B pins. common_anode=True — if the common leg goes to 3.3 V, not to GND. |
| `rgb.color(r, g=None, b=None)` | Light a color: rgb.color("red"), rgb.color(255, 100, 0), rgb.color("#FF6400"). |
| `rgb.on(c='white')` | Turn on (white by default). |
| `rgb.off()` | Turn off (and stop blinking / rainbow). |
| `rgb.get_color()` | Which color is lit right now: (R, G, B). |
| `rgb.brightness(percent)` | Overall brightness 0..100 % for all colors. |
| `rgb.blink(c='red', times=3, speed=0.5)` | Blink color c times times. |
| `rgb.start_blink(c='red', speed=0.5)` | Blink in the background non-stop. Stop it: rgb.off(). |
| `rgb.fade(c, seconds=1.0)` | Smoothly change from the current color to color c over seconds seconds. |
| `rgb.rainbow(seconds=5, speed=2.0)` | Cycle through all colors for seconds seconds. speed — seconds per rainbow cycle. |
| `rgb.start_rainbow(speed=2.0)` | Rainbow in the background non-stop. Stop it: rgb.off(). |
| `rgb.random_color()` | Light a random bright color. Returns (R, G, B). |
| `rgb.police(times=5, speed=0.15)` | Police lights: red-blue. |
| `rgb.colors()` | Show all color names. |
| `rgb.pins()` | Show how to wire the RGB LED. |
| `rgb.help()` | Show all commands of this module. |

### Button — `button.py`
```python
import button
if button.is_pressed(4): print("pressed")
button.wait_press(4)                  # wait for a press
button.on_press(4, lambda: led.toggle(17))   # what to do on every press
```

| Command | What it does |
|---|---|
| `button.setup(pin, to='gnd')` | How the button is wired: to="gnd" (default) or to="3.3v" (the second leg goes to 3.3 V). |
| `button.is_pressed(pin)` | Is the button pressed right now (True / False). |
| `button.wait_press(pin, timeout=None)` | Wait for a press. timeout — the most seconds to wait. Returns True, or False (didn't happen). |
| `button.wait_release(pin, timeout=None)` | Wait until the button is released. |
| `button.wait_click(pin, timeout=None)` | Wait for a full click: pressed and released. |
| `button.on_press(pin, func)` | Call func() on every press (the program keeps going meanwhile). func=None — stop. |
| `button.on_release(pin, func)` | Call func() every time the button is released. |
| `button.on_hold(pin, func, seconds=1.0)` | Call func() if the button is held longer than seconds seconds (long press). |
| `button.stop(pin)` | Stop watching the button (cancels on_press / on_release / on_hold). |
| `button.hold_time(pin, timeout=None)` | Wait for a press and return how many seconds the button was held. |
| `button.clicks(pin, gap=0.4, timeout=None)` | Wait for a series of clicks and return how many: 1 — single, 2 — double, 3 — triple... |
| `button.count(pin, seconds=5)` | Count how many times it was pressed within seconds seconds. |
| `button.toggled(pin)` | Toggle switch: every press flips the state. Returns True (on) or False (off). |
| `button.pins(pin=None)` | Show how to wire the button. |
| `button.help()` | Show all commands of this module. |

### TTP223 touch button (button_2 in the old code) — `touch.py`
```python
import touch
if touch.is_touched(21): print("touched")
touch.on_touch(21, lambda: led.toggle(17))
```

| Command | What it does |
|---|---|
| `touch.is_touched(pin)` | Is the sensor being touched right now (True / False). |
| `touch.wait_touch(pin, timeout=None)` | Wait for a touch. Returns True, or False (if the timeout ran out). |
| `touch.wait_release(pin, timeout=None)` | Wait until the finger is taken away. |
| `touch.on_touch(pin, func)` | Call func() on every touch. func=None — stop. |
| `touch.on_release(pin, func)` | Call func() when the finger is taken away. |
| `touch.on_hold(pin, func, seconds=1.0)` | Call func() if the finger is held longer than seconds seconds. |
| `touch.stop(pin)` | Stop watching the sensor. |
| `touch.hold_time(pin, timeout=None)` | Wait for a touch and return how many seconds the finger was held. |
| `touch.clicks(pin, gap=0.4, timeout=None)` | Wait for a series of touches and return how many (1, 2, 3...). |
| `touch.count(pin, seconds=5)` | How many times it was touched within seconds seconds. |
| `touch.toggled(pin)` | Touch switch: every touch flips True/False. |
| `touch.pins(pin=None)` | Show how to wire the touch button. |
| `touch.help()` | Show all commands of this module. |

### Servo (SG90, MG996R, etc.) — `servo.py`
```python
import servo
servo.angle(18, 90)      # turn to 90 degrees
servo.smooth(18, 0, 2)   # smoothly turn to 0 in 2 seconds
servo.spin(18, 50)       # for a 360° servo: spin at 50 % speed
```

| Command | What it does |
|---|---|
| `servo.setup(pin, min_ms=0.5, max_ms=2.5, max_angle=180)` | Set up the servo: pulse length for 0° and for the max angle. If the servo doesn't reach the ends — tune it. |
| `servo.angle(pin, degrees, wait=0.5)` | Turn to the angle degrees (0..180). wait — how many seconds to give the servo to get there. |
| `servo.get_angle(pin)` | The last angle set (or None if it hasn't turned yet). |
| `servo.center(pin)` | Turn to the middle (90°). |
| `servo.left(pin)` | Turn to the end position 0°. |
| `servo.right(pin)` | Turn to the end position 180°. |
| `servo.smooth(pin, degrees, seconds=1.0)` | Smoothly turn from the current angle to degrees over seconds seconds. |
| `servo.sweep(pin, times=1, seconds=1.0)` | Sweep 0° -> 180° -> 0° times times. seconds — time for one pass. |
| `servo.start_sweep(pin, seconds=1.0)` | Sweep back and forth in the background non-stop. Stop it: servo.stop(pin). |
| `servo.spin(pin, speed)` | For a 360° (continuous rotation) servo: speed from -100 (backward) to 100 (forward), 0 — stop. |
| `servo.stop(pin)` | Stop sending the signal: the servo relaxes and stops jittering (a 360° servo stops). |
| `servo.pins(pin=None)` | Show how to wire the servo. |
| `servo.help()` | Show all commands of this module. |

### Buzzer. An active one beeps by itself on 1, a passive one can play notes — `buzzer.py`
```python
import buzzer
buzzer.beep(23, 3)              # beep 3 times (active and passive)
buzzer.tone(23, 1000, 0.5)      # a 1000 Hz sound for half a second (passive)
buzzer.play(23, "birthday")     # play a melody (passive)
buzzer.play(23, "C5 D5 E5:2 R G5/2")   # your own notes
```

| Command | What it does |
|---|---|
| `buzzer.on(pin)` | Turn on (an active buzzer beeps until you turn it off). |
| `buzzer.off(pin)` | Turn the sound off (also stops a background siren/alarm). |
| `buzzer.beep(pin, times=1, length=0.15, pause=0.15, freq=None)` | Beep times times. freq — frequency for a passive buzzer (for example 2000), otherwise plain on/off. |
| `buzzer.tone(pin, freq, seconds=None)` | Passive buzzer: a sound of freq Hz. seconds=None — keeps sounding until you call buzzer.off(pin). |
| `buzzer.note_freq(name)` | Note frequency: note_freq("A4") -> 440.0. Also "C#5", "Eb4" or solfège "la4". |
| `buzzer.note(pin, name, seconds=0.3)` | Play one note: buzzer.note(23, "A4", 0.5). |
| `buzzer.play(pin, melody, tempo=160)` | Play a melody: a name (buzzer.melodies()) or a string of notes "C5 D5 E5:2 R G5/2". tempo — beats per minute. |
| `buzzer.melodies()` | Show the names of the built-in melodies. |
| `buzzer.siren(pin, times=2, seconds=1.0)` | Passive buzzer: an "up-down" siren times times. |
| `buzzer.alarm(pin, times=5, speed=0.1)` | Alarm: frequent short beeps (works with an active buzzer too). |
| `buzzer.start_alarm(pin, speed=0.3, freq=None)` | Beep in the background non-stop (the program keeps going). Stop it: buzzer.off(pin). |
| `buzzer.pins(pin=None)` | Show how to wire the buzzer. |
| `buzzer.help()` | Show all commands of this module. |

### Light sensor — photoresistor (foto in the old code) — `light.py`
```python
import light
if light.is_dark(24): led.on(17)
print(light.level(24))      # brightness 0..100 %
light.mode("rc")        # photoresistor + capacitor, like in the old code (default)
light.mode("digital")   # a module with a DO output (threshold set with the screw on the module)
light.mode("adc")       # a module with an AO output through an ADC (adc.py), the ADC channel number instead of a pin
```

| Command | What it does |
|---|---|
| `light.mode(m)` | Wiring mode: "rc" (default), "digital" or "adc". |
| `light.raw(pin)` | Raw value: rc — charge time in seconds, adc — number from the ADC, digital — 0 or 1. |
| `light.level(pin)` | Light level 0..100 % (100 — very bright). More accurate after light.calibrate(pin). |
| `light.set_threshold(pin, value)` | Set the "dark" threshold in raw() units. For example light.set_threshold(24, 0.02). |
| `light.is_dark(pin)` | Is it dark right now (True / False). |
| `light.is_light(pin)` | Is it bright right now (True / False). |
| `light.wait_dark(pin, timeout=None)` | Wait until it gets dark. Returns True, or False (time ran out). |
| `light.wait_light(pin, timeout=None)` | Wait until it gets bright. |
| `light.on_dark(pin, func)` | Call func() when it gets dark (the program keeps going). |
| `light.on_light(pin, func)` | Call func() when it gets bright. |
| `light.stop(pin)` | Stop watching (cancels on_dark / on_light). |
| `light.calibrate(pin)` | Tune the sensor to your room: measure "bright" and "dark". Saved to a file. |
| `light.pins(pin=None)` | Show how to wire the light sensor (for the current mode). |
| `light.help()` | Show all commands of this module. |

### Potentiometer (rotary knob, potencyometr in the old code) — `potentiometer.py`
```python
import potentiometer as pot
print(pot.percent(25))            # 0..100 %
servo.angle(18, pot.value(25, 0, 180))   # the knob controls a servo
pot.mode("rc")    # with a capacitor, like in the old code (default)
pot.mode("adc")   # through an ADC (adc.py), the ADC channel number instead of a pin (more accurate and faster)
```

| Command | What it does |
|---|---|
| `potentiometer.mode(m)` | Wiring mode: "rc" (default) or "adc". |
| `potentiometer.raw(pin)` | Raw value: rc — charge time in seconds, adc — number from the ADC. |
| `potentiometer.percent(pin)` | Knob position 0..100 %. |
| `potentiometer.value(pin, low=0, high=100)` | Knob position mapped to the range low..high. For example value(25, 0, 180) for a servo. |
| `potentiometer.wait_change(pin, step=5, timeout=None)` | Wait until the knob is turned by more than step %. Returns the new value (or None). |
| `potentiometer.on_change(pin, func, step=3)` | Call func(percent) every time the knob is turned by more than step %. |
| `potentiometer.stop(pin)` | Stop watching (cancels on_change). |
| `potentiometer.calibrate(pin)` | Remember the end positions of the knob. Saved to a file. |
| `potentiometer.pins(pin=None)` | Show how to wire the potentiometer (for the current mode). |
| `potentiometer.help()` | Show all commands of this module. |

### Soil moisture sensor (ground in the old code) — `soil.py`
```python
import soil
if soil.is_dry(16): print("Water the plant!")
print(soil.status(16))          # "dry" or "wet"
print(soil.moisture(0))         # moisture in % (only through an ADC, channel 0)
```

| Command | What it does |
|---|---|
| `soil.is_dry(pin)` | Is the soil dry? (True / False). The threshold is the screw on the module. |
| `soil.is_wet(pin)` | Is the soil wet? (True / False). |
| `soil.status(pin)` | The string "dry" or "wet". |
| `soil.wait_dry(pin, timeout=None)` | Wait until the soil dries out. Returns True, or False (time ran out). |
| `soil.wait_wet(pin, timeout=None)` | Wait until the soil is watered. |
| `soil.on_dry(pin, func)` | Call func() when the soil gets dry. |
| `soil.on_wet(pin, func)` | Call func() when the soil gets wet. |
| `soil.stop(pin)` | Stop watching (cancels on_dry / on_wet). |
| `soil.moisture(channel=0)` | Moisture 0..100 % through an ADC (the module's AO output -> ADC channel). More accurate after soil.calibrate(). |
| `soil.calibrate(channel=0)` | Tune moisture(): measure the sensor in the air (dry) and in a glass of water (wet). Saved to a file. |
| `soil.pins(pin=None)` | Show how to wire the soil sensor. |
| `soil.help()` | Show all commands of this module. |

### Water / rain sensor (water in the old code) — `water.py`
```python
import water
if water.is_water(20): print("Leak!")
water.on_water(20, lambda: buzzer.alarm(23))
print(water.level(0))        # level in % (only through an ADC, channel 0)
```

| Command | What it does |
|---|---|
| `water.is_water(pin)` | Is there water on the sensor (True / False). |
| `water.is_dry(pin)` | Is the sensor dry (no water)? |
| `water.wait_water(pin, timeout=None)` | Wait until water appears. Returns True, or False (time ran out). |
| `water.wait_dry(pin, timeout=None)` | Wait until the sensor dries. |
| `water.on_water(pin, func)` | Call func() when water appears (the program keeps going). |
| `water.on_dry(pin, func)` | Call func() when the water is gone. |
| `water.stop(pin)` | Stop watching (cancels on_water / on_dry). |
| `water.level(channel=0)` | How much water is on the sensor, 0..100 % (S/AO output -> ADC channel). |
| `water.pins(pin=None)` | Show how to wire the water sensor. |
| `water.help()` | Show all commands of this module. |

### IR obstacle sensor (FC-51, KY-032) or line sensor (TCRT5000) — `ir_sensor.py`
```python
import ir_sensor
if ir_sensor.is_obstacle(5): print("Obstacle ahead")
if ir_sensor.is_black(6): print("Black line under the sensor")
print(ir_sensor.count(5, 10))     # how many objects passed in 10 seconds
```

| Command | What it does |
|---|---|
| `ir_sensor.is_obstacle(pin)` | Is there an obstacle in front of the sensor (True / False). |
| `ir_sensor.is_clear(pin)` | Is the way ahead clear? |
| `ir_sensor.is_black(pin)` | Line sensor: is it black underneath (the beam isn't reflected)? |
| `ir_sensor.is_white(pin)` | Line sensor: is it white underneath (the beam is reflected)? |
| `ir_sensor.wait_obstacle(pin, timeout=None)` | Wait until an obstacle appears. Returns True, or False (time ran out). |
| `ir_sensor.wait_clear(pin, timeout=None)` | Wait until the obstacle goes away. |
| `ir_sensor.on_obstacle(pin, func)` | Call func() when an obstacle appears (the program keeps going). |
| `ir_sensor.on_clear(pin, func)` | Call func() when the obstacle goes away. |
| `ir_sensor.stop(pin)` | Stop watching (cancels on_obstacle / on_clear). |
| `ir_sensor.count(pin, seconds=10)` | Count how many times something appeared in front of the sensor within seconds seconds (object counter). |
| `ir_sensor.pins(pin=None)` | Show how to wire the IR sensor. |
| `ir_sensor.help()` | Show all commands of this module. |

### PIR motion sensor HC-SR501 (motion_sensor in the old code) — `motion.py`
```python
import motion
if motion.is_motion(18): print("Someone is here!")
motion.wait_motion(18)                 # wait for motion
motion.on_motion(18, lambda: led.on(17))
```

| Command | What it does |
|---|---|
| `motion.is_motion(pin)` | Is there motion right now (True / False). |
| `motion.wait_motion(pin, timeout=None)` | Wait for motion. Returns True, or False (the timeout ran out). |
| `motion.wait_still(pin, timeout=None)` | Wait until the motion ends. |
| `motion.on_motion(pin, func)` | Call func() every time motion starts (the program keeps going). func=None — stop. |
| `motion.on_still(pin, func)` | Call func() when the motion has ended. |
| `motion.stop(pin)` | Stop watching (cancels on_motion / on_still). |
| `motion.seconds_since_motion(pin)` | How many seconds have passed since the last detected motion (None — none yet). |
| `motion.warm_up(seconds=30)` | Wait for the sensor to "warm up" after power-on (for the first ~30 s it triggers by itself). |
| `motion.pins(pin=None)` | Show how to wire the motion sensor. |
| `motion.help()` | Show all commands of this module. |

### HC-SR04 ultrasonic distance sensor (distance_sensor in the old code) — `distance.py`
```python
import distance
print(distance.cm())             # distance in centimeters
if distance.is_closer(20): print("Too close!")
distance.connect(trig=5, echo=6) # if you didn't wire it to 23/24
```

| Command | What it does |
|---|---|
| `distance.connect(trig=23, echo=24)` | Set the TRIG and ECHO pins. |
| `distance.set_temperature(celsius)` | Take the air temperature into account (sound is faster when warm) — the distance gets more accurate. |
| `distance.cm(samples=3)` | Distance in centimeters (median of samples measurements). None — nothing found (beyond ~4 m or an error). |
| `distance.mm(samples=3)` | Distance in millimeters. |
| `distance.meters(samples=3)` | Distance in meters. |
| `distance.is_closer(limit_cm)` | Is an object closer than limit_cm centimeters? (True / False). |
| `distance.is_farther(limit_cm)` | Is the object farther than limit_cm centimeters (or is there nothing)? |
| `distance.wait_closer(limit_cm, timeout=None)` | Wait until something comes closer than limit_cm. Returns True, or False (time ran out). |
| `distance.wait_farther(limit_cm, timeout=None)` | Wait until the object moves farther than limit_cm. |
| `distance.on_closer(limit_cm, func)` | Call func() when something comes closer than limit_cm (the program keeps going). |
| `distance.on_farther(limit_cm, func)` | Call func() when the object moves farther than limit_cm. |
| `distance.stop()` | Stop watching (cancels on_closer / on_farther). |
| `distance.pins()` | Show how to wire the distance sensor. |
| `distance.help()` | Show all commands of this module. |

### ADC — turns a voltage of 0..3.3 V into a number. The Raspberry Pi has no ADC of its own, hence — `adc.py`
```python
import adc
print(adc.read(0))        # raw number from channel 0
print(adc.percent(0))     # 0..100 %
adc.connect("mcp3008")    # if you have a different chip
```

| Command | What it does |
|---|---|
| `adc.connect(chip='adc0832', cs=22, clk=23, do=24, di=25, address=None)` | Choose the chip and pins. ADC0832 with a single DIO wire: di=None (or di=do). |
| `adc.channels()` | How many channels the selected chip has. |
| `adc.max_value()` | The largest number the chip returns (255, 1023 ...). |
| `adc.read(channel=0)` | Raw value from a channel: from 0 to adc.max_value(). |
| `adc.percent(channel=0)` | Value in percent 0..100. |
| `adc.voltage(channel=0, vref=3.3)` | Voltage on the channel in volts. |
| `adc.pins()` | Show how to wire the selected ADC. |
| `adc.help()` | Show all commands of this module. |

### KY-023 joystick (two axes + button). The axes are analog, so an ADC is needed (adc.py) — `joystick.py`
```python
import joystick
print(joystick.x(), joystick.y())   # -100..100 on each axis
print(joystick.direction())         # "up", "down", "left", "right" or "center"
joystick.connect(button=17)         # if you connected the SW button
```

| Command | What it does |
|---|---|
| `joystick.connect(x=0, y=1, button=None, invert_x=False, invert_y=False, dead_zone=25)` | ADC channels for the X and Y axes, the SW button pin (if connected), axis inversion and the dead zone in %. |
| `joystick.calibrate()` | Remember the current position as the center (don't touch the joystick while calling it). |
| `joystick.x()` | Position on the X axis: -100 (left) .. 0 .. 100 (right). |
| `joystick.y()` | Position on the Y axis: -100 (up) .. 0 .. 100 (down). If it's the other way round — connect(invert_y=True). |
| `joystick.position()` | Both axes at once: (x, y). |
| `joystick.direction(arrows=False)` | Where it's tilted: "up", "down", "left", "right" or "center". arrows=True — "↑", "↓", "←", "→", "•". |
| `joystick.is_pressed()` | Is the joystick button pressed (connect SW and set connect(button=pin)). |
| `joystick.wait_press(timeout=None)` | Wait for the joystick button to be pressed. |
| `joystick.wait_move(timeout=None)` | Wait until the joystick is tilted. Returns the direction ("up"...) or None (time ran out). |
| `joystick.on_move(func)` | Call func(direction) every time the direction changes (except going back to the center). |
| `joystick.on_press(func)` | Call func() when the joystick button is pressed. |
| `joystick.stop()` | Stop watching (cancels on_move / on_press). |
| `joystick.pins()` | Show how to wire the joystick. |
| `joystick.help()` | Show all commands of this module. |

### RC522 RFID reader (13.56 MHz cards and key fobs) — `rfid.py`
```python
import rfid
print(rfid.read_id())          # wait for a card and return its number
rfid.write("Hello")            # write text to a card (up to 48 bytes)
print(rfid.read_text())        # read the text from a card
rfid.remember("Alice")         # remember a card under a name
print(rfid.who())              # whose card is this
```

| Command | What it does |
|---|---|
| `rfid.connect(rst=25, device=0)` | Set the RST pin and which CE SDA uses: device=0 (GPIO8) or 1 (GPIO7). |
| `rfid.check()` | Is there a card at the reader right now? Returns the card number or None (doesn't wait). |
| `rfid.read_id(timeout=None)` | Wait for a card and return its number. timeout — the most seconds to wait (otherwise returns None). |
| `rfid.read(timeout=None)` | Wait for a card and return (number, text). |
| `rfid.read_text(timeout=None)` | Wait for a card and return only its text. |
| `rfid.write(text, timeout=None)` | Wait for a card and write text to it (up to 48 bytes: ~48 Latin or ~24 Cyrillic letters). Returns the card number. |
| `rfid.wait_remove(timeout=None)` | Wait until the card is taken away from the reader. |
| `rfid.on_card(func)` | Call func(card_number) every time a card is brought up (the program keeps going). |
| `rfid.stop()` | Stop watching (cancels on_card). |
| `rfid.cards()` | All remembered cards: {number: name}. |
| `rfid.remember(name, timeout=None)` | Bring a card up — it is remembered under the name name (saved to rfid_cards.json). |
| `rfid.forget(name)` | Forget a card by name. |
| `rfid.name_of(card)` | Name of a remembered card by its number (or None). |
| `rfid.who(timeout=None)` | Wait for a card and return the owner's name (or None if the card is unknown / time ran out). |
| `rfid.is_known(card)` | Is the card remembered? (True / False). |
| `rfid.pins()` | Show how to wire the RC522. |
| `rfid.help()` | Show all commands of this module. |

### 8x8 LED matrix on MAX7219 (led_8x8 in the old code). Several matrices can be chained — `matrix.py`
```python
import matrix
matrix.show("smile")          # a picture (list: matrix.pictures())
matrix.text("Hello!")         # scrolling text (Cyrillic works too)
matrix.number(42)             # a number 0..99
matrix.pixel(3, 4)            # light up the dot x=3, y=4
matrix.connect(count=4, rotate=90)   # 4 matrices in a row (FC-16 module)
```

| Command | What it does |
|---|---|
| `matrix.connect(count=1, rotate=0, mirror=False, device=0)` | count — how many matrices are chained, rotate — rotation 0/90/180/270 (if the picture is rotated), mirror=True — if it's mirrored, device=1 — if CS is on GPIO7 (CE1). |
| `matrix.width()` | Screen width in dots (8 * number of matrices). |
| `matrix.update()` | Send the picture to the matrix (usually called automatically). |
| `matrix.clear()` | Turn off all dots (and stop the scrolling text / animation). |
| `matrix.fill()` | Light up all dots. |
| `matrix.pixel(x, y, on=True, show=True)` | Light up (on=True) or turn off a dot. x — column 0..7 (from the left), y — row 0..7 (from the top). |
| `matrix.get_pixel(x, y)` | Is the dot lit (True / False). |
| `matrix.show(picture, x=0)` | Show a picture: a name ("smile", "heart" ...) or 8 rows like "01100110". |
| `matrix.pictures()` | Show the names of the built-in pictures. |
| `matrix.letter(ch)` | Show one letter or digit in the center. |
| `matrix.number(n)` | Show a number from -9 to 99 in small digits. |
| `matrix.text(message, speed=0.08)` | Scrolling text (Latin, Cyrillic, digits). speed — seconds per step (less = faster). |
| `matrix.start_text(message, speed=0.08)` | Scrolling text in the background, in a loop. Stop it: matrix.clear(). |
| `matrix.brightness(level)` | Brightness from 0 to 15. |
| `matrix.invert()` | Swap lit and unlit dots. |
| `matrix.row(y, on=True)` | Light up (or turn off) a whole row y = 0..7. |
| `matrix.column(x, on=True)` | Light up (or turn off) a whole column x. |
| `matrix.line(x1, y1, x2, y2, on=True)` | Draw a line from (x1, y1) to (x2, y2). |
| `matrix.rect(x, y, w, h, filled=False, on=True)` | Rectangle: top left corner (x, y), width w, height h. filled=True — filled. |
| `matrix.animate(frames, speed=0.2, times=1)` | Show frames one after another: frames — a list of pictures (names or 8 rows). |
| `matrix.on()` | Turn the screen on (the picture comes back). |
| `matrix.off()` | Turn the screen off without erasing the picture. |
| `matrix.test(seconds=1.0)` | Test: light up all dots at full brightness for seconds seconds. |
| `matrix.pins()` | Show how to wire the matrix. |
| `matrix.help()` | Show all commands of this module. |

### 1602 (or 2004) screen with a PCF8574 I2C board — `lcd.py`
```python
import lcd
lcd.write("Hello!")               # to line 1 (Cyrillic letters are converted to Latin automatically)
lcd.write("t = 23.5°C", 2)        # to line 2
lcd.show("Line 1", "Line 2")      # clear and print both lines
lcd.scroll("A long scrolling line")
lcd.connect(cols=20, rows=4)      # for a 2004 screen
```

| Command | What it does |
|---|---|
| `lcd.connect(address=None, cols=16, rows=2)` | address — I2C address (usually 0x27 or 0x3F; None — find it automatically), screen size cols x rows. |
| `lcd.find()` | Find the screen on the I2C bus. Returns the address or None. |
| `lcd.move(col, line=1)` | Put the cursor in column col (from 0) of line line (from 1). |
| `lcd.write(text, line=1, col=0, clear_rest=True)` | Write text to line line (1.._rows) from position col. clear_rest — erase the old tail of the line. |
| `lcd.show(line1='', line2='', line3='', line4='')` | Clear the screen and print up to 4 lines. |
| `lcd.center(text, line=1)` | Write text centered in the line. |
| `lcd.clear()` | Clear the screen (and stop the scrolling line). |
| `lcd.clear_line(line=1)` | Clear one line. |
| `lcd.scroll(text, line=1, speed=0.3, times=1)` | Scrolling text in line line. speed — seconds per step. The program waits until it has scrolled through. |
| `lcd.start_scroll(text, line=1, speed=0.3)` | Scrolling text in the background, in a loop (the program keeps going). Stop it: lcd.clear(). |
| `lcd.backlight(on=True)` | Turn the backlight on / off. |
| `lcd.on()` | Turn the screen on (the text comes back). |
| `lcd.off()` | Turn the screen off without erasing the text (the backlight stays — turn it off with backlight(False)). |
| `lcd.cursor(show=True, blink=False)` | Show an underline cursor (show) and/or a blinking block (blink). |
| `lcd.create_char(slot, pattern)` | Your own symbol (up to 8, slot 0..7). pattern — 8 rows of 5 dots: ["01010", "11111", ...]. |
| `lcd.char(slot, col=0, line=1)` | Print your own symbol slot (made with create_char) at position col, line. |
| `lcd.pins()` | Show how to wire the screen. |
| `lcd.help()` | Show all commands of this module. |

### DHT11 temperature and humidity sensor (blue) — `dht11.py`
```python
import dht11
print(dht11.temperature(4))      # °C
print(dht11.humidity(4))         # %
t, h = dht11.read(4)             # everything at once
dht11.show(4)                    # print it nicely
```

| Command | What it does |
|---|---|
| `dht11.read(pin)` | Return (temperature °C, humidity %). If the sensor didn't answer — (None, None). |
| `dht11.temperature(pin)` | Temperature in °C (or None). |
| `dht11.humidity(pin)` | Air humidity in % (or None). |
| `dht11.show(pin)` | Print the temperature and humidity. |
| `dht11.pins(pin=None)` | Show how to wire the DHT11. |
| `dht11.help()` | Show all commands of this module. |

### DHT22 / AM2302 temperature and humidity sensor (white, more accurate than DHT11) — `dht22.py`
```python
import dht22
print(dht22.temperature(4))      # °C (with tenths, can be below zero)
print(dht22.humidity(4))         # %
t, h = dht22.read(4)             # everything at once
dht22.show(4)                    # print it nicely
```

| Command | What it does |
|---|---|
| `dht22.read(pin)` | Return (temperature °C, humidity %). If the sensor didn't answer — (None, None). |
| `dht22.temperature(pin)` | Temperature in °C (or None). |
| `dht22.humidity(pin)` | Air humidity in % (or None). |
| `dht22.show(pin)` | Print the temperature and humidity. |
| `dht22.pins(pin=None)` | Show how to wire the DHT22. |
| `dht22.help()` | Show all commands of this module. |

### DS3231 real-time clock (time and time_colibrowka in the old code). Keeps running without power — on its battery — `clock.py`
```python
import clock
print(clock.now())         # [year, month, day, hours, minutes, seconds]
print(clock.time_str())    # "14:05:09"
print(clock.date_str())    # "16.10.2026"
clock.sync()               # write the Raspberry's time into the clock (formerly time_colibrowka)
clock.wait_until(7, 30)    # alarm clock: wait until 7:30
```

| Command | What it does |
|---|---|
| `clock.now()` | Current date and time: [year, month, day, hours, minutes, seconds]. |
| `clock.datetime()` | Date and time as a datetime object (handy for computing differences). |
| `clock.time_str(seconds=True)` | Time as a string: "14:05:09" (seconds=False -> "14:05"). |
| `clock.date_str(words=False)` | Date as a string: "16.10.2026" (words=True -> "16 October 2026"). |
| `clock.year()` | Year. |
| `clock.month()` | Month 1..12. |
| `clock.day()` | Day of the month 1..31. |
| `clock.hour()` | Hours 0..23. |
| `clock.minute()` | Minutes 0..59. |
| `clock.second()` | Seconds 0..59. |
| `clock.weekday()` | Day of the week as a word: "Monday" ... "Sunday". |
| `clock.set(year, month, day, hour, minute, second=0)` | Set the time by hand: clock.set(2026, 10, 16, 14, 5, 0). |
| `clock.sync()` | Write the Raspberry Pi's current time into the module (formerly time_colibrowka). The Pi needs internet. |
| `clock.to_system()` | The other way round: set the Raspberry Pi's time from the DS3231 (when there's no internet). Needs sudo. |
| `clock.temperature()` | Temperature inside the DS3231 module (°C, 0.25 steps). |
| `clock.lost_power()` | True if the clock has stopped (dead battery) and the time must be set again. |
| `clock.show()` | Print the date, time and day of the week. |
| `clock.wait_until(hour, minute=0, second=0)` | Wait until the clock shows hour:minute (alarm clock). If that time has passed today — until tomorrow. |
| `clock.pins()` | Show how to wire the clock. |
| `clock.help()` | Show all commands of this module. |

### IR remote: receiving (VS1838B IR receiver) and sending (IR LED). ir_remote, ir_read, ir_send in the old code — `ir.py`
```python
import ir
print(ir.read_code())       # press a remote button -> "0x00FF30CF"
ir.learn("power")           # remember a remote button under a name
print(ir.wait_button())     # which remembered button was pressed -> "power"
ir.send("power")            # send a remembered signal (like the remote)
```

| Command | What it does |
|---|---|
| `ir.connect(receiver=None, sender=None)` | Set the devices by hand, for example ir.connect("/dev/lirc1", "/dev/lirc0"). Usually they are found automatically. |
| `ir.read_raw(timeout=None)` | Wait for a remote signal and return the "raw" signal: a list of durations in µs. None — nothing came. |
| `ir.decode_nec(sig)` | Decode a raw NEC signal (most Chinese remotes) -> "0x00FF30CF" or None. |
| `ir.read_code(timeout=None)` | Wait for a remote button press and return its code ("0x00FF30CF"). Repeats while held -> "REPEAT". |
| `ir.same(sig1, sig2, tolerance=0.25)` | Are two raw signals similar (True / False). Compares the first ~60 durations. |
| `ir.buttons()` | Names of all remembered buttons. |
| `ir.learn(name, timeout=None)` | Press a remote button — its signal is remembered under the name name (file ir_codes.json). |
| `ir.forget(name)` | Forget a button. |
| `ir.recognize(sig)` | Find the name of a remembered button by a raw signal (or None). |
| `ir.wait_button(timeout=None)` | Wait for any remembered button and return its name (or None if the time ran out). |
| `ir.on_button(func)` | Call func(button_name) on every press of a remembered button (the program keeps going). |
| `ir.stop()` | Stop listening to the remote (cancels on_button). |
| `ir.send(button, times=1)` | Send a signal: the name of a remembered button, or a raw signal (list / string "+9000 -4500 ..."). |
| `ir.send_nec(code, times=1)` | Send an NEC code, for example ir.send_nec("0x00FF30CF"). |
| `ir.pins()` | Show how to wire the IR receiver and IR LED. |
| `ir.help()` | Show all commands of this module. |

### ST7789 240x240 color display (SPI) — `display.py`
```python
import display
display.text("HELLO!")                    # text in the center (Cyrillic works too)
display.text("12:30", size=60, color="yellow")
display.image("/home/pi/picture.png")     # picture on the whole screen
display.fill("blue")                      # fill with a color
display.circle(120, 120, 50, "red")       # shapes: pixel, line, rect, circle
```

| Command | What it does |
|---|---|
| `display.connect(dc=25, rst=27, bl=23, device=0, width=240, height=240, rotate=3, invert=True, speed=40, spi_mode=3, x_offset=0, y_offset=0)` | Display settings. rotate 0..3 — rotation by 90° (text upside down? change it), invert=False — if colors look like a negative, speed — SPI speed in MHz (garbage on screen? lower it), spi_mode — SPI mode (screens without a CS pin need 3), bl=None — if the backlight isn't connected. |
| `display.size()` | Screen size (width, height) taking the rotation into account. |
| `display.reset()` | Do the "clean start" and setup again (like in the old code) and show the picture. Use it if the screen hangs, is white or black. |
| `display.update()` | Send the picture to the screen (usually called automatically after every command). |
| `display.auto_update(on=True)` | auto_update(False) — draw without showing, then call display.update() once (faster, no flicker). |
| `display.fonts()` | Show the fonts you can use in display.text(..., font="name"). Put your own .ttf files into libs/fonts. |
| `display.clear(color='black')` | Clear the screen (fill it with color, black by default). |
| `display.fill(color)` | Fill the whole screen with a color: "red", "#00FF00" or (0, 0, 255). |
| `display.text(message, x=None, y=None, size=30, color='white', bg='black', clear=True, bold=True, font=None, align='center')` | Write text. x, y = None — in the center. clear=True — clear the screen with color bg first. font — font name (list: display.fonts()), align — "left"/"center"/"right" for several lines. |
| `display.image(path, keep_ratio=False, bg='black')` | Show a picture from a file on the whole screen. keep_ratio=True — don't stretch (margins in color bg). |
| `display.pixel(x, y, color='white')` | A single pixel. |
| `display.line(x1, y1, x2, y2, color='white', width=2)` | A line from (x1, y1) to (x2, y2). |
| `display.rect(x, y, w, h, color='white', fill=True, width=2)` | Rectangle: top left corner (x, y), width w, height h. fill=False — outline only. |
| `display.circle(x, y, r, color='white', fill=True, width=2)` | Circle with center (x, y) and radius r. fill=False — outline only. |
| `display.bar(percent, y=200, height=24, color='lime', bg='gray')` | An indicator bar (progress, battery level, volume...) across the whole screen width. |
| `display.backlight(on=True)` | Turn the backlight on / off (needs BL connected). |
| `display.brightness(percent)` | Backlight brightness 0..100 % (PWM on the BL pin). Holds while the program runs. |
| `display.off()` | Turn the screen and backlight off (sleep); the picture is kept. |
| `display.on()` | Turn the screen back on after off(). |
| `display.canvas()` | For your own drawings with Pillow: img, draw = display.canvas(); draw.text(...); display.update(). |
| `display.save(path='screen.png')` | Save what's on the screen right now to a picture file. |
| `display.pins()` | Show how to wire the display. |
| `display.help()` | Show all commands of this module. |

### Speaker (dynamic in the old code): music, voice, sounds — `speaker.py`
```python
import speaker
speaker.play("elsa.mp3")                 # play a file (mp3, wav, ogg...)
speaker.play("elsa.mp3", wait=False)     # play in the background, the program keeps going
speaker.say("Hello, I am a Raspberry Pi")   # say it out loud (online voice; offline it uses espeak)
speaker.volume(70)                       # volume 70 %
speaker.set_device(None)                 # sound to the default device (not hw:1,0)
```

| Command | What it does |
|---|---|
| `speaker.set_device(name)` | Where the sound goes: "hw:1,0", "hw:0,0" ... or None — the default device. List: speaker.devices(). |
| `speaker.devices()` | Show the Raspberry Pi's sound devices (cards). |
| `speaker.play(path, wait=True)` | Play a file. wait=False — play in the background (stop it: speaker.stop()). |
| `speaker.stop()` | Stop the sound. |
| `speaker.is_playing()` | Is anything playing right now (True / False). |
| `speaker.wait()` | Wait until whatever was started with wait=False finishes. |
| `speaker.say(text, lang='en', wait=True)` | Say the text with the Google voice (needs internet). Without internet — the espeak voice. lang: "en", "ru"... |
| `speaker.say_offline(text, lang='en', wait=True)` | Say the text without internet (espeak-ng robot voice). Install: sudo apt install espeak-ng. |
| `speaker.tone(freq=440, seconds=0.5, wait=True)` | Play a pure tone of freq Hz (no file). |
| `speaker.beep()` | A short beep. |
| `speaker.volume(percent)` | Volume 0..100 % (through amixer). |
| `speaker.pins()` | Show how to connect the sound. |
| `speaker.help()` | Show all commands of this module. |

### Weather sensor: BMP280 + AHT20 board (pressure, temperature, humidity). From dynamic in the old code — `weather.py`
```python
import weather
print(weather.temperature())      # °C
print(weather.humidity())         # %
print(weather.pressure())         # hPa
print(weather.pressure_mm())      # mmHg
weather.show()                    # everything at once
```

| Command | What it does |
|---|---|
| `weather.connect(bmp_address=None, aht_address=56)` | Sensor addresses. BMP280 is usually 0x77 or 0x76 (None — find it automatically). |
| `weather.has_bmp()` | Is there a BMP280 pressure sensor. |
| `weather.has_aht()` | Is there an AHT20 humidity sensor. |
| `weather.temperature()` | Air temperature, °C. |
| `weather.humidity()` | Air humidity, % (needs the AHT20). |
| `weather.pressure()` | Atmospheric pressure, hPa (hectopascals; normal is about 1013). |
| `weather.pressure_mm()` | Atmospheric pressure, mm of mercury (normal is about 760). |
| `weather.altitude(sea_level=None)` | Approximate altitude above sea level, m (from the pressure). |
| `weather.read()` | Everything at once as a dict: {'temperature': .., 'humidity': .., 'pressure': .., 'pressure_mm': ..}. |
| `weather.show()` | Print everything the sensor can do. |
| `weather.phrase(lang='en')` | Ready-made sentence for the voice: speaker.say(weather.phrase()). |
| `weather.pins()` | Show how to wire the weather sensor. |
| `weather.help()` | Show all commands of this module. |

### nRF24L01 radio module (2.4 GHz) — messages with another Raspberry or an Arduino (RF24 library) — `nrf.py`
```python
import nrf
nrf.send("Hello")                 # send a message (up to 32 bytes)
print(nrf.receive())              # wait for a message and return the text
nrf.on_message(print)             # print everything that arrives (the program keeps going)
nrf.connect(address="00002", channel=90)   # another address / channel
```

| Command | What it does |
|---|---|
| `nrf.connect(ce=22, csn=0, channel=76, address='00001', power='low', speed='1mbps', dynamic=True)` | Radio settings. They must match the other side (Arduino): address — 5 characters, channel 0..125, power "min"/"low"/"high"/"max", speed "250kbps"/"1mbps"/"2mbps", dynamic=True — like radio.enableDynamicPayloads() on Arduino. csn=0 — pin CE0 (GPIO8), 1 — CE1 (GPIO7). |
| `nrf.is_connected()` | Is the module connected and answering? (True / False). |
| `nrf.send(message)` | Send a message (text or a number). Returns True — delivered (the other side confirmed), False — not. |
| `nrf.read()` | Read a message if one has already arrived (doesn't wait). Returns the text or None. |
| `nrf.available()` | Is there an unread message (True / False). |
| `nrf.receive(timeout=None)` | Wait for a message and return the text. timeout — the most seconds to wait (otherwise None). |
| `nrf.on_message(func)` | Call func(text) for every incoming message (the program keeps going). |
| `nrf.stop()` | Stop listening (cancels on_message). |
| `nrf.details()` | Print all radio module settings (for debugging). |
| `nrf.pins()` | Show how to wire the nRF24L01. |
| `nrf.help()` | Show all commands of this module. |

### Common Raspberry Pi commands: pin map, board check, I2C device search — `pi.py`
```python
import pi
pi.pinout()     # map of all 40 pins
pi.check()      # what's enabled on the board and which libraries are missing
pi.devices()    # list of all modules (led, button, lcd ...)
```

| Command | What it does |
|---|---|
| `pi.pinout()` | Draw a map of all 40 Raspberry Pi pins (top view, pin 1 at the edge with the SD card). |
| `pi.devices()` | List of all device modules with an example. |
| `pi.check()` | Check the board: are I2C/SPI on, are the libraries and programs there. |
| `pi.i2c_scan(bus=1)` | Find all devices on the I2C bus. Returns a list of addresses, for example [0x27, 0x68]. |
| `pi.wait(seconds)` | Pause for seconds seconds (fractions allowed: 0.5). |
| `pi.forever()` | Do nothing and keep the program running until Ctrl+C is pressed. |
| `pi.cleanup()` | Stop everything in the background and reset all pins (everything turns off). |
| `pi.help()` | Show all commands of this module. |
