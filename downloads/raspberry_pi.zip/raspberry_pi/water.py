"""
Water / rain sensor (water in the old code).
    import water
    if water.is_water(20): print("Leak!")
    water.on_water(20, lambda: buzzer.alarm(23))
    print(water.level(0))        # level in % (only through an ADC, channel 0)
Wiring diagram: water.pins()     All commands: water.help()
"""
import _core
from _digital import Digital

# The module's DO output: 0 — water present, 1 — dry (like in the old code)
_d = Digital("water", active=0, pull="up")


def is_water(pin):
    """Is there water on the sensor (True / False)."""
    return _d.is_on(pin)


def is_dry(pin):
    """Is the sensor dry (no water)?"""
    return not _d.is_on(pin)


def wait_water(pin, timeout=None):
    """Wait until water appears. Returns True, or False (time ran out)."""
    return _d.wait(pin, True, timeout, settle=0.1)


def wait_dry(pin, timeout=None):
    """Wait until the sensor dries."""
    return _d.wait(pin, False, timeout, settle=0.1)


def on_water(pin, func):
    """Call func() when water appears (the program keeps going)."""
    _d.on(pin, func, True, debounce=0.1)


def on_dry(pin, func):
    """Call func() when the water is gone."""
    _d.on(pin, func, False, debounce=0.5)


def stop(pin):
    """Stop watching (cancels on_water / on_dry)."""
    _d.stop(pin)


def level(channel=0):
    """How much water is on the sensor, 0..100 % (S/AO output -> ADC channel)."""
    import adc
    return adc.percent(channel)


def pins(pin=None):
    """Show how to wire the water sensor."""
    _core.show_pins("Water / rain sensor", [
        ("DO", _core.any_pin(pin)),
        ("AO / S (if you need the level)", "ADC input (see adc.pins()), then water.level(channel)"),
        ("VCC (+)", _core.V3),
        ("GND (-)", _core.GND),
    ], [
        "The DO sensitivity is set with the screw on the comparator board.",
        "The red \"Water Sensor\" board with three contacts S + - is analog only: it needs an ADC.",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
