"""
IR obstacle sensor (FC-51, KY-032) or line sensor (TCRT5000).
    import ir_sensor
    if ir_sensor.is_obstacle(5): print("Obstacle ahead")
    if ir_sensor.is_black(6): print("Black line under the sensor")
    print(ir_sensor.count(5, 10))     # how many objects passed in 10 seconds
Wiring diagram: ir_sensor.pins()     All commands: ir_sensor.help()
"""
import _core
from _digital import Digital

# OUT/DO output: 0 — the beam was reflected (obstacle / white surface), 1 — no reflection
_d = Digital("ir_sensor", active=0, pull="up")


def is_obstacle(pin):
    """Is there an obstacle in front of the sensor (True / False)."""
    return _d.is_on(pin)


def is_clear(pin):
    """Is the way ahead clear?"""
    return not _d.is_on(pin)


def is_black(pin):
    """Line sensor: is it black underneath (the beam isn't reflected)?"""
    return not _d.is_on(pin)


def is_white(pin):
    """Line sensor: is it white underneath (the beam is reflected)?"""
    return _d.is_on(pin)


def wait_obstacle(pin, timeout=None):
    """Wait until an obstacle appears. Returns True, or False (time ran out)."""
    return _d.wait(pin, True, timeout)


def wait_clear(pin, timeout=None):
    """Wait until the obstacle goes away."""
    return _d.wait(pin, False, timeout)


def on_obstacle(pin, func):
    """Call func() when an obstacle appears (the program keeps going)."""
    _d.on(pin, func, True, debounce=0.02)


def on_clear(pin, func):
    """Call func() when the obstacle goes away."""
    _d.on(pin, func, False, debounce=0.02)


def stop(pin):
    """Stop watching (cancels on_obstacle / on_clear)."""
    _d.stop(pin)


def count(pin, seconds=10):
    """Count how many times something appeared in front of the sensor within seconds seconds (object counter)."""
    return _d.count(pin, seconds)


def pins(pin=None):
    """Show how to wire the IR sensor."""
    _core.show_pins("IR obstacle / line sensor", [
        ("OUT (DO)", _core.any_pin(pin)),
        ("VCC", _core.V3),
        ("GND", _core.GND),
    ], [
        "The trigger distance is set with the little screw on the module (2-30 cm).",
        "Bright sunlight confuses IR sensors — test indoors.",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
