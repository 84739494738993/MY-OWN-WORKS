"""
HC-SR04 ultrasonic distance sensor (distance_sensor in the old code).
    import distance
    print(distance.cm())             # distance in centimeters
    if distance.is_closer(20): print("Too close!")
    distance.connect(trig=5, echo=6) # if you didn't wire it to 23/24
Wiring diagram: distance.pins()     All commands: distance.help()
"""
import threading
import time

import _core

_mlock = threading.Lock()
# Pins like in the old code: TRIG=23, ECHO=24
_trig, _echo = 23, 24
_ready = False
_sound = 34300.0   # speed of sound, cm/s (at +20 °C)
_last_time = 0.0


def connect(trig=23, echo=24):
    """Set the TRIG and ECHO pins."""
    global _trig, _echo, _ready
    _trig, _echo = _core.check_pin(trig), _core.check_pin(echo)
    _ready = False


def set_temperature(celsius):
    """Take the air temperature into account (sound is faster when warm) — the distance gets more accurate."""
    global _sound
    _sound = (331.3 + 0.606 * celsius) * 100


def _measure_once():
    with _mlock:  # so background watching and a normal measurement don't get in each other's way
        return _measure()


def _measure():
    global _ready, _last_time
    G = _core.gpio()
    if not _ready:
        _core.write(_trig, 0)
        _core.make_input(_echo, None)
        time.sleep(0.05)
        _ready = True
    # ~60 ms are needed between measurements, otherwise we catch the echo of the previous one
    wait = 0.06 - (time.time() - _last_time)
    if wait > 0:
        time.sleep(wait)
    _last_time = time.time()
    G.output(_trig, 1)
    time.sleep(0.00001)
    G.output(_trig, 0)
    t0 = time.perf_counter()
    while G.input(_echo) == 0:
        if time.perf_counter() - t0 > 0.03:
            return None
    start = time.perf_counter()
    while G.input(_echo) == 1:
        if time.perf_counter() - start > 0.04:
            return None
    return (time.perf_counter() - start) * _sound / 2


def cm(samples=3):
    """Distance in centimeters (median of samples measurements). None — nothing found (beyond ~4 m or an error)."""
    values = []
    for _ in range(max(1, samples)):
        d = _measure_once()
        if d is not None and 2 <= d <= 450:
            values.append(d)
    if not values:
        return None
    values.sort()
    return round(values[len(values) // 2], 1)


def mm(samples=3):
    """Distance in millimeters."""
    d = cm(samples)
    return None if d is None else round(d * 10)


def meters(samples=3):
    """Distance in meters."""
    d = cm(samples)
    return None if d is None else round(d / 100.0, 3)


def is_closer(limit_cm):
    """Is an object closer than limit_cm centimeters? (True / False)."""
    d = cm()
    return d is not None and d < limit_cm


def is_farther(limit_cm):
    """Is the object farther than limit_cm centimeters (or is there nothing)?"""
    return not is_closer(limit_cm)


def wait_closer(limit_cm, timeout=None):
    """Wait until something comes closer than limit_cm. Returns True, or False (time ran out)."""
    return _core.wait_for(lambda: is_closer(limit_cm), timeout, 0.02)


def wait_farther(limit_cm, timeout=None):
    """Wait until the object moves farther than limit_cm."""
    return _core.wait_for(lambda: is_farther(limit_cm), timeout, 0.02)


def on_closer(limit_cm, func):
    """Call func() when something comes closer than limit_cm (the program keeps going)."""
    _core.watch(("distance", "closer"), lambda: is_closer(limit_cm), on_true=func, interval=0.05, debounce=0.1)


def on_farther(limit_cm, func):
    """Call func() when the object moves farther than limit_cm."""
    _core.watch(("distance", "farther"), lambda: is_closer(limit_cm), on_false=func, interval=0.05, debounce=0.1)


def stop():
    """Stop watching (cancels on_closer / on_farther)."""
    _core.stop_task(("distance", "closer"))
    _core.stop_task(("distance", "farther"))


def pins():
    """Show how to wire the distance sensor."""
    _core.show_pins("HC-SR04 ultrasonic distance sensor", [
        ("VCC", _core.V5),
        ("TRIG", _core.any_pin(_trig)),
        ("ECHO", "DIVIDER 1 kΩ + 2 kΩ -> " + _core.any_pin(_echo)),
        ("GND", _core.GND),
    ], [
        "ECHO outputs 5 V! Divider: ECHO -> 1 kΩ -> GPIO, and from GPIO -> 2 kΩ -> GND.",
        "The HC-SR04P model (3.3 V) can be powered from 3.3V and ECHO wired directly.",
        "Other pins: distance.connect(trig=5, echo=6).",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
