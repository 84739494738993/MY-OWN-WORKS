"""
Common Raspberry Pi commands: pin map, board check, I2C device search.
    import pi
    pi.pinout()     # map of all 40 pins
    pi.check()      # what's enabled on the board and which libraries are missing
    pi.devices()    # list of all modules (led, button, lcd ...)
"""
import os
import platform
import time

import _core

_LABEL = {
    1: "3.3V", 2: "5V", 4: "5V", 17: "3.3V",
    6: "GND", 9: "GND", 14: "GND", 20: "GND", 25: "GND", 30: "GND", 34: "GND", 39: "GND",
}
for _bcm, _phys in _core.PHYS.items():
    _LABEL[_phys] = "GPIO%d" % _bcm + (" / " + _core.SPECIAL[_bcm] if _bcm in _core.SPECIAL else "")

DEVICES = [
    ("led", "LED", "led.on(17)"),
    ("rgb", "RGB LED", 'rgb.color("red")'),
    ("button", "button", "button.is_pressed(4)"),
    ("touch", "TTP223 touch button (button_2)", "touch.is_touched(21)"),
    ("servo", "servo", "servo.angle(18, 90)"),
    ("buzzer", "buzzer (buzer)", "buzzer.beep(23)"),
    ("light", "light sensor / photoresistor (foto)", "light.is_dark(24)"),
    ("potentiometer", "potentiometer (potencyometr)", "potentiometer.percent(25)"),
    ("soil", "soil moisture (ground)", "soil.is_dry(16)"),
    ("water", "water sensor (water)", "water.is_water(20)"),
    ("ir_sensor", "IR obstacle / line sensor", "ir_sensor.is_obstacle(5)"),
    ("motion", "PIR motion sensor (motion_sensor)", "motion.is_motion(18)"),
    ("distance", "HC-SR04 distance sensor (distance_sensor)", "distance.cm()"),
    ("adc", "ADC: ADC0832 / MCP3008 / PCF8591 / ADS1115", "adc.read(0)"),
    ("joystick", "joystick (through the ADC)", "joystick.direction()"),
    ("rfid", "RC522 RFID reader", "rfid.read_id()"),
    ("matrix", "8x8 LED matrix MAX7219 (led_8x8)", 'matrix.text("Hello")'),
    ("lcd", "1602 screen over I2C", 'lcd.write("Hello")'),
    ("dht11", "DHT11 temperature and humidity", "dht11.temperature(4)"),
    ("dht22", "DHT22 temperature and humidity", "dht22.temperature(4)"),
    ("clock", "DS3231 clock (time, time_colibrowka)", "clock.time_str()"),
    ("ir", "IR remote: receive and send (ir_remote, ir_read, ir_send)", "ir.read_code()"),
    ("display", "ST7789 240x240 color display", 'display.text("HELLO!")'),
    ("speaker", "speaker: music and voice (dynamic)", 'speaker.say("Hello")'),
    ("weather", "BMP280 + AHT20: pressure, temperature, humidity", "weather.temperature()"),
    ("nrf", "nRF24L01 radio module", 'nrf.send("Hello")'),
]

KNOWN_I2C = {
    0x20: "PCF8574 (1602 screen)", 0x27: "1602 screen (PCF8574)", 0x3F: "1602 screen (PCF8574A)",
    0x38: "AHT20 (humidity) or 1602 screen (PCF8574A)", 0x3C: "SSD1306 OLED screen",
    0x48: "ADC PCF8591 / ADS1115", 0x57: "memory on the DS3231 module", 0x68: "DS3231 clock / MPU6050",
    0x76: "BMP280 / BME280", 0x77: "BMP280 / BME280",
}


def pinout():
    """Draw a map of all 40 Raspberry Pi pins (top view, pin 1 at the edge with the SD card)."""
    print()
    print("        Raspberry Pi — 40-pin header")
    print("   (the code uses GPIO numbers; the physical pin number is in brackets)")
    print()
    for left in range(1, 41, 2):
        right = left + 1
        print("  %22s (%2d) (%2d) %-22s" % (_LABEL[left], left, right, _LABEL[right]))
    print()
    print("  Free GPIOs for simple devices: 4, 5, 6, 12, 13, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27")
    print("  Warning: the pins take only 3.3 V! Never put 5 V on a GPIO input.")
    print()


def devices():
    """List of all device modules with an example."""
    print()
    print("  Module           Device                                      Example")
    print("  " + "-" * 100)
    for mod, what, example in DEVICES:
        print("  %-16s %-43s %s" % (mod, what, example))
    print()
    print("  Every module has  <module>.pins()  — wiring diagram and  <module>.help()  — all commands.")
    print()


def _ok(flag, text, fix=""):
    print("  [%s] %s%s" % ("OK" if flag else "NO", text, ("   ->  " + fix) if (fix and not flag) else ""))


def _try_import(mod):
    try:
        m = __import__(mod)
        for part in mod.split(".")[1:]:
            m = getattr(m, part)
        return True, getattr(m, "__version__", getattr(m, "VERSION", ""))
    except Exception as e:
        return False, str(e)


def check():
    """Check the board: are I2C/SPI on, are the libraries and programs there."""
    print()
    model = ""
    try:
        with open("/proc/device-tree/model") as f:
            model = f.read().strip("\x00\n ")
    except OSError:
        pass
    print("  Board:  %s" % (model or "not a Raspberry Pi (%s)" % platform.platform()))
    print("  Python: %s (%s)" % (platform.python_version(), platform.machine()))
    print()
    print("  Libraries:")
    for mod, what, fix in [
        ("RPi.GPIO", "RPi.GPIO — pins", "bash libs/pi_install/install_on_pi.sh"),
        ("spidev", "spidev — SPI (rfid, matrix, display)", "bash libs/pi_install/install_on_pi.sh"),
        ("smbus2", "smbus2 — I2C (lcd, clock, weather, adc)", "bundled in libs/"),
        ("PIL", "Pillow — pictures and text (display)", "sudo apt install python3-pil"),
        ("mfrc522", "mfrc522 — RFID", "bundled in libs/"),
        ("pyrf24", "pyrf24 — nRF24L01 radio", "pip install pyrf24 --break-system-packages"),
        ("gtts", "gTTS — online voice (speaker.say)", "bundled in libs/"),
    ]:
        ok, info = _try_import(mod)
        _ok(ok, "%s %s" % (what, ("(" + str(info) + ")") if ok and info else ""), fix)
    print()
    print("  Interfaces:")
    _ok(os.path.exists("/dev/i2c-1"), "I2C on (/dev/i2c-1)", "sudo raspi-config -> Interface Options -> I2C")
    _ok(os.path.exists("/dev/spidev0.0"), "SPI on (/dev/spidev0.0)", "sudo raspi-config -> Interface Options -> SPI")
    lirc = sorted(d for d in (os.listdir("/dev") if os.path.isdir("/dev") else []) if d.startswith("lirc"))
    _ok(bool(lirc), "IR receiver/transmitter (%s)" % (", ".join(lirc) or "no /dev/lirc*"), "see ir.pins()")
    print()
    print("  Programs:")
    for prog, what, fix in [
        ("mpv", "mpv — playing music", "sudo apt install mpv"),
        ("espeak-ng", "espeak-ng — offline voice", "sudo apt install espeak-ng"),
        ("ir-ctl", "ir-ctl — IR remote", "sudo apt install v4l-utils"),
        ("i2cdetect", "i2cdetect — I2C device search", "sudo apt install i2c-tools"),
    ]:
        _ok(_core.has_program(prog), what, fix)
    print()


def i2c_scan(bus=1):
    """Find all devices on the I2C bus. Returns a list of addresses, for example [0x27, 0x68]."""
    found = []
    for addr in range(0x03, 0x78):
        if _core.i2c_found(addr, bus):
            found.append(addr)
    print()
    if not found:
        print("  Nobody on the I2C bus. Check the SDA/SCL wires and power.")
    for addr in found:
        print("  0x%02X  %s" % (addr, KNOWN_I2C.get(addr, "")))
    print()
    return found


def wait(seconds):
    """Pause for seconds seconds (fractions allowed: 0.5)."""
    time.sleep(seconds)


def forever():
    """Do nothing and keep the program running until Ctrl+C is pressed."""
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopped.")


def cleanup():
    """Stop everything in the background and reset all pins (everything turns off)."""
    _core.stop_all_tasks()
    if _core._gpio is not None:
        with _core._lock:
            for pin in list(_core._pwm):
                _core._pwm_off(pin)
            _core._gpio.cleanup()
            _core._setup.clear()
            _core._gpio = None  # after cleanup the numbering resets — it's set up again on the next command


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)


if __name__ == "__main__":
    devices()
    pinout()
    check()
