"""
KY-023 joystick (two axes + button). The axes are analog, so an ADC is needed (adc.py).
    import joystick
    print(joystick.x(), joystick.y())   # -100..100 on each axis
    print(joystick.direction())         # "up", "down", "left", "right" or "center"
    joystick.connect(button=17)         # if you connected the SW button
Wiring diagram: joystick.pins()     All commands: joystick.help()
"""
import _core
import adc
from _digital import Digital

_x_ch, _y_ch = 0, 1
_btn = None
_inv_x = _inv_y = False
_center = None       # (x, y) in raw ADC units
_dead = 25           # dead zone in %, inside it the direction = "center"
_d = Digital("joystick", active=0, pull="up")

ARROWS = {"up": "↑", "down": "↓", "left": "←", "right": "→", "center": "•"}


def connect(x=0, y=1, button=None, invert_x=False, invert_y=False, dead_zone=25):
    """ADC channels for the X and Y axes, the SW button pin (if connected), axis inversion and the dead zone in %."""
    global _x_ch, _y_ch, _btn, _inv_x, _inv_y, _dead, _center
    _x_ch, _y_ch = x, y
    _btn = None if button is None else _core.check_pin(button)
    _inv_x, _inv_y, _dead = invert_x, invert_y, dead_zone
    _center = None


def calibrate():
    """Remember the current position as the center (don't touch the joystick while calling it)."""
    global _center
    xs = [adc.read(_x_ch) for _ in range(5)]
    ys = [adc.read(_y_ch) for _ in range(5)]
    _center = (sum(xs) / 5.0, sum(ys) / 5.0)
    return _center


def _axis(raw, center, invert):
    top = adc.max_value()
    if raw >= center:
        v = 100.0 * (raw - center) / max(1, top - center)
    else:
        v = -100.0 * (center - raw) / max(1, center)
    v = max(-100, min(100, v))
    return int(-v if invert else v)


def x():
    """Position on the X axis: -100 (left) .. 0 .. 100 (right)."""
    c = _center or (adc.max_value() / 2.0, adc.max_value() / 2.0)
    return _axis(adc.read(_x_ch), c[0], _inv_x)


def y():
    """Position on the Y axis: -100 (up) .. 0 .. 100 (down). If it's the other way round — connect(invert_y=True)."""
    c = _center or (adc.max_value() / 2.0, adc.max_value() / 2.0)
    return _axis(adc.read(_y_ch), c[1], _inv_y)


def position():
    """Both axes at once: (x, y)."""
    return x(), y()


def direction(arrows=False):
    """Where it's tilted: "up", "down", "left", "right" or "center". arrows=True — "↑", "↓", "←", "→", "•"."""
    px, py = position()
    if max(abs(px), abs(py)) < _dead:
        d = "center"
    elif abs(px) >= abs(py):
        d = "right" if px > 0 else "left"
    else:
        d = "down" if py > 0 else "up"
    return ARROWS[d] if arrows else d


def is_pressed():
    """Is the joystick button pressed (connect SW and set connect(button=pin))."""
    if _btn is None:
        raise RuntimeError("The joystick button isn't set up in the code: joystick.connect(button=17)")
    return _d.is_on(_btn)


def wait_press(timeout=None):
    """Wait for the joystick button to be pressed."""
    if _btn is None:
        raise RuntimeError("The joystick button isn't set up in the code: joystick.connect(button=17)")
    return _d.wait(_btn, True, timeout)


def wait_move(timeout=None):
    """Wait until the joystick is tilted. Returns the direction ("up"...) or None (time ran out)."""
    result = []

    def moved():
        d = direction()
        if d != "center":
            result.append(d)
            return True
        return False

    return result[-1] if _core.wait_for(moved, timeout, 0.02) else None


def on_move(func):
    """Call func(direction) every time the direction changes (except going back to the center)."""

    def loop(ev):
        last = "center"
        while not ev.is_set():
            d = direction()
            if d != last:
                last = d
                if d != "center":
                    try:
                        func(d)
                    except Exception as e:
                        print("[error in your function] %s" % e)
            ev.wait(0.03)

    _core.start_task(("joystick", "move"), loop)


def on_press(func):
    """Call func() when the joystick button is pressed."""
    if _btn is None:
        raise RuntimeError("The joystick button isn't set up in the code: joystick.connect(button=17)")
    _d.on(_btn, func, True)


def stop():
    """Stop watching (cancels on_move / on_press)."""
    _core.stop_task(("joystick", "move"))
    if _btn is not None:
        _d.stop(_btn)


def pins():
    """Show how to wire the joystick."""
    _core.show_pins("KY-023 joystick", [
        ("GND", _core.GND),
        ("+5V", _core.V3 + "  (really 3.3V, so the axes stay in the ADC range)"),
        ("VRx", "ADC channel %d" % _x_ch),
        ("VRy", "ADC channel %d" % _y_ch),
        ("SW (button)", _core.any_pin(_btn) if _btn is not None else "ANY GPIO, then joystick.connect(button=pin)"),
    ], [
        "Wire the ADC itself as shown in adc.pins() (ADC0832 by default).",
        "If the axes are swapped or reversed: joystick.connect(x=1, y=0, invert_y=True).",
        "Center drifts? Call joystick.calibrate() without touching the stick.",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
