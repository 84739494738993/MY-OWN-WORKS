"""
DHT11 temperature and humidity sensor (blue).
    import dht11
    print(dht11.temperature(4))      # °C
    print(dht11.humidity(4))         # %
    t, h = dht11.read(4)             # everything at once
    dht11.show(4)                    # print it nicely
Wiring diagram: dht11.pins()     All commands: dht11.help()
"""
import _core
import _dht


def read(pin):
    """Return (temperature °C, humidity %). If the sensor didn't answer — (None, None)."""
    return _dht.read(pin, 11)


def temperature(pin):
    """Temperature in °C (or None)."""
    return read(pin)[0]


def humidity(pin):
    """Air humidity in % (or None)."""
    return read(pin)[1]


def show(pin):
    """Print the temperature and humidity."""
    _dht.show(pin, 11)


def pins(pin=None):
    """Show how to wire the DHT11."""
    _dht.pins(pin, 11)


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
