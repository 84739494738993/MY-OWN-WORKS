"""
Weather sensor: BMP280 + AHT20 board (pressure, temperature, humidity). From dynamic in the old code.
Also works with just a BMP280 (no humidity) or just an AHT20 (no pressure).
    import weather
    print(weather.temperature())      # °C
    print(weather.humidity())         # %
    print(weather.pressure())         # hPa
    print(weather.pressure_mm())      # mmHg
    weather.show()                    # everything at once
Wiring diagram: weather.pins()     All commands: weather.help()
"""
import time

import _core

_bmp = None        # BMP280 address (0x76 or 0x77), found automatically
_aht = 0x38
_cal = None
_aht_ready = False
SEA_LEVEL = 1013.25


def connect(bmp_address=None, aht_address=0x38):
    """Sensor addresses. BMP280 is usually 0x77 or 0x76 (None — find it automatically)."""
    global _bmp, _aht, _cal, _aht_ready
    _bmp, _aht, _cal, _aht_ready = bmp_address, aht_address, None, False


def _bus():
    return _core.i2c()


def _find_bmp():
    global _bmp
    if _bmp is None:
        for a in (0x77, 0x76):
            try:
                with _core.i2c_lock:
                    if _bus().read_byte_data(a, 0xD0) in (0x56, 0x57, 0x58, 0x60):
                        _bmp = a
                        break
            except OSError:
                pass
    return _bmp


def has_bmp():
    """Is there a BMP280 pressure sensor."""
    return _find_bmp() is not None


def has_aht():
    """Is there an AHT20 humidity sensor."""
    return _core.i2c_found(_aht)


def _calibration():
    global _cal
    if _cal is None:
        with _core.i2c_lock:
            raw = _bus().read_i2c_block_data(_find_bmp(), 0x88, 24)

        def u16(i):
            return raw[i] | (raw[i + 1] << 8)

        def s16(i):
            v = u16(i)
            return v - 65536 if v > 32767 else v

        _cal = [u16(0), s16(2), s16(4), u16(6)] + [s16(8 + 2 * i) for i in range(8)]
    return _cal


def _bmp_read():
    """(temperature °C, pressure hPa) from the BMP280 using the datasheet formulas."""
    addr = _find_bmp()
    if addr is None:
        raise RuntimeError("BMP280 not found on I2C. Check the wiring: weather.pins()")
    T1, T2, T3, P1, P2, P3, P4, P5, P6, P7, P8, P9 = _calibration()
    with _core.i2c_lock:
        bus = _bus()
        bus.write_byte_data(addr, 0xF4, (1 << 5) | (3 << 2) | 1)   # T x1, P x4, one measurement
        for _ in range(50):
            time.sleep(0.005)
            if not bus.read_byte_data(addr, 0xF3) & 0x08:
                break
        d = bus.read_i2c_block_data(addr, 0xF7, 6)
    adc_p = (d[0] << 12) | (d[1] << 4) | (d[2] >> 4)
    adc_t = (d[3] << 12) | (d[4] << 4) | (d[5] >> 4)
    v1 = (adc_t / 16384.0 - T1 / 1024.0) * T2
    v2 = (adc_t / 131072.0 - T1 / 8192.0) ** 2 * T3
    t_fine = v1 + v2
    temp = t_fine / 5120.0
    v1 = t_fine / 2.0 - 64000.0
    v2 = v1 * v1 * P6 / 32768.0
    v2 = v2 + v1 * P5 * 2.0
    v2 = v2 / 4.0 + P4 * 65536.0
    v1 = (P3 * v1 * v1 / 524288.0 + P2 * v1) / 524288.0
    v1 = (1.0 + v1 / 32768.0) * P1
    if v1 == 0:
        return temp, None
    p = 1048576.0 - adc_p
    p = (p - v2 / 4096.0) * 6250.0 / v1
    v1 = P9 * p * p / 2147483648.0
    v2 = p * P8 / 32768.0
    p = p + (v1 + v2 + P7) / 16.0
    return temp, p / 100.0


def _aht_read():
    """(temperature °C, humidity %) from the AHT20."""
    global _aht_ready
    from smbus2 import i2c_msg
    with _core.i2c_lock:
        bus = _bus()
        if not _aht_ready:
            try:
                status = bus.read_byte(_aht)
                if not status & 0x08:  # not calibrated — initialize
                    bus.write_i2c_block_data(_aht, 0xBE, [0x08, 0x00])
                    time.sleep(0.01)
            except OSError:
                pass  # some AHT20 clones don't answer a status read — try measuring straight away
            _aht_ready = True
        try:
            bus.write_i2c_block_data(_aht, 0xAC, [0x33, 0x00])
            time.sleep(0.08)
            msg = i2c_msg.read(_aht, 6)
            bus.i2c_rdwr(msg)
            d = list(msg)
        except OSError:
            raise RuntimeError("AHT20 doesn't answer on I2C (address 0x%02X). Check the wiring: weather.pins(), "
                               "and who's on the bus: pi.i2c_scan()" % _aht) from None
    h = ((d[1] << 12) | (d[2] << 4) | (d[3] >> 4)) / 1048576.0 * 100
    t = (((d[3] & 0x0F) << 16) | (d[4] << 8) | d[5]) / 1048576.0 * 200 - 50
    return t, h


def temperature():
    """Air temperature, °C."""
    if has_bmp():
        return round(_bmp_read()[0], 1)
    try:
        return round(_aht_read()[0], 1)
    except RuntimeError:
        raise RuntimeError("Weather sensor not found: neither BMP280 (0x76/0x77) nor AHT20 (0x%02X) answers on I2C.\n"
                           "Check the wiring: weather.pins(), and who's on the bus: pi.i2c_scan()" % _aht) from None


def humidity():
    """Air humidity, % (needs the AHT20)."""
    return round(_aht_read()[1], 1)


def pressure():
    """Atmospheric pressure, hPa (hectopascals; normal is about 1013)."""
    return round(_bmp_read()[1], 1)


def pressure_mm():
    """Atmospheric pressure, mm of mercury (normal is about 760)."""
    return round(_bmp_read()[1] * 0.750062, 1)


def altitude(sea_level=None):
    """Approximate altitude above sea level, m (from the pressure)."""
    p = _bmp_read()[1]
    return round(44330.0 * (1 - (p / (sea_level or SEA_LEVEL)) ** (1 / 5.255)), 1)


def read():
    """Everything at once as a dict: {'temperature': .., 'humidity': .., 'pressure': .., 'pressure_mm': ..}."""
    data = {}
    if has_bmp():
        t, p = _bmp_read()
        data.update(temperature=round(t, 1), pressure=round(p, 1), pressure_mm=round(p * 0.750062, 1))
    if has_aht():
        t, h = _aht_read()
        data.setdefault("temperature", round(t, 1))
        data["humidity"] = round(h, 1)
    return data


def show():
    """Print everything the sensor can do."""
    d = read()
    if not d:
        print("Weather sensor not found. Check the wiring: weather.pins()")
        return
    parts = []
    if "temperature" in d:
        parts.append("Temperature: %.1f °C" % d["temperature"])
    if "humidity" in d:
        parts.append("Humidity: %.0f %%" % d["humidity"])
    if "pressure" in d:
        parts.append("Pressure: %.0f hPa (%.0f mmHg)" % (d["pressure"], d["pressure_mm"]))
    print("   ".join(parts))


def phrase(lang="en"):
    """Ready-made sentence for the voice: speaker.say(weather.phrase())."""
    d = read()
    s = "Air temperature is %.0f degrees." % d.get("temperature", 0)
    if "humidity" in d:
        s += " Humidity is %.0f percent." % d["humidity"]
    if "pressure" in d:
        s += " Pressure is %.0f hectopascals." % d["pressure"]
    return s


def pins():
    """Show how to wire the weather sensor."""
    _core.show_pins("Weather sensor BMP280 + AHT20 (I2C)", [
        ("VIN / VCC", _core.V3),
        ("GND", _core.GND),
        ("SDA", _core.only_pin(2)),
        ("SCL", _core.only_pin(3)),
    ], [
        "Turn on I2C: sudo raspi-config -> Interface Options -> I2C -> Yes.",
        "Addresses: AHT20 = 0x38, BMP280 = 0x77 or 0x76 (check: pi.i2c_scan()).",
        "Can share the same SDA/SCL wires with the 1602 screen and the DS3231 clock.",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
