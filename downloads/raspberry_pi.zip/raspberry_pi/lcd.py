"""
1602 (or 2004) screen with a PCF8574 I2C board.
    import lcd
    lcd.write("Hello!")               # to line 1 (Cyrillic letters are converted to Latin automatically)
    lcd.write("t = 23.5°C", 2)        # to line 2
    lcd.show("Line 1", "Line 2")      # clear and print both lines
    lcd.scroll("A long scrolling line")
    lcd.connect(cols=20, rows=4)      # for a 2004 screen
Wiring diagram: lcd.pins()     All commands: lcd.help()
"""
import time

import _core

_addr = None
_cols, _rows = 16, 2
_backlight = 0x08
_ctrl = 0x04          # display on, cursor off, blinking off
_ready = False
KEY = "lcd"

_TRANSLIT = {
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e", "ж": "zh", "з": "z",
    "и": "i", "й": "y", "к": "k", "л": "l", "м": "m", "н": "n", "о": "o", "п": "p", "р": "r",
    "с": "s", "т": "t", "у": "u", "ф": "f", "х": "h", "ц": "c", "ч": "ch", "ш": "sh", "щ": "sch",
    "ъ": "", "ы": "y", "ь": "'", "э": "e", "ю": "yu", "я": "ya",
}


def connect(address=None, cols=16, rows=2):
    """address — I2C address (usually 0x27 or 0x3F; None — find it automatically), screen size cols x rows."""
    global _addr, _cols, _rows, _ready
    _addr, _cols, _rows, _ready = address, cols, rows, False


def find():
    """Find the screen on the I2C bus. Returns the address or None."""
    for a in [0x27, 0x3F] + list(range(0x20, 0x27)) + list(range(0x38, 0x3F)):
        if _core.i2c_found(a):
            return a
    return None


def _bus_write(b):
    with _core.i2c_lock:
        _core.i2c().write_byte(_addr, b)


def _nibble(data):
    # upper 4 bits of the byte -> lines D4-D7, strobe on E
    _bus_write(data | _backlight)
    _bus_write(data | 0x04 | _backlight)
    time.sleep(0.0005)
    _bus_write((data & ~0x04) | _backlight)
    time.sleep(0.0001)


def _send(value, rs=0):
    _nibble(rs | (value & 0xF0))
    _nibble(rs | ((value << 4) & 0xF0))


def _cmd(c):
    _init()
    _send(c, 0)
    if c in (0x01, 0x02):
        time.sleep(0.002)


def _init():
    global _addr, _ready
    if _ready:
        return
    if _addr is None:
        _addr = find()
        if _addr is None:
            raise RuntimeError("1602 screen not found on I2C. Check the wiring: lcd.pins(), and that I2C is on.")
    _ready = True
    time.sleep(0.05)
    for wait in (0.005, 0.001, 0.001):
        _nibble(0x30)
        time.sleep(wait)
    _nibble(0x20)               # 4-bit mode
    _send(0x28 if _rows > 1 else 0x20)   # 2 lines, 5x8 font
    _send(0x08 | _ctrl)
    _send(0x01)
    time.sleep(0.002)
    _send(0x06)                 # cursor moves right


def _prepare(text):
    out = []
    for ch in str(text):
        low = ch.lower()
        if low in _TRANSLIT:
            t = _TRANSLIT[low]
            out.append(t.capitalize() if ch != low else t)
        elif ch in ("°", "\xdf"):
            out.append("\xdf")   # degree sign in the screen's ROM
        elif ord(ch) < 8 or 32 <= ord(ch) < 127:
            out.append(ch)
        else:
            out.append("?")
    return "".join(out)


def _offsets():
    if _cols == 16 and _rows == 4:
        return [0x00, 0x40, 0x10, 0x50]
    return [0x00, 0x40, 0x14, 0x54]


def move(col, line=1):
    """Put the cursor in column col (from 0) of line line (from 1)."""
    line = max(1, min(_rows, line))
    _cmd(0x80 | (_offsets()[line - 1] + max(0, min(_cols - 1, col))))


def write(text, line=1, col=0, clear_rest=True):
    """Write text to line line (1.._rows) from position col. clear_rest — erase the old tail of the line."""
    _core.stop_foreign(KEY)
    _write(text, line, col, clear_rest)


def _write(text, line, col, clear_rest):
    s = _prepare(text)[: max(0, _cols - col)]
    if clear_rest:
        s = s.ljust(_cols - col)
    move(col, line)
    for ch in s:
        _send(ord(ch), 1)


def show(line1="", line2="", line3="", line4=""):
    """Clear the screen and print up to 4 lines."""
    _core.stop_foreign(KEY)
    for i, t in enumerate([line1, line2, line3, line4][:_rows]):
        _write(t, i + 1, 0, True)


def center(text, line=1):
    """Write text centered in the line."""
    write(_prepare(text).center(_cols), line)


def clear():
    """Clear the screen (and stop the scrolling line)."""
    _core.stop_foreign(KEY)
    _cmd(0x01)


def clear_line(line=1):
    """Clear one line."""
    write("", line)


def scroll(text, line=1, speed=0.3, times=1):
    """Scrolling text in line line. speed — seconds per step. The program waits until it has scrolled through."""
    _core.stop_foreign(KEY)
    for _ in range(times):
        _scroll(text, line, speed)


def _scroll(text, line, speed, ev=None):
    s = " " * _cols + _prepare(text) + " " * _cols
    for i in range(len(s) - _cols + 1):
        _write(s[i:i + _cols], line, 0, False)
        if _core.sleep(speed, ev):
            return True
    return False


def start_scroll(text, line=1, speed=0.3):
    """Scrolling text in the background, in a loop (the program keeps going). Stop it: lcd.clear()."""

    def loop(ev):
        while not ev.is_set():
            if _scroll(text, line, speed, ev):
                break

    _core.start_task(KEY, loop)


def backlight(on=True):
    """Turn the backlight on / off."""
    global _backlight
    _init()
    _backlight = 0x08 if on else 0x00
    _bus_write(_backlight)


def on():
    """Turn the screen on (the text comes back)."""
    global _ctrl
    _ctrl |= 0x04
    _cmd(0x08 | _ctrl)


def off():
    """Turn the screen off without erasing the text (the backlight stays — turn it off with backlight(False))."""
    global _ctrl
    _ctrl &= ~0x04
    _cmd(0x08 | _ctrl)


def cursor(show=True, blink=False):
    """Show an underline cursor (show) and/or a blinking block (blink)."""
    global _ctrl
    _ctrl = (_ctrl & 0x04) | (0x02 if show else 0) | (0x01 if blink else 0)
    _cmd(0x08 | _ctrl)


def create_char(slot, pattern):
    """Your own symbol (up to 8, slot 0..7). pattern — 8 rows of 5 dots: ["01010", "11111", ...]."""
    rows = [int(r, 2) if isinstance(r, str) else int(r) for r in pattern][:8]
    _cmd(0x40 | ((slot & 7) << 3))
    for r in rows + [0] * (8 - len(rows)):
        _send(r & 0x1F, 1)
    move(0, 1)


def char(slot, col=0, line=1):
    """Print your own symbol slot (made with create_char) at position col, line."""
    move(col, line)
    _send(slot & 7, 1)


def pins():
    """Show how to wire the screen."""
    _core.show_pins("1602/2004 screen with an I2C board (PCF8574)", [
        ("GND", _core.GND),
        ("VCC", _core.V5),
        ("SDA", _core.only_pin(2)),
        ("SCL", _core.only_pin(3)),
    ], [
        "Turn on I2C: sudo raspi-config -> Interface Options -> I2C -> Yes, then reboot.",
        "Can't see anything? Turn the blue screw (contrast) on the back board.",
        "Find the address: lcd.find() or pi.i2c_scan(). Usually 0x27 or 0x3F.",
        "The screen can't show Cyrillic letters — they are automatically written in Latin letters.",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
