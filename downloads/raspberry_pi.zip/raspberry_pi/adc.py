"""
ADC — turns a voltage of 0..3.3 V into a number. The Raspberry Pi has no ADC of its own, so
a potentiometer, a joystick and analog sensors (AO output) need an ADC chip.
Supported: ADC0832 (default, like in the old code), MCP3008, PCF8591, ADS1115.
    import adc
    print(adc.read(0))        # raw number from channel 0
    print(adc.percent(0))     # 0..100 %
    adc.connect("mcp3008")    # if you have a different chip
Wiring diagram: adc.pins()     All commands: adc.help()
"""
import time

import _core

CHIPS = {
    # chip: (channels, maximum, bus)
    "adc0832": (2, 255, "gpio"),
    "mcp3008": (8, 1023, "gpio"),
    "pcf8591": (4, 255, "i2c"),
    "ads1115": (4, 26400, "i2c"),   # 26400 ≈ 3.3 V with the ±4.096 V range
}
_chip = "adc0832"
# Pins like in the old joystick code: CS=22, CLK=23, DO=24, DI=25
_pins = {"cs": 22, "clk": 23, "do": 24, "di": 25}
_address = None
_ready = False


def connect(chip="adc0832", cs=22, clk=23, do=24, di=25, address=None):
    """Choose the chip and pins. ADC0832 with a single DIO wire: di=None (or di=do).
    PCF8591 / ADS1115 use I2C — no pins needed, the default address is 0x48."""
    global _chip, _pins, _address, _ready
    chip = chip.lower().replace("-", "")
    if chip not in CHIPS:
        raise ValueError("Unknown chip %r. Available: %s" % (chip, ", ".join(CHIPS)))
    _chip = chip
    if CHIPS[chip][2] == "gpio":
        for p in (cs, clk, do):
            _core.check_pin(p)
        if di is not None:
            _core.check_pin(di)
        _pins = {"cs": cs, "clk": clk, "do": do, "di": do if di is None else di}
    _address = address
    _ready = False


def channels():
    """How many channels the selected chip has."""
    return CHIPS[_chip][0]


def max_value():
    """The largest number the chip returns (255, 1023 ...)."""
    return CHIPS[_chip][1]


def _prepare():
    global _ready
    if _ready:
        return
    if CHIPS[_chip][2] == "gpio":
        _core.write(_pins["cs"], 1)
        _core.write(_pins["clk"], 0)
        if _pins["di"] != _pins["do"]:
            _core.write(_pins["di"], 0)
            _core.make_input(_pins["do"], None)
    _ready = True


def read(channel=0):
    """Raw value from a channel: from 0 to adc.max_value()."""
    if not 0 <= channel < channels():
        raise ValueError("%s channels go from 0 to %d" % (_chip.upper(), channels() - 1))
    _prepare()
    with _core._lock:
        if _chip == "adc0832":
            return _read_adc0832(channel)
        if _chip == "mcp3008":
            return _read_mcp3008(channel)
    if _chip == "pcf8591":
        return _read_pcf8591(channel)
    return _read_ads1115(channel)


def percent(channel=0):
    """Value in percent 0..100."""
    return round(read(channel) * 100.0 / max_value(), 1)


def voltage(channel=0, vref=3.3):
    """Voltage on the channel in volts."""
    if _chip == "ads1115":
        return round(read(channel) * 4.096 / 32768, 3)
    return round(read(channel) * vref / max_value(), 3)


def _read_adc0832(ch):
    G = _core.gpio()
    cs, clk, do, di = _pins["cs"], _pins["clk"], _pins["do"], _pins["di"]
    shared = di == do
    if shared:
        G.setup(di, G.OUT)
    G.output(cs, 0)
    for bit in (1, 1, ch & 1):  # start bit, single-ended mode, channel number
        G.output(di, bit)
        G.output(clk, 1)
        G.output(clk, 0)
    if shared:
        G.setup(do, G.IN)
    value = 0
    for _ in range(8):  # 8 bits, most significant first
        G.output(clk, 1)
        G.output(clk, 0)
        value = (value << 1) | G.input(do)
    G.output(cs, 1)
    if shared:
        _core._setup.pop(do, None)
    return value


def _read_mcp3008(ch):
    G = _core.gpio()
    cs, clk, do, di = _pins["cs"], _pins["clk"], _pins["do"], _pins["di"]
    G.output(cs, 1)
    G.output(clk, 0)
    G.output(cs, 0)
    cmd = (ch | 0x18) << 3  # start bit + single-ended mode + 3 channel bits
    for _ in range(5):
        G.output(di, 1 if cmd & 0x80 else 0)
        cmd <<= 1
        G.output(clk, 1)
        G.output(clk, 0)
    value = 0
    for _ in range(12):  # empty bit, null bit and 10 data bits
        G.output(clk, 1)
        G.output(clk, 0)
        value = (value << 1) | G.input(do)
    G.output(cs, 1)
    return (value >> 1) & 0x3FF


def _i2c_addr():
    return _address if _address is not None else 0x48


def _read_pcf8591(ch):
    bus = _core.i2c()
    with _core.i2c_lock:
        bus.write_byte(_i2c_addr(), 0x40 | ch)
        bus.read_byte(_i2c_addr())  # the first read returns the old value
        return bus.read_byte(_i2c_addr())


def _read_ads1115(ch):
    bus = _core.i2c()
    # single conversion, input AINx against GND, range ±4.096 V, 128 samples/s
    config = 0x8000 | ((4 + ch) << 12) | (1 << 9) | (1 << 8) | (4 << 5) | 3
    with _core.i2c_lock:
        bus.write_i2c_block_data(_i2c_addr(), 0x01, [config >> 8, config & 0xFF])
        time.sleep(0.01)
        d = bus.read_i2c_block_data(_i2c_addr(), 0x00, 2)
    v = (d[0] << 8) | d[1]
    if v > 0x7FFF:
        v -= 0x10000
    return max(0, v)


def pins():
    """Show how to wire the selected ADC."""
    p = _pins
    if _chip == "adc0832":
        rows = [
            ("CS (leg 1)", _core.any_pin(p["cs"])),
            ("CH0 (leg 2)", "analog signal #0 (for example the joystick X axis)"),
            ("CH1 (leg 3)", "analog signal #1 (for example the joystick Y axis)"),
            ("GND (leg 4)", _core.GND),
            ("DI (leg 5)", _core.any_pin(p["di"])),
            ("DO (leg 6)", _core.any_pin(p["do"]) + ("  (the same wire as DI)" if p["di"] == p["do"] else "")),
            ("CLK (leg 7)", _core.any_pin(p["clk"])),
            ("VCC (leg 8)", _core.V3),
        ]
        notes = ["If DI and DO are joined together (DIO): adc.connect('adc0832', cs=.., clk=.., do=.., di=None)."]
    elif _chip == "mcp3008":
        rows = [
            ("VDD (16), VREF (15)", _core.V3),
            ("AGND (14), DGND (9)", _core.GND),
            ("CLK (13)", _core.any_pin(p["clk"])),
            ("DOUT (12)", _core.any_pin(p["do"])),
            ("DIN (11)", _core.any_pin(p["di"])),
            ("CS (10)", _core.any_pin(p["cs"])),
            ("CH0..CH7 (1..8)", "analog signals"),
        ]
        notes = ["Can use hardware SPI: CLK->GPIO11, DOUT->GPIO9, DIN->GPIO10, CS->GPIO8 and "
                 "adc.connect('mcp3008', cs=8, clk=11, do=9, di=10)."]
    else:
        rows = [
            ("VCC", _core.V3),
            ("GND", _core.GND),
            ("SDA", _core.only_pin(2)),
            ("SCL", _core.only_pin(3)),
            ("AIN0..AIN3", "analog signals"),
        ]
        notes = ["Turn on I2C: sudo raspi-config -> Interface Options -> I2C.",
                 "Check the address: import pi; pi.i2c_scan()   (usually 0x48)."]
    _core.show_pins("ADC %s" % _chip.upper(), rows, notes + [
        "Another chip: adc.connect('mcp3008') / adc.connect('pcf8591') / adc.connect('ads1115').",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
