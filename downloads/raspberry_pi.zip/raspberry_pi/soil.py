"""
Soil moisture sensor (ground in the old code).
    import soil
    if soil.is_dry(16): print("Water the plant!")
    print(soil.status(16))          # "dry" or "wet"
    print(soil.moisture(0))         # moisture in % (only through an ADC, channel 0)
Wiring diagram: soil.pins()     All commands: soil.help()
"""
import _core
from _digital import Digital

# The module's DO output: 1 — dry, 0 — wet (like in the old code)
_d = Digital("soil", active=1, pull="up")
_cal = _core.load_json("soil_calibration.json", {})   # ADC channel -> [dry, wet]


def is_dry(pin):
    """Is the soil dry? (True / False). The threshold is the screw on the module."""
    return _d.is_on(pin)


def is_wet(pin):
    """Is the soil wet? (True / False)."""
    return not _d.is_on(pin)


def status(pin):
    """The string "dry" or "wet"."""
    return "dry" if is_dry(pin) else "wet"


def wait_dry(pin, timeout=None):
    """Wait until the soil dries out. Returns True, or False (time ran out)."""
    return _d.wait(pin, True, timeout, settle=0.5)


def wait_wet(pin, timeout=None):
    """Wait until the soil is watered."""
    return _d.wait(pin, False, timeout, settle=0.5)


def on_dry(pin, func):
    """Call func() when the soil gets dry."""
    _d.on(pin, func, True, debounce=1.0)


def on_wet(pin, func):
    """Call func() when the soil gets wet."""
    _d.on(pin, func, False, debounce=1.0)


def stop(pin):
    """Stop watching (cancels on_dry / on_wet)."""
    _d.stop(pin)


def moisture(channel=0):
    """Moisture 0..100 % through an ADC (the module's AO output -> ADC channel). More accurate after soil.calibrate()."""
    import adc
    v = adc.read(channel)
    dry, wet = _cal.get(str(channel), [adc.max_value(), 0])
    if dry == wet:
        return 0
    return int(max(0, min(100, round(100.0 * (dry - v) / (dry - wet)))))


def calibrate(channel=0):
    """Tune moisture(): measure the sensor in the air (dry) and in a glass of water (wet). Saved to a file."""
    import adc
    input("Hold the sensor in the AIR and press Enter...")
    dry = adc.read(channel)
    input("Put the sensor in WATER (up to the line) and press Enter...")
    wet = adc.read(channel)
    _cal[str(channel)] = [dry, wet]
    path = _core.save_json("soil_calibration.json", _cal)
    print("Done: dry=%s, wet=%s. Saved to %s" % (dry, wet, path))


def pins(pin=None):
    """Show how to wire the soil sensor."""
    _core.show_pins("Soil moisture sensor (module with a comparator)", [
        ("DO", _core.any_pin(pin)),
        ("AO (if you need percent)", "ADC input (see adc.pins()), then soil.moisture(channel)"),
        ("VCC", _core.V3),
        ("GND", _core.GND),
        ("probe (2 wires)", "to the comparator board, polarity doesn't matter"),
    ], [
        "The dry/wet threshold for DO is set with the screw on the blue board.",
        "To keep the probe from rusting, power it from a GPIO and switch it on only while measuring.",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
