"""
DS3231 real-time clock (time and time_colibrowka in the old code). Keeps running without power — on its battery.
    import clock
    print(clock.now())         # [year, month, day, hours, minutes, seconds]
    print(clock.time_str())    # "14:05:09"
    print(clock.date_str())    # "16.10.2026"
    clock.sync()               # write the Raspberry's time into the clock (formerly time_colibrowka)
    clock.wait_until(7, 30)    # alarm clock: wait until 7:30
Wiring diagram: clock.pins()     All commands: clock.help()
"""
import datetime as _dt
import subprocess
import time

import _core

ADDR = 0x68
WEEKDAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August",
          "September", "October", "November", "December"]


def _bcd2dec(b):
    return (b >> 4) * 10 + (b & 0x0F)


def _dec2bcd(d):
    return ((d // 10) << 4) | (d % 10)


def _read(reg, n):
    try:
        with _core.i2c_lock:
            return _core.i2c().read_i2c_block_data(ADDR, reg, n)
    except OSError as e:
        raise RuntimeError(
            "DS3231 clock doesn't answer (%s). Check the wiring: clock.pins(). "
            "If config.txt has dtoverlay=i2c-rtc,ds3231, the system has taken the module — remove that line." % e) from None


def _write(reg, data):
    with _core.i2c_lock:
        _core.i2c().write_i2c_block_data(ADDR, reg, data)


def now():
    """Current date and time: [year, month, day, hours, minutes, seconds]."""
    d = _read(0x00, 7)
    sec = _bcd2dec(d[0] & 0x7F)
    minute = _bcd2dec(d[1] & 0x7F)
    if d[2] & 0x40:  # 12-hour mode
        hour = _bcd2dec(d[2] & 0x1F) % 12 + (12 if d[2] & 0x20 else 0)
    else:
        hour = _bcd2dec(d[2] & 0x3F)
    day = _bcd2dec(d[4] & 0x3F)
    month = _bcd2dec(d[5] & 0x1F)
    year = _bcd2dec(d[6]) + 2000 + (100 if d[5] & 0x80 else 0)
    return [year, month, day, hour, minute, sec]


def datetime():
    """Date and time as a datetime object (handy for computing differences)."""
    return _dt.datetime(*now())


def time_str(seconds=True):
    """Time as a string: "14:05:09" (seconds=False -> "14:05")."""
    y, mo, d, h, mi, s = now()
    return "%02d:%02d:%02d" % (h, mi, s) if seconds else "%02d:%02d" % (h, mi)


def date_str(words=False):
    """Date as a string: "16.10.2026" (words=True -> "16 October 2026")."""
    y, mo, d = now()[:3]
    return "%d %s %d" % (d, MONTHS[mo - 1], y) if words else "%02d.%02d.%d" % (d, mo, y)


def year():
    """Year."""
    return now()[0]


def month():
    """Month 1..12."""
    return now()[1]


def day():
    """Day of the month 1..31."""
    return now()[2]


def hour():
    """Hours 0..23."""
    return now()[3]


def minute():
    """Minutes 0..59."""
    return now()[4]


def second():
    """Seconds 0..59."""
    return now()[5]


def weekday():
    """Day of the week as a word: "Monday" ... "Sunday"."""
    return WEEKDAYS[datetime().weekday()]


def set(year, month, day, hour, minute, second=0):
    """Set the time by hand: clock.set(2026, 10, 16, 14, 5, 0)."""
    wd = _dt.date(year, month, day).isoweekday()
    _write(0x00, [_dec2bcd(second), _dec2bcd(minute), _dec2bcd(hour), wd,
                  _dec2bcd(day), _dec2bcd(month), _dec2bcd(year % 100)])
    status = _read(0x0F, 1)[0]
    _write(0x0F, [status & 0x7F])  # clear the "clock was stopped" flag


def sync():
    """Write the Raspberry Pi's current time into the module (formerly time_colibrowka). The Pi needs internet."""
    t = _dt.datetime.now()
    set(t.year, t.month, t.day, t.hour, t.minute, t.second)
    print("Time written to the clock: %s" % t.strftime("%d.%m.%Y %H:%M:%S"))


def to_system():
    """The other way round: set the Raspberry Pi's time from the DS3231 (when there's no internet). Needs sudo."""
    t = datetime().strftime("%Y-%m-%d %H:%M:%S")
    subprocess.run(["sudo", "date", "-s", t], check=False)


def temperature():
    """Temperature inside the DS3231 module (°C, 0.25 steps)."""
    msb, lsb = _read(0x11, 2)
    t = msb - 256 if msb & 0x80 else msb
    return t + (lsb >> 6) * 0.25


def lost_power():
    """True if the clock has stopped (dead battery) and the time must be set again."""
    return bool(_read(0x0F, 1)[0] & 0x80)


def show():
    """Print the date, time and day of the week."""
    print("%s, %s, %s" % (date_str(), time_str(), weekday()))


def wait_until(hour, minute=0, second=0):
    """Wait until the clock shows hour:minute (alarm clock). If that time has passed today — until tomorrow."""
    target = (hour, minute, second)
    last = None
    while True:
        cur = tuple(now()[3:6])
        if last is not None and last < target <= cur:
            return
        if cur == target:
            return
        last = cur
        time.sleep(0.5)


def pins():
    """Show how to wire the clock."""
    _core.show_pins("DS3231 real-time clock (I2C)", [
        ("GND", _core.GND),
        ("VCC", _core.V3),
        ("SDA (D)", _core.only_pin(2)),
        ("SCL (C)", _core.only_pin(3)),
        ("SQW, 32K", "not connected"),
    ], [
        "Turn on I2C: sudo raspi-config -> Interface Options -> I2C -> Yes.",
        "Address 0x68 (check: pi.i2c_scan()). If it shows UU — remove dtoverlay=i2c-rtc from config.txt.",
        "Put in a CR2032 battery — then the clock runs without power.",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
