"""
RGB LED (any color mixed from red, green and blue).
    import rgb
    rgb.color("red")          # or "lime", (255, 120, 0), "#FF7800"
    rgb.rainbow(5)            # rainbow for 5 seconds
    rgb.connect(5, 6, 13)     # if you didn't wire it to 17/27/22
Wiring diagram: rgb.pins()     All commands: rgb.help()
"""
import colorsys
import random as _random
import time

import _core

# Default pins — like in the old code: R=17, G=27, B=22
_pins = [17, 27, 22]
_anode = False      # common anode (long leg on 3.3 V) — then everything is inverted
_bright = 100       # overall brightness, %
_current = (0, 0, 0)
KEY = "rgb"

COLORS = {
    "red": (255, 0, 0), "green": (0, 255, 0), "blue": (0, 0, 255), "white": (255, 255, 255),
    "yellow": (255, 255, 0), "cyan": (0, 255, 255), "magenta": (255, 0, 255), "purple": (128, 0, 255),
    "orange": (255, 80, 0), "pink": (255, 40, 120), "black": (0, 0, 0), "off": (0, 0, 0),
    "lime": (0, 255, 0), "navy": (0, 0, 128), "aqua": (0, 255, 255), "violet": (128, 0, 255),
    "gold": (255, 180, 0), "amber": (255, 150, 0), "warm": (255, 160, 60),
    "teal": (0, 128, 128), "lavender": (180, 120, 255), "crimson": (220, 20, 60),
    "coral": (255, 90, 60), "rose": (255, 0, 100), "gray": (60, 60, 60), "grey": (60, 60, 60),
    "dark": (0, 0, 0),
}


def connect(red=17, green=27, blue=22, common_anode=False):
    """Set the R, G, B pins. common_anode=True — if the common leg goes to 3.3 V, not to GND."""
    global _pins, _anode
    for p in (red, green, blue):
        _core.check_pin(p)
    if _current != (0, 0, 0):
        off()  # switch off the old pins only if something was lit on them
    _pins = [red, green, blue]
    _anode = common_anode


def _parse(r, g=None, b=None):
    if g is not None and b is not None:
        return (int(r), int(g), int(b))
    if isinstance(r, (tuple, list)):
        return tuple(int(v) for v in r[:3])
    s = str(r).strip().lower()
    if s in COLORS:
        return COLORS[s]
    if s.startswith("#") and len(s) == 7:
        return (int(s[1:3], 16), int(s[3:5], 16), int(s[5:7], 16))
    raise ValueError("Unknown color %r. List of colors: rgb.colors()" % (r,))


def _apply(c):
    global _current
    c = tuple(max(0, min(255, int(v))) for v in c)
    _current = c
    for pin, v in zip(_pins, c):
        duty = (v / 255.0) ** 2 * _bright  # squared — so brightness changes evenly "to the eye"
        if duty <= 0:
            _core.write(pin, 1 if _anode else 0)
        elif duty >= 100:
            _core.write(pin, 0 if _anode else 1)
        else:
            _core.pwm(pin, 200, 100 - duty if _anode else duty)


def color(r, g=None, b=None):
    """Light a color: rgb.color("red"), rgb.color(255, 100, 0), rgb.color("#FF6400")."""
    _core.stop_foreign(KEY)
    _apply(_parse(r, g, b))


def on(c="white"):
    """Turn on (white by default)."""
    color(c)


def off():
    """Turn off (and stop blinking / rainbow)."""
    _core.stop_foreign(KEY)
    _apply((0, 0, 0))


def get_color():
    """Which color is lit right now: (R, G, B)."""
    return _current


def brightness(percent):
    """Overall brightness 0..100 % for all colors."""
    global _bright
    _bright = max(0, min(100, percent))
    _apply(_current)


def blink(c="red", times=3, speed=0.5):
    """Blink color c times times."""
    _core.stop_foreign(KEY)
    rgb = _parse(c)
    for _ in range(times):
        _apply(rgb)
        time.sleep(speed)
        _apply((0, 0, 0))
        time.sleep(speed)


def start_blink(c="red", speed=0.5):
    """Blink in the background non-stop. Stop it: rgb.off()."""
    rgb = _parse(c)

    def loop(ev):
        while not ev.is_set():
            _apply(rgb)
            if ev.wait(speed):
                break
            _apply((0, 0, 0))
            ev.wait(speed)

    _core.start_task(KEY, loop)


def fade(c, seconds=1.0):
    """Smoothly change from the current color to color c over seconds seconds."""
    _core.stop_foreign(KEY)
    _fade(_parse(c), seconds)


def _fade(target, seconds, ev=None):
    start = _current
    steps = max(1, int(seconds * 40))
    for i in range(1, steps + 1):
        k = i / steps
        _apply([start[j] + (target[j] - start[j]) * k for j in range(3)])
        if _core.sleep(seconds / steps, ev):
            return True
    return False


def _rainbow_step(ev, speed):
    steps = max(1, int(speed * 40))
    for i in range(steps):
        r, g, b = colorsys.hsv_to_rgb(i / steps, 1, 1)
        _apply((r * 255, g * 255, b * 255))
        if _core.sleep(speed / steps, ev):
            return True
    return False


def rainbow(seconds=5, speed=2.0):
    """Cycle through all colors for seconds seconds. speed — seconds per rainbow cycle."""
    _core.stop_foreign(KEY)
    end = time.time() + seconds
    while time.time() < end:
        _rainbow_step(None, min(speed, max(0.1, end - time.time())))
    off()


def start_rainbow(speed=2.0):
    """Rainbow in the background non-stop. Stop it: rgb.off()."""

    def loop(ev):
        while not ev.is_set():
            if _rainbow_step(ev, speed):
                break

    _core.start_task(KEY, loop)


def random_color():
    """Light a random bright color. Returns (R, G, B)."""
    r, g, b = colorsys.hsv_to_rgb(_random.random(), 1, 1)
    c = (int(r * 255), int(g * 255), int(b * 255))
    color(c)
    return c


def police(times=5, speed=0.15):
    """Police lights: red-blue."""
    _core.stop_foreign(KEY)
    for _ in range(times):
        for c in ((255, 0, 0), (0, 0, 0), (0, 0, 255), (0, 0, 0)):
            _apply(c)
            time.sleep(speed)


def colors():
    """Show all color names."""
    print(", ".join(sorted(COLORS)))


def pins():
    """Show how to wire the RGB LED."""
    common = "3.3V (phys. pin 1)" if _anode else _core.GND
    _core.show_pins("RGB LED (%s)" % ("common anode" if _anode else "common cathode"), [
        ("R (red)", "220 Ω resistor -> " + _core.any_pin(_pins[0])),
        ("G (green)", "220 Ω resistor -> " + _core.any_pin(_pins[1])),
        ("B (blue)", "220 Ω resistor -> " + _core.any_pin(_pins[2])),
        ("common (the longest)", common),
    ], [
        "Other pins: rgb.connect(red, green, blue), for example rgb.connect(5, 6, 13).",
        "If the colors are \"inverted\" (lit when it should be off) — rgb.connect(..., common_anode=True).",
        "A ready-made module (KY-016) already has resistors: R, G, B -> pins, '-' -> GND.",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
