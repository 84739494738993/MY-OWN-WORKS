"""
Speaker (dynamic in the old code): music, voice, sounds.
    import speaker
    speaker.play("elsa.mp3")                 # play a file (mp3, wav, ogg...)
    speaker.play("elsa.mp3", wait=False)     # play in the background, the program keeps going
    speaker.say("Hello, I am a Raspberry Pi")   # say it out loud (online voice; offline it uses espeak)
    speaker.volume(70)                       # volume 70 %
    speaker.set_device(None)                 # sound to the default device (not hw:1,0)
Wiring diagram: speaker.pins()     All commands: speaker.help()
"""
import hashlib
import math
import os
import struct
import subprocess
import tempfile
import time
import wave

import _core

# Like in the old code: --audio-device=alsa/hw:1,0 (USB sound card or the 3.5 mm jack)
_device = "hw:1,0"
_proc = None
CACHE = os.path.join(tempfile.gettempdir(), "speaker_cache")


def set_device(name):
    """Where the sound goes: "hw:1,0", "hw:0,0" ... or None — the default device. List: speaker.devices()."""
    global _device
    _device = name


def devices():
    """Show the Raspberry Pi's sound devices (cards)."""
    if _core.has_program("aplay"):
        print(subprocess.run(["aplay", "-l"], capture_output=True, text=True).stdout)
    else:
        print("The aplay program is missing (sudo apt install alsa-utils)")


def _command(path, device):
    plug = device.replace("hw:", "plughw:") if device else None
    if _core.has_program("mpv"):
        cmd = ["mpv", "--no-video", "--really-quiet"]
        if device:
            cmd.append("--audio-device=alsa/" + device)
        return cmd + [path]
    if _core.has_program("cvlc"):
        cmd = ["cvlc", "--play-and-exit", "--quiet"]
        if plug:
            cmd += ["--aout=alsa", "--alsa-audio-device=" + plug]
        return cmd + [path]
    if _core.has_program("mpg123") and path.lower().endswith(".mp3"):
        return ["mpg123", "-q"] + (["-a", plug] if plug else []) + [path]
    if _core.has_program("aplay") and path.lower().endswith(".wav"):
        return ["aplay", "-q"] + (["-D", plug] if plug else []) + [path]
    raise RuntimeError("Nothing to play sound with. Install a player: sudo apt install mpv")


def play(path, wait=True):
    """Play a file. wait=False — play in the background (stop it: speaker.stop())."""
    global _proc
    if not os.path.exists(path):
        raise FileNotFoundError("File %s not found" % path)
    stop()
    devices_to_try = [_device, None] if _device else [None]
    for dev in devices_to_try:
        _proc = subprocess.Popen(_command(path, dev), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if not wait:
            time.sleep(0.3)  # if the device is wrong, the player exits with an error right away
            if _proc.poll() not in (None, 0):
                continue
            return
        try:
            code = _proc.wait()
        except KeyboardInterrupt:
            stop()
            raise
        if code == 0:
            return
    print("Couldn't play %s. Check the device: speaker.devices(), speaker.set_device(...)" % path)


def stop():
    """Stop the sound."""
    global _proc
    if _proc is not None and _proc.poll() is None:
        _proc.terminate()
        try:
            _proc.wait(2)
        except subprocess.TimeoutExpired:
            _proc.kill()
    _proc = None


def is_playing():
    """Is anything playing right now (True / False)."""
    return _proc is not None and _proc.poll() is None


def wait():
    """Wait until whatever was started with wait=False finishes."""
    if _proc is not None:
        _proc.wait()


def _cached(name):
    os.makedirs(CACHE, exist_ok=True)
    return os.path.join(CACHE, name)


def say(text, lang="en", wait=True):
    """Say the text with the Google voice (needs internet). Without internet — the espeak voice. lang: "en", "ru"..."""
    key = hashlib.md5(("%s|%s" % (lang, text)).encode("utf-8")).hexdigest()
    mp3 = _cached(key + ".mp3")
    if not os.path.exists(mp3):
        try:
            from gtts import gTTS
            gTTS(text=str(text), lang=lang).save(mp3)
        except Exception as e:
            if os.path.exists(mp3):
                os.remove(mp3)
            print("Google voice is not available (%s), speaking with espeak." % type(e).__name__)
            say_offline(text, lang, wait)
            return
    play(mp3, wait)


def say_offline(text, lang="en", wait=True):
    """Say the text without internet (espeak-ng robot voice). Install: sudo apt install espeak-ng."""
    prog = "espeak-ng" if _core.has_program("espeak-ng") else ("espeak" if _core.has_program("espeak") else None)
    if prog is None:
        raise RuntimeError("espeak-ng is missing. Install it: sudo apt install espeak-ng")
    wav = _cached("espeak.wav")
    subprocess.run([prog, "-v", lang, "-w", wav, str(text)], check=False)
    play(wav, wait)


def tone(freq=440, seconds=0.5, wait=True):
    """Play a pure tone of freq Hz (no file)."""
    path = _cached("tone_%d_%d.wav" % (int(freq), int(seconds * 1000)))
    if not os.path.exists(path):
        rate = 44100
        n = int(rate * seconds)
        with wave.open(path, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(rate)
            fade = int(rate * 0.01)
            frames = bytearray()
            for i in range(n):
                k = min(1.0, i / fade, (n - i) / fade) if fade else 1.0  # no clicks at the edges
                frames += struct.pack("<h", int(20000 * k * math.sin(2 * math.pi * freq * i / rate)))
            w.writeframes(bytes(frames))
    play(path, wait)


def beep():
    """A short beep."""
    tone(1000, 0.15)


def volume(percent):
    """Volume 0..100 % (through amixer)."""
    card = None
    if _device and ":" in _device:
        card = _device.split(":")[1].split(",")[0]
    for control in ("PCM", "Speaker", "Master", "Headphone", "Digital"):
        cmd = ["amixer", "-q"] + (["-c", card] if card else []) + ["sset", control, "%d%%" % percent]
        if subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0:
            return True
    print("Couldn't change the volume. Try alsamixer in the terminal.")
    return False


def pins():
    """Show how to connect the sound."""
    _core.show_pins("Speaker", [
        ("USB sound card", "any USB port  (usually hw:1,0 — like in the old code)"),
        ("speaker with a 3.5 mm cable", "the Raspberry Pi headphone jack (not on Pi 5)"),
        ("I2S amplifier MAX98357A: BCLK", _core.only_pin(18)),
        ("I2S amplifier MAX98357A: LRC", _core.only_pin(19)),
        ("I2S amplifier MAX98357A: DIN", _core.only_pin(21)),
        ("MAX98357A: VIN / GND", _core.V5 + " / GND"),
    ], [
        "A speaker is never wired straight to a GPIO — you need an amplifier or a USB sound card.",
        "For the MAX98357A add to /boot/firmware/config.txt: dtoverlay=max98357a and reboot.",
        "Find the device number: speaker.devices(), then speaker.set_device('hw:CARD,0').",
        "Programs you need: sudo apt install mpv espeak-ng",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
