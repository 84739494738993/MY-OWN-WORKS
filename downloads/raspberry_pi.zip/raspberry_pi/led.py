"""
LED.
    import led
    led.on(17)            # turn on the LED on GPIO17
    led.blink(17, 5)      # blink 5 times
    led.brightness(17, 30)  # brightness 30 %
Wiring diagram: led.pins()     All commands: led.help()
"""
import time

import _core

MORSE = {
    "A": ".-", "B": "-...", "C": "-.-.", "D": "-..", "E": ".", "F": "..-.", "G": "--.", "H": "....",
    "I": "..", "J": ".---", "K": "-.-", "L": ".-..", "M": "--", "N": "-.", "O": "---", "P": ".--.",
    "Q": "--.-", "R": ".-.", "S": "...", "T": "-", "U": "..-", "V": "...-", "W": ".--", "X": "-..-",
    "Y": "-.--", "Z": "--..", "0": "-----", "1": ".----", "2": "..---", "3": "...--", "4": "....-",
    "5": ".....", "6": "-....", "7": "--...", "8": "---..", "9": "----.",
    "А": ".-", "Б": "-...", "В": ".--", "Г": "--.", "Д": "-..", "Е": ".", "Ё": ".", "Ж": "...-",
    "З": "--..", "И": "..", "Й": ".---", "К": "-.-", "Л": ".-..", "М": "--", "Н": "-.", "О": "---",
    "П": ".--.", "Р": ".-.", "С": "...", "Т": "-", "У": "..-", "Ф": "..-.", "Х": "....", "Ц": "-.-.",
    "Ч": "---.", "Ш": "----", "Щ": "--.-", "Ъ": "--.--", "Ы": "-.--", "Ь": "-..-", "Э": "..-..",
    "Ю": "..--", "Я": ".-.-",
}


def on(pin):
    """Turn the LED on."""
    _core.write(pin, 1)


def off(pin):
    """Turn the LED off (also stops blinking and smooth effects on this pin)."""
    _core.stop_task(pin)
    _core.write(pin, 0)


def toggle(pin):
    """Toggle: if it was on it goes off, if it was off it goes on."""
    _core.write(pin, 0 if is_on(pin) else 1)


def is_on(pin):
    """Is the LED on right now (True / False)."""
    return bool(_core.level(pin))


def on_for(pin, seconds):
    """Turn on for seconds seconds, then off."""
    on(pin)
    time.sleep(seconds)
    off(pin)


def blink(pin, times=3, speed=0.5):
    """Blink times times. speed — how many seconds it's on and off. The program waits until the blinking ends."""
    _core.stop_task(pin)
    for _ in range(times):
        _core.write(pin, 1)
        time.sleep(speed)
        _core.write(pin, 0)
        time.sleep(speed)


def start_blink(pin, speed=0.5):
    """Blink in the background non-stop while the program keeps going. Stop it: led.off(pin)."""
    _core.check_pin(pin)

    def loop(ev):
        while not ev.is_set():
            _core.write(pin, 1)
            if ev.wait(speed):
                break
            _core.write(pin, 0)
            ev.wait(speed)

    _core.start_task(pin, loop)


def brightness(pin, percent):
    """Brightness from 0 to 100 %. Holds while the program runs (Ctrl+C — exit)."""
    percent = max(0, min(100, percent))
    if percent >= 100:
        on(pin)
    elif percent <= 0:
        off(pin)
    else:
        # the eye sees brightness non-linearly: squaring makes 50 % look like half "to the eye"
        _core.pwm(pin, 200, (percent / 100.0) ** 2 * 100)


def get_brightness(pin):
    """Current brightness 0..100 %."""
    duty = _core.pwm_duty(pin)
    if duty is None:
        return 100 if is_on(pin) else 0
    return round((duty / 100.0) ** 0.5 * 100)


def fade_in(pin, seconds=1.0):
    """Fade in over seconds seconds."""
    _core.stop_task(pin)
    _fade(pin, 0, 100, seconds)
    on(pin)


def fade_out(pin, seconds=1.0):
    """Fade out over seconds seconds."""
    _core.stop_task(pin)
    _fade(pin, get_brightness(pin), 0, seconds)
    off(pin)


def _fade(pin, start, end, seconds, ev=None):
    steps = max(1, int(seconds * 50))
    for i in range(steps + 1):
        p = start + (end - start) * i / steps
        _core.pwm(pin, 200, (p / 100.0) ** 2 * 100)
        if _core.sleep(seconds / steps, ev):
            return True
    return False


def pulse(pin, times=3, speed=1.0):
    """\"Breathing\": fade in and out times times. speed — seconds per breath."""
    _core.stop_task(pin)
    for _ in range(times):
        _fade(pin, 0, 100, speed / 2)
        _fade(pin, 100, 0, speed / 2)
    off(pin)


def start_pulse(pin, speed=2.0):
    """\"Breathe\" in the background non-stop. Stop it: led.off(pin)."""
    _core.check_pin(pin)

    def loop(ev):
        while not ev.is_set():
            if _fade(pin, 0, 100, speed / 2, ev) or _fade(pin, 100, 0, speed / 2, ev):
                break

    _core.start_task(pin, loop)


def morse(pin, text, speed=0.15):
    """Send text in Morse code (Latin, Cyrillic, digits). speed — length of a dot in seconds."""
    _core.stop_task(pin)
    for word in text.upper().split():
        for ch in word:
            for sign in MORSE.get(ch, ""):
                _core.write(pin, 1)
                time.sleep(speed if sign == "." else speed * 3)
                _core.write(pin, 0)
                time.sleep(speed)
            time.sleep(speed * 2)  # pause between letters (3 dots in total)
        time.sleep(speed * 4)  # pause between words (7 dots in total)


def pins(pin=None):
    """Show how to wire the LED."""
    _core.show_pins("LED", [
        ("long leg (+)", "220 Ω resistor -> " + _core.any_pin(pin)),
        ("short leg (-)", _core.GND),
    ], [
        "Without a resistor the LED and the pin can burn out.",
        "You write the pin number in the command: led.on(17) means GPIO17.",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
