"""
Button.
    import button
    if button.is_pressed(4): print("pressed")
    button.wait_press(4)                  # wait for a press
    button.on_press(4, lambda: led.toggle(17))   # what to do on every press
Wiring diagram: button.pins()     All commands: button.help()
"""
import _core
from _digital import Digital

# The button connects the pin to GND; the internal pull-up to 3.3 V turns on by itself (like in the old code)
_d = Digital("button", active=0, pull="up")


def setup(pin, to="gnd"):
    """How the button is wired: to="gnd" (default) or to="3.3v" (the second leg goes to 3.3 V)."""
    if str(to).lower() in ("gnd", "0", "ground"):
        _d.setup(pin, active=0, pull="up")
    else:
        _d.setup(pin, active=1, pull="down")


def is_pressed(pin):
    """Is the button pressed right now (True / False)."""
    return _d.is_on(pin)


def wait_press(pin, timeout=None):
    """Wait for a press. timeout — the most seconds to wait. Returns True, or False (didn't happen)."""
    return _d.wait(pin, True, timeout)


def wait_release(pin, timeout=None):
    """Wait until the button is released."""
    return _d.wait(pin, False, timeout)


def wait_click(pin, timeout=None):
    """Wait for a full click: pressed and released."""
    if not _d.wait(pin, True, timeout):
        return False
    return _d.wait(pin, False)


def on_press(pin, func):
    """Call func() on every press (the program keeps going meanwhile). func=None — stop."""
    _d.on(pin, func, True)


def on_release(pin, func):
    """Call func() every time the button is released."""
    _d.on(pin, func, False)


def on_hold(pin, func, seconds=1.0):
    """Call func() if the button is held longer than seconds seconds (long press)."""
    _d.on_hold(pin, func, seconds)


def stop(pin):
    """Stop watching the button (cancels on_press / on_release / on_hold)."""
    _d.stop(pin)


def hold_time(pin, timeout=None):
    """Wait for a press and return how many seconds the button was held."""
    return _d.hold_time(pin, timeout)


def clicks(pin, gap=0.4, timeout=None):
    """Wait for a series of clicks and return how many: 1 — single, 2 — double, 3 — triple..."""
    return _d.clicks(pin, gap, timeout)


def count(pin, seconds=5):
    """Count how many times it was pressed within seconds seconds."""
    return _d.count(pin, seconds)


def toggled(pin):
    """Toggle switch: every press flips the state. Returns True (on) or False (off)."""
    return _d.toggled(pin)


def pins(pin=None):
    """Show how to wire the button."""
    _core.show_pins("Button", [
        ("leg 1", _core.any_pin(pin)),
        ("leg 2", _core.GND),
    ], [
        "No resistor needed — the internal pull-up turns on by itself.",
        "On a 4-leg button the legs are connected in pairs: use two legs on the diagonal.",
        "Button module with 3 contacts: S -> GPIO, '+' -> 3.3V, '-' -> GND.",
        "If the second leg goes to 3.3V instead of GND: button.setup(pin, to='3.3v').",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
