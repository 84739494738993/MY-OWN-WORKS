"""
DHT22 / AM2302 temperature and humidity sensor (white, more accurate than DHT11).
    import dht22
    print(dht22.temperature(4))      # °C (with tenths, can be below zero)
    print(dht22.humidity(4))         # %
    t, h = dht22.read(4)             # everything at once
    dht22.show(4)                    # print it nicely
Wiring diagram: dht22.pins()     All commands: dht22.help()
"""
import _core
import _dht


def read(pin):
    """Return (temperature °C, humidity %). If the sensor didn't answer — (None, None)."""
    return _dht.read(pin, 22)


def temperature(pin):
    """Temperature in °C (or None)."""
    return read(pin)[0]


def humidity(pin):
    """Air humidity in % (or None)."""
    return read(pin)[1]


def show(pin):
    """Print the temperature and humidity."""
    _dht.show(pin, 22)


def pins(pin=None):
    """Show how to wire the DHT22."""
    _dht.pins(pin, 22)


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
