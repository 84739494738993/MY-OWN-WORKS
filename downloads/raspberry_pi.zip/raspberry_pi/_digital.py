"""
Shared logic for sensors with a digital 0/1 output
(button, touch button, motion, water, obstacle sensors...).
You don't need to import it yourself.
"""
import time

import _core


class Digital:
    def __init__(self, key, active=0, pull="up"):
        self.key = key          # name for background tasks
        self.active = active    # which level means "triggered": 0 or 1
        self.pull = pull        # pull-up: "up", "down" or None
        self.cfg = {}           # special settings for individual pins

    def setup(self, pin, active=None, pull="keep"):
        _core.check_pin(pin)
        a, p = self.cfg.get(pin, (self.active, self.pull))
        if active is not None:
            a = 1 if active else 0
        if pull != "keep":
            p = pull
        self.cfg[pin] = (a, p)

    def is_on(self, pin):
        a, p = self.cfg.get(pin, (self.active, self.pull))
        return _core.read(pin, p) == a

    def wait(self, pin, state=True, timeout=None, settle=0.02):
        """Wait until the sensor is in state. True — it happened, False — the time ran out."""
        _core.check_pin(pin)
        end = None if timeout is None else time.time() + timeout
        while True:
            if self.is_on(pin) == state:
                if not settle:
                    return True
                time.sleep(settle)  # debounce
                if self.is_on(pin) == state:
                    return True
            if end is not None and time.time() >= end:
                return False
            time.sleep(0.005)

    def on(self, pin, func, state=True, debounce=0.03):
        """Call func() every time the sensor goes into state. func=None — stop."""
        _core.check_pin(pin)
        key = (self.key, pin, state)
        if func is None:
            _core.stop_task(key)
            return
        _core.watch(key, lambda: self.is_on(pin),
                    on_true=func if state else None,
                    on_false=None if state else func,
                    debounce=debounce)

    def on_hold(self, pin, func, seconds=1.0):
        """Call func() once when the sensor has been held for seconds seconds."""
        _core.check_pin(pin)

        def loop(ev):
            while not ev.is_set():
                if self.is_on(pin):
                    t0 = time.time()
                    fired = False
                    while self.is_on(pin) and not ev.is_set():
                        if not fired and time.time() - t0 >= seconds:
                            fired = True
                            try:
                                func()
                            except Exception as e:
                                print("[error in your function] %s" % e)
                        ev.wait(0.01)
                ev.wait(0.01)

        _core.start_task((self.key, pin, "hold"), loop)

    def stop(self, pin):
        for kind in (True, False, "hold", "toggle"):
            _core.stop_task((self.key, pin, kind))

    def hold_time(self, pin, timeout=None):
        if not self.wait(pin, True, timeout):
            return 0.0
        t0 = time.time()
        self.wait(pin, False)
        return round(time.time() - t0, 2)

    def count(self, pin, seconds):
        n = 0
        end = time.time() + seconds
        prev = self.is_on(pin)
        while time.time() < end:
            cur = self.is_on(pin)
            if cur and not prev:
                n += 1
                time.sleep(0.03)
            prev = cur
            time.sleep(0.005)
        return n

    def clicks(self, pin, gap=0.4, timeout=None):
        if not self.wait(pin, True, timeout):
            return 0
        n = 0
        while True:
            self.wait(pin, False)
            n += 1
            if not self.wait(pin, True, gap):
                return n

    def toggled(self, pin):
        key = (self.key, pin, "toggle")
        if not _core.task_running(key):
            self._toggle_state = getattr(self, "_toggle_state", {})
            self._toggle_state.setdefault(pin, False)

            def flip():
                self._toggle_state[pin] = not self._toggle_state[pin]

            _core.watch(key, lambda: self.is_on(pin), on_true=flip)
        return self._toggle_state[pin]
