"""
PIR motion sensor HC-SR501 (motion_sensor in the old code).
    import motion
    if motion.is_motion(18): print("Someone is here!")
    motion.wait_motion(18)                 # wait for motion
    motion.on_motion(18, lambda: led.on(17))
Wiring diagram: motion.pins()     All commands: motion.help()
"""
import time

import _core
from _digital import Digital

# OUT output: 1 — there is motion
_d = Digital("motion", active=1, pull="down")
_last = {}


def is_motion(pin):
    """Is there motion right now (True / False)."""
    v = _d.is_on(pin)
    if v:
        _last[pin] = time.time()
    return v


def wait_motion(pin, timeout=None):
    """Wait for motion. Returns True, or False (the timeout ran out)."""
    ok = _d.wait(pin, True, timeout, settle=0)
    if ok:
        _last[pin] = time.time()
    return ok


def wait_still(pin, timeout=None):
    """Wait until the motion ends."""
    return _d.wait(pin, False, timeout, settle=0)


def on_motion(pin, func):
    """Call func() every time motion starts (the program keeps going). func=None — stop."""
    def wrapper():
        _last[pin] = time.time()
        func()
    _d.on(pin, wrapper if func else None, True, debounce=0)


def on_still(pin, func):
    """Call func() when the motion has ended."""
    _d.on(pin, func, False, debounce=0)


def stop(pin):
    """Stop watching (cancels on_motion / on_still)."""
    _d.stop(pin)


def seconds_since_motion(pin):
    """How many seconds have passed since the last detected motion (None — none yet)."""
    if is_motion(pin):
        return 0.0
    t = _last.get(pin)
    return None if t is None else round(time.time() - t, 1)


def warm_up(seconds=30):
    """Wait for the sensor to "warm up" after power-on (for the first ~30 s it triggers by itself)."""
    for s in range(int(seconds), 0, -1):
        print("\rMotion sensor warming up... %2d s " % s, end="", flush=True)
        time.sleep(1)
    print("\rMotion sensor ready.                 ")


def pins(pin=None):
    """Show how to wire the motion sensor."""
    _core.show_pins("PIR motion sensor HC-SR501", [
        ("VCC", _core.V5),
        ("OUT (middle)", _core.any_pin(pin)),
        ("GND", _core.GND),
    ], [
        "Powered from 5V, but the OUT output gives 3.3 V — that's safe for the pin.",
        "Orange screws: Sx — sensitivity (range), Tx — how many seconds to hold the signal.",
        "Jumper H — the signal holds while there's motion (handier), L — a single pulse.",
        "After power-on the sensor needs ~30-60 s: motion.warm_up().",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
