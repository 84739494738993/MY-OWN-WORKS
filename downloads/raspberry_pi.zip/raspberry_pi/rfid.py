"""
RC522 RFID reader (13.56 MHz cards and key fobs).
    import rfid
    print(rfid.read_id())          # wait for a card and return its number
    rfid.write("Hello")             # write text to a card (up to 48 bytes)
    print(rfid.read_text())        # read the text from a card
    rfid.remember("Alice")         # remember a card under a name
    print(rfid.who())              # whose card is this
Wiring diagram: rfid.pins()     All commands: rfid.help()
"""
import threading
import time

import _core

_rst = 25          # RST: GPIO25 (phys. pin 22), like in the standard wiring
_device = 0        # SDA -> CE0 (GPIO8). If SDA is on CE1 (GPIO7) — connect(device=1)
_reader = None
_lock = threading.RLock()
KEY = [0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF]   # factory card key
BLOCKS = [8, 9, 10]                          # the text is written here (3 blocks of 16 bytes)
TRAILER = 11
CARDS_FILE = "rfid_cards.json"


def connect(rst=25, device=0):
    """Set the RST pin and which CE SDA uses: device=0 (GPIO8) or 1 (GPIO7)."""
    global _rst, _device, _reader
    _rst, _device = _core.check_pin(rst), device
    _reader = None


def _r():
    global _reader
    if _reader is None:
        _core.gpio()  # BCM numbering — before creating the reader
        _core.spi(0, _device).close()  # check that SPI is on (a clear error)
        from mfrc522 import MFRC522
        _reader = MFRC522(bus=0, device=_device, pin_rst=_rst)
    return _reader


def _uid_to_num(uid):
    n = 0
    for i in range(5):
        n = n * 256 + uid[i]
    return n


def _select():
    r = _r()
    status, _ = r.MFRC522_Request(r.PICC_REQIDL)
    if status != r.MI_OK:
        return None, None
    status, uid = r.MFRC522_Anticoll()
    if status != r.MI_OK:
        return None, None
    return _uid_to_num(uid), uid


def check():
    """Is there a card at the reader right now? Returns the card number or None (doesn't wait)."""
    with _lock:
        card, _ = _select()
        return card


def _wait(func, timeout):
    end = None if timeout is None else time.time() + timeout
    while True:
        result = func()
        if result is not None:
            return result
        if end is not None and time.time() >= end:
            return None
        time.sleep(0.05)


def read_id(timeout=None):
    """Wait for a card and return its number. timeout — the most seconds to wait (otherwise returns None)."""
    return _wait(check, timeout)


def _read_now():
    with _lock:
        r = _r()
        card, uid = _select()
        if card is None:
            return None
        r.MFRC522_SelectTag(uid)
        data = []
        if r.MFRC522_Auth(r.PICC_AUTHENT1A, TRAILER, KEY, uid) == r.MI_OK:
            for b in BLOCKS:
                block = r.MFRC522_Read(b)
                if block:
                    data += block
        r.MFRC522_StopCrypto1()
        text = bytes(data).rstrip(b"\x00 ").decode("utf-8", errors="ignore")
        return card, text


def read(timeout=None):
    """Wait for a card and return (number, text)."""
    res = _wait(_read_now, timeout)
    return res if res else (None, None)


def read_text(timeout=None):
    """Wait for a card and return only its text."""
    return read(timeout)[1]


def _write_now(payload):
    with _lock:
        r = _r()
        card, uid = _select()
        if card is None:
            return None
        r.MFRC522_SelectTag(uid)
        status = r.MFRC522_Auth(r.PICC_AUTHENT1A, TRAILER, KEY, uid)
        r.MFRC522_Read(TRAILER)
        if status == r.MI_OK:
            for i, b in enumerate(BLOCKS):
                r.MFRC522_Write(b, payload[i * 16:(i + 1) * 16])
        r.MFRC522_StopCrypto1()
        return card if status == r.MI_OK else None


def write(text, timeout=None):
    """Wait for a card and write text to it (up to 48 bytes: ~48 Latin or ~24 Cyrillic letters). Returns the card number."""
    data = str(text).encode("utf-8")
    while len(data) > 48:  # trim without cutting multi-byte letters in half
        text = str(text)[:-1]
        data = text.encode("utf-8")
    payload = bytearray(data.ljust(48, b" "))
    return _wait(lambda: _write_now(payload), timeout)


def wait_remove(timeout=None):
    """Wait until the card is taken away from the reader."""
    misses = [0]

    def gone():
        misses[0] = misses[0] + 1 if check() is None else 0
        return misses[0] >= 3

    return _core.wait_for(gone, timeout, 0.05)


def on_card(func):
    """Call func(card_number) every time a card is brought up (the program keeps going)."""

    def loop(ev):
        last, misses = None, 0
        while not ev.is_set():
            card = check()
            if card is None:
                misses += 1
                if misses >= 3:
                    last = None
            else:
                misses = 0
                if card != last:
                    last = card
                    try:
                        func(card)
                    except Exception as e:
                        print("[error in your function] %s" % e)
            ev.wait(0.1)

    _core.start_task("rfid", loop)


def stop():
    """Stop watching (cancels on_card)."""
    _core.stop_task("rfid")


def cards():
    """All remembered cards: {number: name}."""
    return _core.load_json(CARDS_FILE, {})


def remember(name, timeout=None):
    """Bring a card up — it is remembered under the name name (saved to rfid_cards.json)."""
    print("Bring the card for \"%s\"..." % name)
    card = read_id(timeout)
    if card is None:
        return None
    data = cards()
    data[str(card)] = name
    _core.save_json(CARDS_FILE, data)
    print("Remembered: %s -> %s" % (card, name))
    wait_remove(3)
    return card


def forget(name):
    """Forget a card by name."""
    data = {k: v for k, v in cards().items() if v != name}
    _core.save_json(CARDS_FILE, data)


def name_of(card):
    """Name of a remembered card by its number (or None)."""
    return cards().get(str(card))


def who(timeout=None):
    """Wait for a card and return the owner's name (or None if the card is unknown / time ran out)."""
    card = read_id(timeout)
    return None if card is None else name_of(card)


def is_known(card):
    """Is the card remembered? (True / False)."""
    return name_of(card) is not None


def pins():
    """Show how to wire the RC522."""
    cs = 8 if _device == 0 else 7
    _core.show_pins("RC522 RFID reader (SPI)", [
        ("SDA (SS)", _core.only_pin(cs)),
        ("SCK", _core.only_pin(11)),
        ("MOSI", _core.only_pin(10)),
        ("MISO", _core.only_pin(9)),
        ("IRQ", "not connected"),
        ("GND", _core.GND),
        ("RST", _core.any_pin(_rst)),
        ("3.3V", _core.V3 + "  (NOT 5V — it will burn!)"),
    ], [
        "Turn on SPI: sudo raspi-config -> Interface Options -> SPI -> Yes, then reboot.",
        "Another RST pin: rfid.connect(rst=22). SDA on GPIO7: rfid.connect(device=1).",
        "The matrix and display use SPI too: each has its own CE (GPIO8 or GPIO7).",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
