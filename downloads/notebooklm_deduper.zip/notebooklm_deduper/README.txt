INSTALLATION

1. Unzip the archive - you will get the notebooklm_deduper folder.
2. Open Chrome and go to: chrome://extensions
3. Turn on "Developer mode" in the top right corner.
4. Click "Load unpacked" and select the notebooklm_deduper folder.
5. Open your NotebookLM notebook and reload the page.

USAGE

1. Click the extension icon.
2. Click "Find duplicates".
3. Check the list.
4. Click "Remove found duplicates" and confirm.

Sources are compared by link, or by title when there is no link
(case-insensitive, extra spaces ignored).
