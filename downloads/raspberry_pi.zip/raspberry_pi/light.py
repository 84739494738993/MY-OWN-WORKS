"""
Light sensor — photoresistor (foto in the old code).
    import light
    if light.is_dark(24): led.on(17)
    print(light.level(24))      # brightness 0..100 %
Three ways to wire it (choose one at the start of the program):
    light.mode("rc")       — photoresistor + capacitor, like in the old code (default)
    light.mode("digital")  — a module with a DO output (threshold set with the screw on the module)
    light.mode("adc")      — a module with an AO output through an ADC (adc.py), the ADC channel number instead of a pin
Wiring diagram: light.pins()     All commands: light.help()
"""
import math

import _core

_mode = "rc"
_threshold = {}   # pin -> "dark" threshold (in raw units)
_cal = _core.load_json("light_calibration.json", {})  # pin -> [bright, dark]
DEFAULT_RC_THRESHOLD = 0.01  # like in the old code: under 0.01 s means bright


def mode(m):
    """Wiring mode: "rc" (default), "digital" or "adc"."""
    global _mode
    if m not in ("rc", "digital", "adc"):
        raise ValueError('Mode can be "rc", "digital" or "adc"')
    _mode = m


def raw(pin):
    """Raw value: rc — charge time in seconds, adc — number from the ADC, digital — 0 or 1.
    In every mode: a bigger value = darker."""
    if _mode == "rc":
        return round(_core.rc_time(pin, 1.0), 5)
    if _mode == "digital":
        return _core.read(pin, "up")  # the module outputs 1 when it's dark
    import adc
    return adc.read(pin)


def level(pin):
    """Light level 0..100 % (100 — very bright). More accurate after light.calibrate(pin)."""
    v = raw(pin)
    if _mode == "digital":
        return 0 if v else 100
    cal = _cal.get(str(pin))
    if _mode == "rc":
        bright, dark = cal if cal else (0.0005, 0.5)
        v, bright, dark = (math.log(max(x, 1e-5)) for x in (v, bright, dark))
    else:
        import adc
        bright, dark = cal if cal else (0, adc.max_value())
    if dark == bright:
        return 50
    p = 100 * (dark - v) / (dark - bright)
    return int(max(0, min(100, p)))


def set_threshold(pin, value):
    """Set the "dark" threshold in raw() units. For example light.set_threshold(24, 0.02)."""
    _threshold[pin] = value


def is_dark(pin):
    """Is it dark right now (True / False)."""
    v = raw(pin)
    if _mode == "digital":
        return bool(v)
    if pin in _threshold:
        return v >= _threshold[pin]
    cal = _cal.get(str(pin))
    if cal:
        bright, dark = cal
        mid = math.sqrt(bright * dark) if _mode == "rc" else (bright + dark) / 2  # rc: logarithmic middle
        return v >= mid if dark >= bright else v <= mid
    if _mode == "rc":
        return v >= DEFAULT_RC_THRESHOLD
    import adc
    return v >= adc.max_value() / 2


def is_light(pin):
    """Is it bright right now (True / False)."""
    return not is_dark(pin)


def wait_dark(pin, timeout=None):
    """Wait until it gets dark. Returns True, or False (time ran out)."""
    return _core.wait_for(lambda: is_dark(pin), timeout, 0.05)


def wait_light(pin, timeout=None):
    """Wait until it gets bright."""
    return _core.wait_for(lambda: is_light(pin), timeout, 0.05)


def on_dark(pin, func):
    """Call func() when it gets dark (the program keeps going)."""
    _core.watch(("light", pin, "dark"), lambda: is_dark(pin), on_true=func, interval=0.1, debounce=0.2)


def on_light(pin, func):
    """Call func() when it gets bright."""
    _core.watch(("light", pin, "light"), lambda: is_dark(pin), on_false=func, interval=0.1, debounce=0.2)


def stop(pin):
    """Stop watching (cancels on_dark / on_light)."""
    _core.stop_task(("light", pin, "dark"))
    _core.stop_task(("light", pin, "light"))


def calibrate(pin):
    """Tune the sensor to your room: measure "bright" and "dark". Saved to a file."""
    if _mode == "digital":
        print("In digital mode the threshold is set with the screw on the module itself.")
        return
    input("Light up the sensor (normal brightness) and press Enter...")
    bright = sum(raw(pin) for _ in range(5)) / 5
    input("Cover the sensor with your finger (dark) and press Enter...")
    dark = sum(raw(pin) for _ in range(5)) / 5
    _cal[str(pin)] = [bright, dark]
    path = _core.save_json("light_calibration.json", _cal)
    print("Done: bright=%.5f, dark=%.5f. Saved to %s" % (bright, dark, path))


def pins(pin=None):
    """Show how to wire the light sensor (for the current mode)."""
    if _mode == "rc":
        rows = [
            ("photoresistor, leg 1", _core.V3),
            ("photoresistor, leg 2", "1 kΩ resistor -> " + _core.any_pin(pin)),
            ("1 µF capacitor (+)", "to the same GPIO (after the resistor)"),
            ("capacitor (-)", _core.GND),
        ]
        notes = ["rc mode (default). Threshold: light.set_threshold(pin, 0.02) or light.calibrate(pin)."]
    elif _mode == "digital":
        rows = [("DO", _core.any_pin(pin)), ("VCC", _core.V3), ("GND", _core.GND)]
        notes = ["digital mode. Turn the screw on the module for the \"dark\" threshold until its LED blinks."]
    else:
        rows = [("AO", "ADC input, channel %s (see adc.pins())" % ("N" if pin is None else pin)),
                ("VCC", _core.V3), ("GND", _core.GND)]
        notes = ["adc mode: in commands write the ADC channel number instead of a pin: light.level(0)."]
    _core.show_pins("Light sensor (photoresistor)", rows, notes + [
        "Change the wiring mode: light.mode('rc' | 'digital' | 'adc').",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
