# Example: a button on GPIO4 turns an LED on GPIO17 on and off.
# Run it on the Raspberry Pi:  python3 example.py
import button
import led

led.pins(17)       # shows how to wire the LED
button.pins(4)     # shows how to wire the button

button.on_press(4, lambda: led.toggle(17))
print("Press the button. Ctrl+C — exit.")
# The program won't exit by itself: while we watch the button it waits for Ctrl+C.
