"""
Potentiometer (rotary knob, potencyometr in the old code).
    import potentiometer as pot
    print(pot.percent(25))            # 0..100 %
    servo.angle(18, pot.value(25, 0, 180))   # the knob controls a servo
Two ways to wire it:
    pot.mode("rc")   — with a capacitor, like in the old code (default)
    pot.mode("adc")  — through an ADC (adc.py), the ADC channel number instead of a pin (more accurate and faster)
Wiring diagram: potentiometer.pins()     All commands: potentiometer.help()
"""
import _core

_mode = "rc"
_cal = _core.load_json("pot_calibration.json", {})   # pin -> [min, max]
_seen = {}   # pin -> [min, max] seen while running (auto-tuning)


def mode(m):
    """Wiring mode: "rc" (default) or "adc"."""
    global _mode
    if m not in ("rc", "adc"):
        raise ValueError('Mode can be "rc" or "adc"')
    _mode = m


def raw(pin):
    """Raw value: rc — charge time in seconds, adc — number from the ADC."""
    if _mode == "rc":
        return round(_core.rc_time(pin, 0.5), 5)
    import adc
    return adc.read(pin)


def _range(pin, v):
    cal = _cal.get(str(pin))
    if cal:
        return cal
    if _mode == "adc":
        import adc
        return [0, adc.max_value()]
    # rc without calibration: adapt to what we've already seen (turn the knob from end to end)
    lo, hi = _seen.get(pin, [v, v])
    lo, hi = min(lo, v), max(hi, v)
    _seen[pin] = [lo, hi]
    return [lo, hi]


def percent(pin):
    """Knob position 0..100 %."""
    v = raw(pin)
    lo, hi = _range(pin, v)
    if hi == lo:
        return 0
    return int(max(0, min(100, round(100.0 * (v - lo) / (hi - lo)))))


def value(pin, low=0, high=100):
    """Knob position mapped to the range low..high. For example value(25, 0, 180) for a servo."""
    return round(low + (high - low) * percent(pin) / 100.0)


def wait_change(pin, step=5, timeout=None):
    """Wait until the knob is turned by more than step %. Returns the new value (or None)."""
    start = percent(pin)
    result = []

    def changed():
        p = percent(pin)
        if abs(p - start) >= step:
            result.append(p)
            return True
        return False

    return result[-1] if _core.wait_for(changed, timeout, 0.05) else None


def on_change(pin, func, step=3):
    """Call func(percent) every time the knob is turned by more than step %."""

    def loop(ev):
        last = percent(pin)
        while not ev.is_set():
            p = percent(pin)
            if abs(p - last) >= step:
                last = p
                try:
                    func(p)
                except Exception as e:
                    print("[error in your function] %s" % e)
            ev.wait(0.05)

    _core.start_task(("pot", pin), loop)


def stop(pin):
    """Stop watching (cancels on_change)."""
    _core.stop_task(("pot", pin))


def calibrate(pin):
    """Remember the end positions of the knob. Saved to a file."""
    input("Turn the knob all the way LEFT and press Enter...")
    lo = sum(raw(pin) for _ in range(5)) / 5
    input("Turn the knob all the way RIGHT and press Enter...")
    hi = sum(raw(pin) for _ in range(5)) / 5
    _cal[str(pin)] = [lo, hi]
    path = _core.save_json("pot_calibration.json", _cal)
    print("Done: left=%s, right=%s. Saved to %s" % (lo, hi, path))


def pins(pin=None):
    """Show how to wire the potentiometer (for the current mode)."""
    if _mode == "rc":
        rows = [
            ("outer leg", _core.V3),
            ("middle leg", "1 kΩ resistor -> " + _core.any_pin(pin)),
            ("1 µF capacitor (+)", "to the same GPIO (after the resistor)"),
            ("capacitor (-)", _core.GND),
            ("other outer leg", "nowhere (not connected)"),
        ]
        notes = ["The 1 kΩ resistor is a must: in the end position the pin would be shorted to 3.3 V without it.",
                 "Without calibration, turn the knob from end to end once — the module learns the range by itself.",
                 "Exact tuning: potentiometer.calibrate(pin)."]
    else:
        rows = [
            ("outer leg", _core.V3),
            ("middle leg", "ADC input, channel %s (see adc.pins())" % ("N" if pin is None else pin)),
            ("other outer leg", _core.GND),
        ]
        notes = ["adc mode: in commands write the ADC channel number instead of a pin: potentiometer.percent(0)."]
    _core.show_pins("Potentiometer", rows, notes + ["Change the mode: potentiometer.mode('rc' | 'adc')."])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
