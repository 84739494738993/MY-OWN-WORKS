const o=".single-source-container";const j=aj=>new Promise(ak=>setTimeout(ak,aj));function ad(e){const V=e.querySelector('input[type="checkbox"][aria-label]');const i=e.querySelector(".source-title");return(V?.getAttribute("aria-label")||i?.textContent||"").trim();}
function ai(w){try{const g=new URL(w);g.hash="";if(g.hostname.includes("youtube.com")){const K=g.searchParams.get("v");if(K)return`https://www.youtube.com/watch?v=${K}`;}
if(g.hostname==="youtu.be"){return`https://www.youtube.com/watch?v=${g.pathname.slice(1)}`;}
["utm_source","utm_medium","utm_campaign","utm_term","utm_content","wbraid","gclid"].forEach(Y=>g.searchParams.delete(Y));return g.href.replace(/\/$/,"").toLocaleLowerCase();}catch{return"";}}
function y(e){const i=ad(e);const ac=[...e.querySelectorAll('a[href^="http"]')].map(m=>ai(m.href)).filter(m=>m&&!m.includes("notebooklm.google.com")&&!m.includes("notebook.google.com"));const g=ac[0]||"";const an=i.toLocaleLowerCase().replace(/\s+/g," ");return{key:g?`url:${g}`:`title:${an}`,title:i,url:g,method:g?"link":"title"};}
function R(){const af=document.querySelector(o);let f=af?.parentElement;while(f){const t=getComputedStyle(f);if(/auto|scroll/.test(t.overflowY)&&f.scrollHeight>f.clientHeight+10){return f;}
f=f.parentElement;}
return[...document.querySelectorAll("div")].filter(d=>d.querySelector(o)&&d.scrollHeight>d.clientHeight+10).sort((X,T)=>X.clientHeight-T.clientHeight)[0]||null;}
async function M(){const c=R();const v=[];const S=new Map();const z=()=>{for(const e of document.querySelectorAll(o)){const q=y(e);if(!q.title)continue;const aa=`${q.key}\n${q.title}`;const W=c?Math.round(e.getBoundingClientRect().top-c.getBoundingClientRect().top+c.scrollTop):Math.round(e.getBoundingClientRect().top);const N=`${aa}\n${W}`;if(!S.has(N)){S.set(N,true);v.push(q);}}};if(!c){z();return v;}
const Z=c.scrollTop;c.scrollTop=0;await j(350);let p=-1;while(c.scrollTop!==p){z();p=c.scrollTop;c.scrollTop=Math.min(c.scrollTop+Math.max(200,Math.floor(c.clientHeight*0.75)),c.scrollHeight-c.clientHeight);await j(300);}
z();c.scrollTop=Z;const P=[...document.querySelectorAll(o)].map(y).filter(d=>d.title);return P.length>=v.length?P:v;}
function J(l){const u=new Map();for(const d of l){if(!u.has(d.key))u.set(d.key,[]);u.get(d.key).push(d);}
return[...u.entries()].filter(([,s])=>s.length>1).map(([h,s])=>({key:h,...s[0],extra:s.length-1}));}
function A(f){if(!f)return false;const t=getComputedStyle(f);return t.display!=="none"&&t.visibility!=="hidden"&&f.getClientRects().length>0;}
function H(ab,ae,ag){return[...ab.querySelectorAll(ae)].find(f=>{const w=`${f.textContent||""} ${f.getAttribute("aria-label")||""}`.trim();return A(f)&&ag.test(w);});}
async function U(){for(let n=0;n<20;n++){const I=[...document.querySelectorAll("mat-dialog-container, [role='dialog']")].filter(A);const D=I[I.length-1];const B=D&&H(D,"button",/^(delete|remove|confirm deletion|удалить|подтвердить удаление|usuń)$/i);if(B){B.click();return;}
await j(150);}
throw new Error("Delete confirmation button not found");}
async function am(e){e.scrollIntoView({block:"center"});await j(250);const C=e.querySelector(".source-item-more-button, button[aria-label='More'], button[aria-label*='More options'], button[aria-label*='Ещё']");if(!C)throw new Error("Source menu button not found");C.click();let k=null;for(let n=0;n<20&&!k;n++){k=document.querySelector(".more-menu-delete-source-button");if(!A(k)){k=H(document,"button[role='menuitem'], [role='menuitem'], button",/remove source|delete source|удалить источник|usuń źródło/i);}
if(!k)await j(150);}
if(!k)throw new Error("Remove source command not found");k.click();await U();await j(1700);}
async function al(h){const c=R();if(c)c.scrollTop=0;await j(300);let p=-1;while(true){const e=[...document.querySelectorAll(o)].find(d=>y(d).key===h);if(e)return e;if(!c||c.scrollTop===p)return null;p=c.scrollTop;c.scrollTop=Math.min(c.scrollTop+Math.max(200,Math.floor(c.clientHeight*0.75)),c.scrollHeight-c.clientHeight);await j(300);}}
async function ao(){const l=await M();const r=J(l);let E=0;let Q=0;for(const x of r){for(let L=0;L<x.extra;L++){try{const e=await al(x.key);if(!e)throw new Error("Source no longer found");await am(e);E++;}catch(G){console.error("NotebookLM Deduper:",x.title,G);Q++;break;}}}
return{removed:E,failed:Q};}
chrome.runtime.onMessage.addListener((F,ap,O)=>{if(F.action==="scan"){M().then(l=>{const r=J(l);O({total:l.length,count:r.reduce((ah,d)=>ah+d.extra,0),duplicates:r.map(d=>({title:d.url||d.title,extra:d.extra,method:d.method}))});});return true;}
if(F.action==="remove"){ao().then(O);return true;}});
