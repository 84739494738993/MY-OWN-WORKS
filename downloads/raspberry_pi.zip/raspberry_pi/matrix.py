"""
8x8 LED matrix on MAX7219 (led_8x8 in the old code). Several matrices can be chained.
    import matrix
    matrix.show("smile")          # a picture (list: matrix.pictures())
    matrix.text("Hello!")         # scrolling text (Cyrillic works too)
    matrix.number(42)             # a number 0..99
    matrix.pixel(3, 4)            # light up the dot x=3, y=4
    matrix.connect(count=4, rotate=90)   # 4 matrices in a row (FC-16 module)
Wiring diagram: matrix.pins()     All commands: matrix.help()
"""
import time

import _core
from led_font import FONT

_spi = None
_count = 1
_device = 0
_rotate = 0
_mirror = False
_bright = 5
_px = [[0] * 8 for _ in range(8)]   # _px[y][x]
KEY = "matrix"

PICTURES = {
    "smile": ["00111100", "01000010", "10100101", "10000001", "10100101", "10011001", "01000010", "00111100"],
    "sad": ["00111100", "01000010", "10100101", "10000001", "10011001", "10100101", "01000010", "00111100"],
    "heart": ["00000000", "01100110", "11111111", "11111111", "11111111", "01111110", "00111100", "00011000"],
    "cross": ["10000001", "01000010", "00100100", "00011000", "00011000", "00100100", "01000010", "10000001"],
    "check": ["00000000", "00000001", "00000011", "10000110", "11001100", "01111000", "00110000", "00000000"],
    "up": ["00011000", "00111100", "01111110", "11011011", "00011000", "00011000", "00011000", "00011000"],
    "square": ["11111111", "10000001", "10000001", "10000001", "10000001", "10000001", "10000001", "11111111"],
    "dot": ["00000000", "00000000", "00000000", "00011000", "00011000", "00000000", "00000000", "00000000"],
    "full": ["11111111"] * 8,
    "empty": ["00000000"] * 8,
}
PICTURES["down"] = PICTURES["up"][::-1]
PICTURES["left"] = ["".join(PICTURES["up"][x][y] for x in range(8)) for y in range(8)]
PICTURES["right"] = [row[::-1] for row in PICTURES["left"]]
PICTURES["happy"], PICTURES["unhappy"], PICTURES["love"] = PICTURES["smile"], PICTURES["sad"], PICTURES["heart"]

# Small 3x5 digits for matrix.number()
DIGITS = {
    "0": ["111", "101", "101", "101", "111"], "1": ["010", "110", "010", "010", "111"],
    "2": ["111", "001", "111", "100", "111"], "3": ["111", "001", "111", "001", "111"],
    "4": ["101", "101", "111", "001", "001"], "5": ["111", "100", "111", "001", "111"],
    "6": ["111", "100", "111", "101", "111"], "7": ["111", "001", "010", "010", "010"],
    "8": ["111", "101", "111", "101", "111"], "9": ["111", "101", "111", "001", "111"],
    "-": ["000", "000", "111", "000", "000"],
}


def connect(count=1, rotate=0, mirror=False, device=0):
    """count — how many matrices are chained, rotate — rotation 0/90/180/270 (if the picture is rotated),
    mirror=True — if it's mirrored, device=1 — if CS is on GPIO7 (CE1)."""
    global _spi, _count, _rotate, _mirror, _device, _px
    if _spi is not None:
        _spi.close()
        _spi = None
    _count, _rotate, _mirror, _device = max(1, count), rotate % 360, mirror, device
    _px = [[0] * (8 * _count) for _ in range(8)]


def width():
    """Screen width in dots (8 * number of matrices)."""
    return 8 * _count


def _dev():
    global _spi
    if _spi is None:
        _spi = _core.spi(0, _device, 1000000, 0)
        for reg, val in ((0x0F, 0), (0x09, 0), (0x0B, 7), (0x0A, _bright), (0x0C, 1)):
            _send_all(reg, val)  # test off, no decoder, 8 rows, brightness, turn on
    return _spi


def _send_all(reg, val):
    _spi.writebytes([reg, val] * _count)


def _block(m):
    # an 8x8 piece for matrix m, taking rotation and mirroring into account -> 8 row bytes
    b = [[_px[y][m * 8 + x] for x in range(8)] for y in range(8)]
    for _ in range(_rotate // 90):
        b = [[b[7 - x][y] for x in range(8)] for y in range(8)]
    if _mirror:
        b = [row[::-1] for row in b]
    return [sum(bit << (7 - x) for x, bit in enumerate(row)) for row in b]


def update():
    """Send the picture to the matrix (usually called automatically)."""
    dev = _dev()
    blocks = [_block(m) for m in range(_count)]
    with _core._lock:
        for row in range(8):
            data = []
            for m in reversed(range(_count)):  # the first bytes go to the farthest matrix
                data += [row + 1, blocks[m][row]]
            dev.writebytes(data)


def clear():
    """Turn off all dots (and stop the scrolling text / animation)."""
    _core.stop_foreign(KEY)
    for row in _px:
        for x in range(len(row)):
            row[x] = 0
    update()


def fill():
    """Light up all dots."""
    _core.stop_foreign(KEY)
    for row in _px:
        for x in range(len(row)):
            row[x] = 1
    update()


def pixel(x, y, on=True, show=True):
    """Light up (on=True) or turn off a dot. x — column 0..7 (from the left), y — row 0..7 (from the top)."""
    if 0 <= x < width() and 0 <= y < 8:
        _px[y][x] = 1 if on else 0
    if show:
        update()


def get_pixel(x, y):
    """Is the dot lit (True / False)."""
    return bool(_px[y][x]) if 0 <= x < width() and 0 <= y < 8 else False


def _picture_rows(picture):
    if isinstance(picture, str):
        if picture not in PICTURES:
            raise ValueError("No picture %r. Available: %s" % (picture, ", ".join(PICTURES)))
        picture = PICTURES[picture]
    rows = []
    for row in picture:
        if isinstance(row, str):
            rows.append([0 if ch in "0. " else 1 for ch in row])
        elif isinstance(row, int):
            rows.append([(row >> (7 - i)) & 1 for i in range(8)])
        else:
            rows.append([1 if v else 0 for v in row])
    return rows


def show(picture, x=0):
    """Show a picture: a name ("smile", "heart" ...) or 8 rows like "01100110"."""
    _core.stop_foreign(KEY)
    _draw(_picture_rows(picture), x)


def _draw(rows, x0=0):
    for row in _px:
        for x in range(len(row)):
            row[x] = 0
    for y, row in enumerate(rows[:8]):
        for x, v in enumerate(row):
            if 0 <= x0 + x < width():
                _px[y][x0 + x] = v
    update()


def pictures():
    """Show the names of the built-in pictures."""
    print(", ".join(PICTURES))


def letter(ch):
    """Show one letter or digit in the center."""
    cols = FONT.get(ch, FONT["?"])
    rows = [[(cols[c] >> y) & 1 for c in range(len(cols))] for y in range(8)]
    show(rows, (8 - len(cols)) // 2)


def number(n):
    """Show a number from -9 to 99 in small digits."""
    s = str(int(n))
    if len(s) > 2:
        raise ValueError("One matrix fits a number from -9 to 99. For longer ones use matrix.text(...)")
    rows = [[] for _ in range(8)]
    for i, ch in enumerate(s):
        for y in range(5):
            rows[y + 1] += [int(c) for c in DIGITS[ch][y]] + ([0] if i == 0 else [])
    for y in (0, 6, 7):
        rows[y] = [0] * len(rows[1])
    show(rows, (8 - len(rows[1])) // 2)


def _columns(message):
    cols = []
    for ch in str(message):
        if ch == " ":
            cols += [0, 0, 0]
            continue
        glyph = FONT.get(ch, FONT["?"])
        nz = [i for i, c in enumerate(glyph) if c]
        cols += (glyph[nz[0]:nz[-1] + 1] if nz else [0, 0]) + [0]
    return cols


def _scroll(message, speed, ev=None):
    cols = [0] * width() + _columns(message) + [0] * width()
    for start in range(len(cols) - width() + 1):
        window = cols[start:start + width()]
        for y in range(8):
            for x in range(width()):
                _px[y][x] = (window[x] >> y) & 1
        update()
        if _core.sleep(speed, ev):
            return True
    return False


def text(message, speed=0.08):
    """Scrolling text (Latin, Cyrillic, digits). speed — seconds per step (less = faster)."""
    _core.stop_foreign(KEY)
    _scroll(message, speed)


def start_text(message, speed=0.08):
    """Scrolling text in the background, in a loop. Stop it: matrix.clear()."""

    def loop(ev):
        while not ev.is_set():
            if _scroll(message, speed, ev):
                break

    _core.start_task(KEY, loop)


def brightness(level):
    """Brightness from 0 to 15."""
    global _bright
    _bright = max(0, min(15, int(level)))
    _dev()
    _send_all(0x0A, _bright)


def invert():
    """Swap lit and unlit dots."""
    for row in _px:
        for x in range(len(row)):
            row[x] = 1 - row[x]
    update()


def row(y, on=True):
    """Light up (or turn off) a whole row y = 0..7."""
    for x in range(width()):
        _px[y][x] = 1 if on else 0
    update()


def column(x, on=True):
    """Light up (or turn off) a whole column x."""
    for y in range(8):
        _px[y][x] = 1 if on else 0
    update()


def line(x1, y1, x2, y2, on=True):
    """Draw a line from (x1, y1) to (x2, y2)."""
    dx, dy = abs(x2 - x1), -abs(y2 - y1)
    sx, sy = (1 if x1 < x2 else -1), (1 if y1 < y2 else -1)
    err = dx + dy
    while True:
        pixel(x1, y1, on, show=False)
        if x1 == x2 and y1 == y2:
            break
        e2 = 2 * err
        if e2 >= dy:
            err += dy
            x1 += sx
        if e2 <= dx:
            err += dx
            y1 += sy
    update()


def rect(x, y, w, h, filled=False, on=True):
    """Rectangle: top left corner (x, y), width w, height h. filled=True — filled."""
    for yy in range(y, y + h):
        for xx in range(x, x + w):
            if filled or yy in (y, y + h - 1) or xx in (x, x + w - 1):
                pixel(xx, yy, on, show=False)
    update()


def animate(frames, speed=0.2, times=1):
    """Show frames one after another: frames — a list of pictures (names or 8 rows)."""
    _core.stop_foreign(KEY)
    for _ in range(times):
        for f in frames:
            _draw(_picture_rows(f))
            time.sleep(speed)


def on():
    """Turn the screen on (the picture comes back)."""
    _dev()
    _send_all(0x0C, 1)


def off():
    """Turn the screen off without erasing the picture."""
    _dev()
    _send_all(0x0C, 0)


def test(seconds=1.0):
    """Test: light up all dots at full brightness for seconds seconds."""
    _dev()
    _send_all(0x0F, 1)
    time.sleep(seconds)
    _send_all(0x0F, 0)


def pins():
    """Show how to wire the matrix."""
    cs = 8 if _device == 0 else 7
    _core.show_pins("8x8 LED matrix MAX7219 (SPI)", [
        ("VCC", _core.V5),
        ("GND", _core.GND),
        ("DIN", _core.only_pin(10)),
        ("CS", _core.only_pin(cs)),
        ("CLK", _core.only_pin(11)),
    ], [
        "Turn on SPI: sudo raspi-config -> Interface Options -> SPI -> Yes, then reboot.",
        "Chain: DOUT of the first matrix -> DIN of the second, and matrix.connect(count=2).",
        "Picture rotated or mirrored? matrix.connect(rotate=90 / 180 / 270, mirror=True).",
        "CS on GPIO7 instead of GPIO8: matrix.connect(device=1).",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
