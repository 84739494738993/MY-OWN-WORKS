"""
IR remote: receiving (VS1838B IR receiver) and sending (IR LED). ir_remote, ir_read, ir_send in the old code.
Works through the Linux driver (ir-ctl), so config.txt has to be set up once — see ir.pins().
    import ir
    print(ir.read_code())       # press a remote button -> "0x00FF30CF"
    ir.learn("power")           # remember a remote button under a name
    print(ir.wait_button())     # which remembered button was pressed -> "power"
    ir.send("power")            # send a remembered signal (like the remote)
Wiring diagram: ir.pins()     All commands: ir.help()
"""
import os
import re
import subprocess
import tempfile

import _core

_rx = None   # receiver device, for example /dev/lirc1
_tx = None   # transmitter device, for example /dev/lirc0
RX_PIN, TX_PIN = 17, 18
CODES_FILE = "ir_codes.json"


def connect(receiver=None, sender=None):
    """Set the devices by hand, for example ir.connect("/dev/lirc1", "/dev/lirc0"). Usually they are found automatically."""
    global _rx, _tx
    _rx, _tx = receiver, sender


def _need_ir_ctl():
    if not _core.has_program("ir-ctl"):
        raise RuntimeError("The ir-ctl program is missing. Install it: sudo apt install v4l-utils")


def _find(kind):
    _need_ir_ctl()
    devs = sorted(d for d in os.listdir("/dev") if re.match(r"lirc\d+$", d))
    for d in devs:
        path = "/dev/" + d
        out = subprocess.run(["ir-ctl", "-d", path, "--features"], capture_output=True, text=True).stdout.lower()
        if ("can receive raw" if kind == "rx" else "can send raw") in out:
            return path
    raise RuntimeError("IR %s not found. Add the line from ir.pins() to config.txt and reboot."
                       % ("receiver" if kind == "rx" else "transmitter"))


def _rx_dev():
    global _rx
    if _rx is None:
        _rx = _find("rx")
    return _rx


def _tx_dev():
    global _tx
    if _tx is None:
        _tx = _find("tx")
    return _tx


def _parse(text):
    """ir-ctl text -> list of durations [pulse, space, pulse, ...] in microseconds."""
    out = []
    word = None
    for line in text.splitlines():
        line = line.split("#")[0]
        for tok in line.split():
            if tok in ("pulse", "space"):
                word = tok
                continue
            if tok == "timeout":
                word = "timeout"
                continue
            try:
                v = int(tok)
            except ValueError:
                continue
            if word == "timeout":
                word = None
                continue
            out.append(abs(v))
            word = None
    if len(out) % 2 == 0 and out:
        out = out[:-1]  # the last element is the trailing space
    return out


def read_raw(timeout=None):
    """Wait for a remote signal and return the "raw" signal: a list of durations in µs. None — nothing came."""
    try:
        r = subprocess.run(["ir-ctl", "-d", _rx_dev(), "-r", "-1"], capture_output=True, text=True,
                           timeout=timeout)
    except subprocess.TimeoutExpired:
        return None
    sig = _parse(r.stdout)
    return sig if len(sig) >= 3 else None


def decode_nec(sig):
    """Decode a raw NEC signal (most Chinese remotes) -> "0x00FF30CF" or None."""
    def near(v, target, tol=0.35):
        return abs(v - target) <= target * tol
    if len(sig) >= 3 and near(sig[0], 9000) and near(sig[1], 2250) and len(sig) < 8:
        return "REPEAT"
    if len(sig) < 67 or not (near(sig[0], 9000) and near(sig[1], 4500)):
        return None
    code = 0
    for i in range(32):
        space = sig[3 + 2 * i]
        if near(space, 1690):
            code = (code << 1) | 1
        elif near(space, 560, 0.5):
            code = code << 1
        else:
            return None
    return "0x%08X" % code


def read_code(timeout=None):
    """Wait for a remote button press and return its code ("0x00FF30CF"). Repeats while held -> "REPEAT"."""
    while True:
        sig = read_raw(timeout)
        if sig is None:
            return None
        code = decode_nec(sig)
        if code:
            return code
        print("Got a signal, but it isn't NEC. Use ir.learn(name) — that way any remote can be remembered.")


def same(sig1, sig2, tolerance=0.25):
    """Are two raw signals similar (True / False). Compares the first ~60 durations."""
    if not sig1 or not sig2 or abs(len(sig1) - len(sig2)) > 4:
        return False
    for a, b in zip(sig1[:60], sig2[:60]):
        if abs(a - b) > max(200, tolerance * max(a, b)):
            return False
    return True


def buttons():
    """Names of all remembered buttons."""
    return list(_core.load_json(CODES_FILE, {}))


def learn(name, timeout=None):
    """Press a remote button — its signal is remembered under the name name (file ir_codes.json)."""
    print("Press the remote button for \"%s\"..." % name)
    sig = read_raw(timeout)
    if not sig:
        print("No signal caught.")
        return False
    codes = _core.load_json(CODES_FILE, {})
    codes[name] = sig
    _core.save_json(CODES_FILE, codes)
    nec = decode_nec(sig)
    print("Remembered \"%s\" (%d pulses%s)" % (name, len(sig), ", NEC " + nec if nec and nec != "REPEAT" else ""))
    return True


def forget(name):
    """Forget a button."""
    codes = _core.load_json(CODES_FILE, {})
    codes.pop(name, None)
    _core.save_json(CODES_FILE, codes)


def recognize(sig):
    """Find the name of a remembered button by a raw signal (or None)."""
    for name, saved in _core.load_json(CODES_FILE, {}).items():
        if same(sig, saved):
            return name
    return None


def wait_button(timeout=None):
    """Wait for any remembered button and return its name (or None if the time ran out)."""
    while True:
        sig = read_raw(timeout)
        if sig is None:
            return None
        name = recognize(sig)
        if name:
            return name


def on_button(func):
    """Call func(button_name) on every press of a remembered button (the program keeps going)."""

    def loop(ev):
        while not ev.is_set():
            sig = read_raw(1.0)
            if sig and not ev.is_set():
                name = recognize(sig)
                if name:
                    try:
                        func(name)
                    except Exception as e:
                        print("[error in your function] %s" % e)

    _core.start_task("ir", loop)


def stop():
    """Stop listening to the remote (cancels on_button)."""
    _core.stop_task("ir")


def _send_raw(sig, times=1, carrier=38000):
    sig = [int(v) for v in sig]
    if len(sig) % 2 == 0:
        sig = sig[:-1]  # the signal must end with a pulse
    text = " ".join(("+%d" if i % 2 == 0 else "-%d") % v for i, v in enumerate(sig))
    fd, path = tempfile.mkstemp(suffix=".txt")
    with os.fdopen(fd, "w") as f:
        f.write(text + "\n")
    try:
        for _ in range(times):
            subprocess.run(["ir-ctl", "-d", _tx_dev(), "--carrier=%d" % carrier, "--send=" + path], check=False)
    finally:
        os.remove(path)


def send(button, times=1):
    """Send a signal: the name of a remembered button, or a raw signal (list / string "+9000 -4500 ...")."""
    codes = _core.load_json(CODES_FILE, {})
    if isinstance(button, str) and button in codes:
        sig = codes[button]
    elif isinstance(button, str) and re.match(r"^[+\-\d\s]+$", button) and len(button.split()) > 2:
        sig = [abs(int(v)) for v in button.split()]
    elif isinstance(button, str):
        raise ValueError("No button %r. Remembered: %s" % (button, ", ".join(codes) or "none yet — ir.learn(name)"))
    else:
        sig = button
    _send_raw(sig, times)


def send_nec(code, times=1):
    """Send an NEC code, for example ir.send_nec("0x00FF30CF")."""
    value = int(code, 16) if isinstance(code, str) else int(code)
    sig = [9000, 4500]
    for i in range(31, -1, -1):
        sig += [560, 1690 if (value >> i) & 1 else 560]
    sig.append(560)
    _send_raw(sig, times)


def pins():
    """Show how to wire the IR receiver and IR LED."""
    _core.show_pins("VS1838B IR receiver and IR LED", [
        ("Receiver OUT (S)", "%s — the one in config.txt" % _core.any_pin(RX_PIN)),
        ("Receiver VCC (+)", _core.V3),
        ("Receiver GND (-)", _core.GND),
        ("IR LED (+)", "100 Ω resistor -> %s — the one in config.txt" % _core.any_pin(TX_PIN)),
        ("IR LED (-)", _core.GND),
    ], [
        "Once: sudo nano /boot/firmware/config.txt  and add these lines at the end:",
        "    dtoverlay=gpio-ir,gpio_pin=%d" % RX_PIN,
        "    dtoverlay=gpio-ir-tx,gpio_pin=%d" % TX_PIN,
        "then sudo reboot. The program: sudo apt install v4l-utils (that's ir-ctl).",
        "Any pin works, but exactly the one written in config.txt.",
        "For a longer range, drive the IR LED through a transistor.",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
