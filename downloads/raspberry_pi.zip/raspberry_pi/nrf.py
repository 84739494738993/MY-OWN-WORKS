"""
nRF24L01 radio module (2.4 GHz) — messages with another Raspberry or an Arduino (RF24 library).
    import nrf
    nrf.send("Hello")                 # send a message (up to 32 bytes)
    print(nrf.receive())              # wait for a message and return the text
    nrf.on_message(print)             # print everything that arrives (the program keeps going)
    nrf.connect(address="00002", channel=90)   # another address / channel
Wiring diagram: nrf.pins()     All commands: nrf.help()
"""
import threading
import time

import _core

_cfg = dict(ce=22, csn=0, channel=76, address="00001", power="low", speed="1mbps", dynamic=True)
_radio = None
_listening = False
_lock = threading.RLock()


def connect(ce=22, csn=0, channel=76, address="00001", power="low", speed="1mbps", dynamic=True):
    """Radio settings. They must match the other side (Arduino):
    address — 5 characters, channel 0..125, power "min"/"low"/"high"/"max", speed "250kbps"/"1mbps"/"2mbps",
    dynamic=True — like radio.enableDynamicPayloads() on Arduino. csn=0 — pin CE0 (GPIO8), 1 — CE1 (GPIO7)."""
    global _radio, _listening
    _core.check_pin(ce)
    with _lock:
        if _radio is not None:
            try:
                _radio.power = False
            except Exception:
                pass
        _radio, _listening = None, False
        _cfg.update(ce=ce, csn=csn, channel=channel, address=str(address), power=power, speed=speed,
                    dynamic=dynamic)


def _lib():
    try:
        import pyrf24
    except ImportError as e:
        raise RuntimeError("The pyrf24 library didn't load (%s).\n"
                           "Install it: pip install pyrf24 --break-system-packages" % e)
    return pyrf24


def _r():
    global _radio
    with _lock:
        if _radio is None:
            lib = _lib()
            radio = lib.RF24(_cfg["ce"], _cfg["csn"])
            if not radio.begin():
                raise RuntimeError("The radio module doesn't answer. Check the wiring (nrf.pins()), "
                                   "3.3V power + capacitor, and that SPI is on.")
            levels = {"min": lib.RF24_PA_MIN, "low": lib.RF24_PA_LOW, "high": lib.RF24_PA_HIGH,
                      "max": lib.RF24_PA_MAX}
            rates = {"250kbps": lib.RF24_250KBPS, "1mbps": lib.RF24_1MBPS, "2mbps": lib.RF24_2MBPS}
            radio.set_pa_level(levels[_cfg["power"].lower()])
            radio.data_rate = rates[_cfg["speed"].lower()]
            radio.channel = int(_cfg["channel"])
            radio.dynamic_payloads = bool(_cfg["dynamic"])
            addr = _cfg["address"].encode("utf-8")
            radio.open_tx_pipe(addr)
            radio.open_rx_pipe(1, addr)
            radio.stop_listening()
            _radio = radio
        return _radio


def _listen(on):
    global _listening
    r = _r()
    if on and not _listening:
        r.start_listening()
    elif not on and _listening:
        r.stop_listening()
    _listening = on


def is_connected():
    """Is the module connected and answering? (True / False)."""
    try:
        return bool(_r().is_chip_connected)
    except RuntimeError:
        return False


def send(message):
    """Send a message (text or a number). Returns True — delivered (the other side confirmed), False — not."""
    data = message if isinstance(message, (bytes, bytearray)) else str(message).encode("utf-8") + b"\x00"
    if len(data) > 32:
        print("The message is longer than 32 bytes — cutting it. Non-Latin letters take 2 bytes each.")
        data = data[:31] + b"\x00"
    with _lock:
        was = _listening
        _listen(False)
        if not _cfg["dynamic"]:
            data = bytes(data).ljust(32, b"\x00")
        ok = _r().write(data)
        if was:
            _listen(True)
    return bool(ok)


def _decode(buf):
    return bytes(buf).split(b"\x00")[0].decode("utf-8", errors="ignore")


def read():
    """Read a message if one has already arrived (doesn't wait). Returns the text or None."""
    with _lock:
        _listen(True)
        r = _r()
        if not r.available():
            return None
        size = r.get_dynamic_payload_size() if _cfg["dynamic"] else 32
        return _decode(r.read(size))


def available():
    """Is there an unread message (True / False)."""
    with _lock:
        _listen(True)
        return bool(_r().available())


def receive(timeout=None):
    """Wait for a message and return the text. timeout — the most seconds to wait (otherwise None)."""
    end = None if timeout is None else time.time() + timeout
    while True:
        msg = read()
        if msg is not None:
            return msg
        if end is not None and time.time() >= end:
            return None
        time.sleep(0.01)


def on_message(func):
    """Call func(text) for every incoming message (the program keeps going)."""

    def loop(ev):
        while not ev.is_set():
            msg = read()
            if msg is not None:
                try:
                    func(msg)
                except Exception as e:
                    print("[error in your function] %s" % e)
            else:
                ev.wait(0.01)

    _core.start_task("nrf", loop)


def stop():
    """Stop listening (cancels on_message)."""
    _core.stop_task("nrf")


def details():
    """Print all radio module settings (for debugging)."""
    _r().print_pretty_details()


def pins():
    """Show how to wire the nRF24L01."""
    cs = 8 if _cfg["csn"] == 0 else 7
    _core.show_pins("nRF24L01 radio module (SPI)", [
        ("GND (1)", _core.GND),
        ("VCC (2)", _core.V3 + "  (NOT 5V — it will burn!)"),
        ("CE (3)", _core.any_pin(_cfg["ce"])),
        ("CSN (4)", _core.only_pin(cs)),
        ("SCK (5)", _core.only_pin(11)),
        ("MOSI (6)", _core.only_pin(10)),
        ("MISO (7)", _core.only_pin(9)),
        ("IRQ (8)", "not connected"),
    ], [
        "Turn on SPI: sudo raspi-config -> Interface Options -> SPI -> Yes, then reboot.",
        "Solder/insert a 10-100 µF capacitor between the module's VCC and GND — without it it often doesn't work.",
        "Address, channel and speed must match the other side: nrf.connect(address='00001', channel=76).",
        "Another CE pin: nrf.connect(ce=25). CSN on GPIO7: nrf.connect(csn=1).",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
