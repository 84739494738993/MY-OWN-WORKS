"""
ST7789 240x240 color display (SPI).
    import display
    display.text("HELLO!")                    # text in the center (Cyrillic works too)
    display.text("12:30", size=60, color="yellow")
    display.image("/home/pi/picture.png")     # picture on the whole screen
    display.fill("blue")                      # fill with a color
    display.circle(120, 120, 50, "red")       # shapes: pixel, line, rect, circle
Wiring diagram: display.pins()     All commands: display.help()
"""
import os
import time

import _core

# Like in the working old code: DC=25, RST=27, backlight BL=23, SPI mode 3, 40 MHz, rotation 3
_cfg = dict(dc=25, rst=27, bl=23, device=0, width=240, height=240, rotate=3, invert=True,
            speed=40, spi_mode=3, x_offset=0, y_offset=0)
_spi = None
_img = None
_draw = None
_auto = True
_fonts = {}


def connect(dc=25, rst=27, bl=23, device=0, width=240, height=240, rotate=3, invert=True,
            speed=40, spi_mode=3, x_offset=0, y_offset=0):
    """Display settings. rotate 0..3 — rotation by 90° (text upside down? change it),
    invert=False — if colors look like a negative, speed — SPI speed in MHz (garbage on screen? lower it),
    spi_mode — SPI mode (screens without a CS pin need 3), bl=None — if the backlight isn't connected."""
    global _spi, _img
    if _spi is not None:
        _spi.close()
    _spi, _img = None, None
    for p in (dc, rst, bl):
        if p is not None:
            _core.check_pin(p)
    _cfg.update(dc=dc, rst=rst, bl=bl, device=device, width=width, height=height, rotate=rotate % 4,
                invert=invert, speed=speed, spi_mode=spi_mode, x_offset=x_offset, y_offset=y_offset)


def _pil():
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError as e:
        raise RuntimeError("The Pillow library is missing (%s). Install it: sudo apt install python3-pil" % e)
    return Image, ImageDraw, ImageFont


def _size():
    w, h = _cfg["width"], _cfg["height"]
    return (h, w) if _cfg["rotate"] % 2 else (w, h)


def size():
    """Screen size (width, height) taking the rotation into account."""
    return _size()


def _canvas():
    global _img, _draw
    if _img is None:
        Image, ImageDraw, _ = _pil()
        _img = Image.new("RGB", _size(), "black")
        _draw = ImageDraw.Draw(_img)
    return _img, _draw


def _cmd(c, *data):
    _core.write(_cfg["dc"], 0)
    _spi.writebytes([c])
    if data:
        _core.write(_cfg["dc"], 1)
        _spi.writebytes(list(data))


def _dev():
    global _spi
    if _spi is not None:
        return _spi
    c = _cfg
    _spi = _core.spi(0, c["device"], c["speed"] * 1000000, c["spi_mode"])
    # Step 1. "Clean start" — exactly like start_nastrojka() from the old working code:
    # DC/RST/BL pins become outputs again, reset via RST, SPI in mode 3, wake the screen up and turn it on.
    # (luma didn't do this itself: it reset the screen without pauses and didn't set the SPI mode —
    # that's why the screen didn't start without this clean start.)
    _core.write(c["dc"], 0)
    if c["rst"] is not None:
        _core.write(c["rst"], 0)
        time.sleep(0.1)
        _core.write(c["rst"], 1)
        time.sleep(0.1)
    _cmd(0x01)                     # software reset
    time.sleep(0.15)
    _cmd(0x11)                     # wake up from sleep
    time.sleep(0.5)
    _cmd(0x3A, 0x05)
    _cmd(0x36, 0x00)
    _cmd(0x21)
    _cmd(0x29)                     # screen on
    if c["bl"] is not None:
        _core.write(c["bl"], 1)    # backlight
    # Step 2. Main setup — the way luma.lcd did it in the old code (without another reset)
    _cmd(0x36, 0x70)               # memory order
    _cmd(0x3A, 0x06)               # 18 bits per pixel: we send R, G, B bytes
    _cmd(0xB2, 0x0C, 0x0C, 0x00, 0x33, 0x33)
    _cmd(0xB7, 0x35)
    _cmd(0xBB, 0x19)
    _cmd(0xC0, 0x2C)
    _cmd(0xC2, 0x01)
    _cmd(0xC3, 0x12)
    _cmd(0xC4, 0x20)
    _cmd(0xC6, 0x0F)
    _cmd(0xD0, 0xA4, 0xA1)
    _cmd(0xE0, 0xD0, 0x04, 0x0D, 0x11, 0x13, 0x2B, 0x3F, 0x54, 0x4C, 0x18, 0x0D, 0x0B, 0x1F, 0x23)
    _cmd(0xE1, 0xD0, 0x04, 0x0C, 0x11, 0x13, 0x2C, 0x3F, 0x44, 0x51, 0x2F, 0x1F, 0x1F, 0x20, 0x23)
    _cmd(0x21 if c["invert"] else 0x20)   # inversion (without it many screens show a "negative")
    _cmd(0x11)
    time.sleep(0.12)
    _cmd(0x29)                     # turn the screen on
    return _spi


def reset():
    """Do the "clean start" and setup again (like in the old code) and show the picture. Use it if the screen hangs, is white or black."""
    global _spi
    if _spi is not None:
        _spi.close()
        _spi = None
    update()  # on the first call the screen is reset and set up again


def update():
    """Send the picture to the screen (usually called automatically after every command)."""
    img, _ = _canvas()
    _dev()
    c = _cfg
    out = img.rotate(-90 * c["rotate"], expand=True) if c["rotate"] else img
    x0, y0 = c["x_offset"], c["y_offset"]
    x1, y1 = x0 + c["width"] - 1, y0 + c["height"] - 1
    with _core._lock:
        _cmd(0x2A, x0 >> 8, x0 & 0xFF, x1 >> 8, x1 & 0xFF)
        _cmd(0x2B, y0 >> 8, y0 & 0xFF, y1 >> 8, y1 & 0xFF)
        _cmd(0x2C)
        _core.write(c["dc"], 1)
        _core.spi_send(_spi, out.tobytes())


def _done():
    if _auto:
        update()


def auto_update(on=True):
    """auto_update(False) — draw without showing, then call display.update() once (faster, no flicker)."""
    global _auto
    _auto = on


_FONT_DIRS = [_core.FONTS, "/usr/share/fonts"]


def _find_font(name):
    if os.path.isfile(name):
        return name
    names = [name] if name.lower().endswith((".ttf", ".otf")) else [name + ".ttf", name + ".otf"]
    for d in _FONT_DIRS:
        for root, _, files in os.walk(d):
            for n in names:
                if n in files:
                    return os.path.join(root, n)
    raise ValueError("Font %r not found. List of fonts: display.fonts()" % name)


def _font(size, bold=True, name=None):
    key = (size, bold, name)
    if key not in _fonts:
        _, _, ImageFont = _pil()
        if name:
            _fonts[key] = ImageFont.truetype(_find_font(name), size)
            return _fonts[key]
        name = "DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"
        for path in (os.path.join(_core.FONTS, name), "/usr/share/fonts/truetype/dejavu/" + name):
            if os.path.exists(path):
                _fonts[key] = ImageFont.truetype(path, size)
                break
        else:
            _fonts[key] = ImageFont.load_default()
    return _fonts[key]


def fonts():
    """Show the fonts you can use in display.text(..., font="name"). Put your own .ttf files into libs/fonts."""
    found = set()
    for d in _FONT_DIRS:
        for root, _, files in os.walk(d):
            found.update(f.rsplit(".", 1)[0] for f in files if f.lower().endswith((".ttf", ".otf")))
    names = sorted(found)
    print(", ".join(names) if names else "No fonts found")
    return names


def clear(color="black"):
    """Clear the screen (fill it with color, black by default)."""
    img, d = _canvas()
    d.rectangle((0, 0, img.width, img.height), fill=color)
    _done()


def fill(color):
    """Fill the whole screen with a color: "red", "#00FF00" or (0, 0, 255)."""
    clear(color)


def text(message, x=None, y=None, size=30, color="white", bg="black", clear=True, bold=True,
         font=None, align="center"):
    """Write text. x, y = None — in the center. clear=True — clear the screen with color bg first.
    font — font name (list: display.fonts()), align — "left"/"center"/"right" for several lines (\\n)."""
    img, d = _canvas()
    if clear:
        d.rectangle((0, 0, img.width, img.height), fill=bg)
    font = _font(size, bold, font)
    message = str(message)
    try:
        box = d.multiline_textbbox((0, 0), message, font=font, align=align)
        tw, th, ox, oy = box[2] - box[0], box[3] - box[1], box[0], box[1]
    except AttributeError:  # old Pillow
        tw, th = d.multiline_textsize(message, font=font)
        ox = oy = 0
    px = (img.width - tw) // 2 - ox if x is None else x
    py = (img.height - th) // 2 - oy if y is None else y
    d.multiline_text((px, py), message, font=font, fill=color, align=align)
    _done()


def image(path, keep_ratio=False, bg="black"):
    """Show a picture from a file on the whole screen. keep_ratio=True — don't stretch (margins in color bg)."""
    Image, _, _ = _pil()
    img, d = _canvas()
    try:
        pic = Image.open(path).convert("RGB")
    except FileNotFoundError:
        raise FileNotFoundError("Picture %s not found" % path)
    resample = getattr(Image, "Resampling", Image).LANCZOS
    if keep_ratio:
        pic.thumbnail(img.size, resample)
        d.rectangle((0, 0, img.width, img.height), fill=bg)
        img.paste(pic, ((img.width - pic.width) // 2, (img.height - pic.height) // 2))
    else:
        img.paste(pic.resize(img.size, resample))
    _done()


def pixel(x, y, color="white"):
    """A single pixel."""
    _, d = _canvas()
    d.point((x, y), fill=color)
    _done()


def line(x1, y1, x2, y2, color="white", width=2):
    """A line from (x1, y1) to (x2, y2)."""
    _, d = _canvas()
    d.line((x1, y1, x2, y2), fill=color, width=width)
    _done()


def rect(x, y, w, h, color="white", fill=True, width=2):
    """Rectangle: top left corner (x, y), width w, height h. fill=False — outline only."""
    _, d = _canvas()
    if fill:
        d.rectangle((x, y, x + w - 1, y + h - 1), fill=color)
    else:
        d.rectangle((x, y, x + w - 1, y + h - 1), outline=color, width=width)
    _done()


def circle(x, y, r, color="white", fill=True, width=2):
    """Circle with center (x, y) and radius r. fill=False — outline only."""
    _, d = _canvas()
    box = (x - r, y - r, x + r, y + r)
    if fill:
        d.ellipse(box, fill=color)
    else:
        d.ellipse(box, outline=color, width=width)
    _done()


def bar(percent, y=200, height=24, color="lime", bg="gray"):
    """An indicator bar (progress, battery level, volume...) across the whole screen width."""
    img, d = _canvas()
    p = max(0, min(100, percent))
    d.rectangle((10, y, img.width - 10, y + height), fill=bg)
    d.rectangle((10, y, 10 + (img.width - 20) * p // 100, y + height), fill=color)
    _done()


def backlight(on=True):
    """Turn the backlight on / off (needs BL connected)."""
    if _cfg["bl"] is None:
        raise RuntimeError("The backlight pin isn't set: display.connect(bl=23)")
    _core.write(_cfg["bl"], 1 if on else 0)


def brightness(percent):
    """Backlight brightness 0..100 % (PWM on the BL pin). Holds while the program runs."""
    if _cfg["bl"] is None:
        raise RuntimeError("The backlight pin isn't set: display.connect(bl=23)")
    if percent >= 100:
        backlight(True)
    else:
        _core.pwm(_cfg["bl"], 500, max(0, percent))


def off():
    """Turn the screen and backlight off (sleep); the picture is kept."""
    _dev()
    _cmd(0x28)
    _cmd(0x10)
    if _cfg["bl"] is not None:
        _core.write(_cfg["bl"], 0)


def on():
    """Turn the screen back on after off()."""
    _dev()
    _cmd(0x11)
    time.sleep(0.12)
    _cmd(0x29)
    if _cfg["bl"] is not None:
        _core.write(_cfg["bl"], 1)


def canvas():
    """For your own drawings with Pillow: img, draw = display.canvas(); draw.text(...); display.update()."""
    return _canvas()


def save(path="screen.png"):
    """Save what's on the screen right now to a picture file."""
    img, _ = _canvas()
    img.save(path)
    return path


def pins():
    """Show how to wire the display."""
    c = _cfg
    cs = 8 if c["device"] == 0 else 7
    _core.show_pins("ST7789 display %dx%d (SPI)" % (c["width"], c["height"]), [
        ("GND", _core.GND),
        ("VCC", _core.V3),
        ("SCL (SCK)", _core.only_pin(11)),
        ("SDA (MOSI)", _core.only_pin(10)),
        ("RES (RST)", _core.any_pin(c["rst"]) if c["rst"] is not None else "not connected"),
        ("DC", _core.any_pin(c["dc"])),
        ("BLK (BL)", _core.any_pin(c["bl"]) if c["bl"] is not None else "not connected (backlight always on)"),
        ("CS (if present)", _core.only_pin(cs)),
    ], [
        "Turn on SPI: sudo raspi-config -> Interface Options -> SPI -> Yes, then reboot.",
        "Your own pins: display.connect(dc=24, rst=17, bl=None).",
        "The screen's \"clean start\", like start_nastrojka() in the old code, happens by itself on the first command.",
        "Screen hangs or is white — display.reset().",
        "Black screen? Try display.connect(speed=8), then display.connect(spi_mode=0).",
        "Text rotated? display.connect(rotate=0 / 1 / 2 / 3).",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
