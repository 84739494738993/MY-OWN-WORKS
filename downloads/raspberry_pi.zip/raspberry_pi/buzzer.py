"""
Buzzer. An active one beeps by itself on 1, a passive one can play notes.
    import buzzer
    buzzer.beep(23, 3)              # beep 3 times (active and passive)
    buzzer.tone(23, 1000, 0.5)      # a 1000 Hz sound for half a second (passive)
    buzzer.play(23, "birthday")     # play a melody (passive)
    buzzer.play(23, "C5 D5 E5:2 R G5/2")   # your own notes
Wiring diagram: buzzer.pins()     All commands: buzzer.help()
"""
import re
import time

import _core

_NAMES = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11, "H": 11,
          "DO": 0, "RE": 2, "MI": 4, "FA": 5, "SOL": 7, "LA": 9, "SI": 11}

# Melodies (folk / classical). Format: NOTE[OCTAVE][:duration], R — rest.
MELODIES = {
    "birthday": "G5:0.75 G5:0.25 A5 G5 C6 B5:2 G5:0.75 G5:0.25 A5 G5 D6 C6:2 "
                "G5:0.75 G5:0.25 G6 E6 C6 B5 A5:2 F6:0.75 F6:0.25 E6 C6 D6 C6:3",
    "jingle": "E5 E5 E5:2 E5 E5 E5:2 E5 G5 C5:1.5 D5:0.5 E5:4 F5 F5 F5:1.5 F5:0.5 "
              "F5 E5 E5 E5:0.5 E5:0.5 G5 G5 F5 D5 C5:4",
    "ode": "E5 E5 F5 G5 G5 F5 E5 D5 C5 C5 D5 E5 E5:1.5 D5:0.5 D5:2 "
           "E5 E5 F5 G5 G5 F5 E5 D5 C5 C5 D5 E5 D5:1.5 C5:0.5 C5:2",
    "twinkle": "C5 C5 G5 G5 A5 A5 G5:2 F5 F5 E5 E5 D5 D5 C5:2 G5 G5 F5 F5 E5 E5 D5:2 "
               "G5 G5 F5 F5 E5 E5 D5:2 C5 C5 G5 G5 A5 A5 G5:2 F5 F5 E5 E5 D5 D5 C5:2",
    "scale": "C5 D5 E5 F5 G5 A5 B5 C6",
    "win": "C5:0.5 E5:0.5 G5:0.5 C6:1.5 G5:0.5 C6:2",
    "lose": "G4 F#4 F4 E4:3",
}


def on(pin):
    """Turn on (an active buzzer beeps until you turn it off)."""
    _core.write(pin, 1)


def off(pin):
    """Turn the sound off (also stops a background siren/alarm)."""
    _core.stop_task(pin)
    _core.write(pin, 0)


def beep(pin, times=1, length=0.15, pause=0.15, freq=None):
    """Beep times times. freq — frequency for a passive buzzer (for example 2000), otherwise plain on/off."""
    _core.stop_task(pin)
    for i in range(times):
        if freq:
            _core.pwm(pin, freq, 50)
        else:
            _core.write(pin, 1)
        time.sleep(length)
        _core.write(pin, 0)
        if i < times - 1:
            time.sleep(pause)


def tone(pin, freq, seconds=None):
    """Passive buzzer: a sound of freq Hz. seconds=None — keeps sounding until you call buzzer.off(pin)."""
    _core.stop_task(pin)
    if freq <= 0:
        _core.write(pin, 0)
        return
    _core.pwm(pin, freq, 50)
    if seconds is not None:
        time.sleep(seconds)
        _core.write(pin, 0)


def note_freq(name):
    """Note frequency: note_freq("A4") -> 440.0. Also "C#5", "Eb4" or solfège "la4"."""
    m = re.match(r"^([A-Za-z]+?)([#b]?)(-?\d)?$", name.strip())
    key = m.group(1).upper() if m else ""
    if key not in _NAMES:
        raise ValueError("Unknown note %r. Examples: C4, D#5, Eb4, A4, la4" % name)
    n = _NAMES[key] + {"#": 1, "b": -1, "": 0}[m.group(2)]
    octave = int(m.group(3)) if m.group(3) else 4
    return round(440.0 * 2 ** ((n - 9) / 12.0 + (octave - 4)), 2)


def note(pin, name, seconds=0.3):
    """Play one note: buzzer.note(23, "A4", 0.5)."""
    tone(pin, note_freq(name), seconds)


def play(pin, melody, tempo=160):
    """Play a melody: a name (buzzer.melodies()) or a string of notes "C5 D5 E5:2 R G5/2". tempo — beats per minute."""
    _core.stop_task(pin)
    text = MELODIES.get(str(melody).lower(), melody)
    beat = 60.0 / tempo
    for token in text.split():
        name, _, length = token.partition(":")
        if "/" in name and not length:
            name, _, div = name.partition("/")
            length = 1.0 / float(div)
        length = float(length) if length else 1.0
        dur = beat * length
        if name.upper() in ("R", "-", "P", "PAUSE"):
            _core.write(pin, 0)
            time.sleep(dur)
            continue
        _core.pwm(pin, note_freq(name), 50)
        time.sleep(dur * 0.9)
        _core.write(pin, 0)
        time.sleep(dur * 0.1)


def melodies():
    """Show the names of the built-in melodies."""
    print(", ".join(MELODIES))


def siren(pin, times=2, seconds=1.0):
    """Passive buzzer: an "up-down" siren times times."""
    _core.stop_task(pin)
    steps = 40
    for _ in range(times):
        for i in list(range(steps)) + list(range(steps, 0, -1)):
            _core.pwm(pin, 600 + i * 30, 50)
            time.sleep(seconds / (2 * steps))
    _core.write(pin, 0)


def alarm(pin, times=5, speed=0.1):
    """Alarm: frequent short beeps (works with an active buzzer too)."""
    beep(pin, times, speed, speed)


def start_alarm(pin, speed=0.3, freq=None):
    """Beep in the background non-stop (the program keeps going). Stop it: buzzer.off(pin)."""
    _core.check_pin(pin)

    def loop(ev):
        while not ev.is_set():
            if freq:
                _core.pwm(pin, freq, 50)
            else:
                _core.write(pin, 1)
            if ev.wait(speed):
                break
            _core.write(pin, 0)
            ev.wait(speed)
        _core.write(pin, 0)

    _core.start_task(pin, loop)


def pins(pin=None):
    """Show how to wire the buzzer."""
    _core.show_pins("Buzzer", [
        ("+ (long leg, I/O, S)", _core.any_pin(pin)),
        ("- (GND)", _core.GND),
        ("VCC (if there are 3 contacts)", _core.V3),
    ], [
        "Active (with a sticker, sealed bottom) — beeps on 1: on/off/beep/alarm.",
        "Passive (circuit board visible underneath) — plays notes: tone/note/play/siren.",
        "A loud buzzer draws a lot of current — better drive it through a transistor (for example S8050) and a 1 kΩ resistor.",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
