#!/bin/bash
# Run it on the Raspberry Pi itself:   bash libs/pi_install/install_on_pi.sh
# Installs what the board may be missing. Everything else is already in the libs folder
# (smbus2, mfrc522, gTTS, fonts, plus Pillow and pyrf24 for a 64-bit system).
cd "$(dirname "$0")"
have() { python3 -c "import $1" 2>/dev/null; }
pip_local() { sudo pip3 install --break-system-packages "$1" 2>/dev/null || sudo pip3 install "$1"; }

MODEL=$(tr -d '\0' < /proc/device-tree/model 2>/dev/null)
echo "Board: ${MODEL:-unknown}"
echo

if have RPi.GPIO; then
  echo "[OK] RPi.GPIO"
elif echo "$MODEL" | grep -q "Raspberry Pi 5"; then
  sudo apt install -y python3-rpi-lgpio          # the old RPi.GPIO doesn't work on Pi 5, this replaces it
else
  sudo apt install -y python3-rpi.gpio || pip_local RPi.GPIO-0.7.1.tar.gz
fi

if have spidev; then echo "[OK] spidev"; else sudo apt install -y python3-spidev || pip_local spidev-3.8.tar.gz; fi
if have PIL; then echo "[OK] Pillow"; else sudo apt install -y python3-pil; fi

echo
read -p "Install programs for sound, voice and the IR remote (mpv espeak-ng v4l-utils i2c-tools)? [y/N] " a
if [ "$a" = "y" ] || [ "$a" = "Y" ]; then
  sudo apt install -y mpv espeak-ng v4l-utils i2c-tools
fi

echo
read -p "Turn on I2C and SPI (needed for screens, clock, RFID, matrix, radio)? [y/N] " b
if [ "$b" = "y" ] || [ "$b" = "Y" ]; then
  sudo raspi-config nonint do_i2c 0
  sudo raspi-config nonint do_spi 0
  echo "Done. Reboot the board: sudo reboot"
fi

echo
echo "Check: python3 ../../pi.py"
