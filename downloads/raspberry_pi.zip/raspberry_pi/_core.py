"""
Shared core for all device modules (led.py, button.py, lcd.py ...).
You don't need to import it yourself — the modules do it.

What's inside:
  * the libs/ folder is added to the path (downloaded libraries live next to the code)
  * GPIO with BCM numbering (GPIO17 = physical pin 11)
  * background tasks (blinking, watching buttons, etc.)
  * nicely printed wiring diagrams (the pins() functions in the modules)
"""
import atexit
import inspect
import os
import shutil
import sys
import threading
import time

# ---------------------------------------------------------------- libraries
HERE = os.path.dirname(os.path.abspath(__file__))
LIBS = os.path.join(HERE, "libs")
FONTS = os.path.join(LIBS, "fonts")
DATA = HERE  # modules save their files here (calibrations, remote codes, cards)

if LIBS not in sys.path:
    sys.path.insert(0, LIBS)
# Compiled libraries (Pillow, pyrf24) go to the end of the path:
# if the board already has its own version, that one is used and ours is a fallback.
_BIN = os.path.join(LIBS, "pi_binary")
if os.path.isdir(_BIN) and _BIN not in sys.path:
    sys.path.append(_BIN)
if FONTS not in sys.path:
    sys.path.append(FONTS)


# ---------------------------------------------------------------- pins
# BCM number -> physical pin number on the 40-pin header
PHYS = {
    2: 3, 3: 5, 4: 7, 17: 11, 27: 13, 22: 15, 10: 19, 9: 21, 11: 23, 0: 27,
    5: 29, 6: 31, 13: 33, 19: 35, 26: 37, 14: 8, 15: 10, 18: 12, 23: 16,
    24: 18, 25: 22, 8: 24, 7: 26, 1: 28, 12: 32, 16: 36, 20: 38, 21: 40,
}
SPECIAL = {
    2: "I2C SDA", 3: "I2C SCL", 10: "SPI MOSI", 9: "SPI MISO", 11: "SPI SCLK",
    8: "SPI CE0", 7: "SPI CE1", 14: "UART TX", 15: "UART RX",
    18: "PWM0", 12: "PWM0", 13: "PWM1", 19: "PWM1", 0: "ID_SD", 1: "ID_SC",
}

GND = "GND (any of physical pins 6, 9, 14, 20, 25, 30, 34, 39)"
V3 = "3.3V (physical pin 1 or 17)"
V5 = "5V (physical pin 2 or 4)"


def name(pin):
    """GPIO17 -> 'GPIO17 (phys. pin 11)'."""
    return "GPIO%d (phys. pin %s)" % (pin, PHYS.get(pin, "?"))


def any_pin(pin=None):
    """Text for a contact that can go to any GPIO."""
    if pin is None:
        return "ANY free GPIO"
    return "ANY GPIO  (now in the code: %s)" % name(pin)


def only_pin(pin, extra=""):
    """Text for a contact that can only go to one specific pin."""
    s = "ONLY %s" % name(pin)
    if pin in SPECIAL:
        s += " — " + SPECIAL[pin]
    if extra:
        s += ", " + extra
    return s


def show_pins(title, rows, notes=()):
    """Prints a wiring diagram: rows = [(device contact, where on the Raspberry), ...]."""
    w = max([len(r[0]) for r in rows] + [10])
    print()
    print("=" * 70)
    print("  " + title)
    print("=" * 70)
    for dev, where in rows:
        print("  %-*s  ->  %s" % (w, dev, where))
    if notes:
        print("-" * 70)
        for n in notes:
            print("  * " + n)
    print("  Pin numbers are BCM everywhere (GPIO17 = phys. pin 11). Map: pi.pinout()")
    print()


def check_pin(pin):
    if isinstance(pin, bool) or not isinstance(pin, int) or not 0 <= pin <= 27:
        raise ValueError(
            "Pin %r won't work. Use a GPIO (BCM) number from 2 to 27, for example 17.\n"
            "Pin map: import pi; pi.pinout()" % (pin,))
    return pin


# ---------------------------------------------------------------- GPIO
_gpio = None
_lock = threading.RLock()
_setup = {}  # pin -> "out" | ("in", pull)
_pwm = {}  # pin -> [PWM object, frequency, duty cycle]


def gpio():
    """The RPi.GPIO module, already set to BCM numbering."""
    global _gpio
    if _gpio is None:
        try:
            import RPi.GPIO as G
        except (ImportError, RuntimeError) as e:
            raise RuntimeError(
                "Couldn't load RPi.GPIO: %s\n"
                "This code controls hardware and only runs on a Raspberry Pi.\n"
                "If you are on the board, install the library: bash libs/pi_install/install_on_pi.sh" % e)
        G.setwarnings(False)
        mode = G.getmode()
        if mode is None:
            G.setmode(G.BCM)
        elif mode != G.BCM:
            raise RuntimeError("BOARD numbering is turned on somewhere, but these modules work in BCM. "
                               "Remove GPIO.setmode(GPIO.BOARD) from your code.")
        _gpio = G
    return _gpio


def write(pin, value):
    """Set the pin to 1 (3.3 V) or 0 (0 V)."""
    check_pin(pin)
    _stop_foreign_task(pin)
    G = gpio()
    with _lock:
        _pwm_off(pin)
        if _setup.get(pin) != "out":
            G.setup(pin, G.OUT)
            _setup[pin] = "out"
        G.output(pin, G.HIGH if value else G.LOW)


def level(pin):
    """What the output pin is set to right now (1 or 0). Works even after the program restarts."""
    check_pin(pin)
    G = gpio()
    with _lock:
        if pin in _pwm:
            return 1 if _pwm[pin][2] > 0 else 0
        if _setup.get(pin) != "out":
            G.setup(pin, G.OUT)  # without initial the pin level doesn't change
            _setup[pin] = "out"
        return G.input(pin)


def read(pin, pull="up"):
    """Read the pin as an input. pull: 'up' (pull-up to 3.3 V), 'down' (to GND) or None."""
    check_pin(pin)
    G = gpio()
    want = ("in", pull)
    with _lock:
        if _setup.get(pin) != want:
            _pwm_off(pin)
            pud = {"up": G.PUD_UP, "down": G.PUD_DOWN, None: G.PUD_OFF}[pull]
            G.setup(pin, G.IN, pull_up_down=pud)
            _setup[pin] = want
            time.sleep(0.002)
        return G.input(pin)


def make_input(pin, pull=None):
    """Switch the pin to input (for example to discharge / release the line)."""
    read(pin, pull)


def pwm(pin, freq, duty, keep=True):
    """PWM on the pin: freq — frequency (Hz), duty — duty cycle 0..100 %.
    keep=True: the program won't exit on its own while PWM runs (otherwise brightness/color would vanish at once)."""
    check_pin(pin)
    _stop_foreign_task(pin)
    G = gpio()
    duty = max(0.0, min(100.0, float(duty)))
    freq = max(0.1, float(freq))
    with _lock:
        p = _pwm.get(pin)
        if p is None:
            if _setup.get(pin) != "out":
                G.setup(pin, G.OUT)
                _setup[pin] = "out"
            obj = G.PWM(pin, freq)
            obj.start(duty)
            _pwm[pin] = [obj, freq, duty, keep]
        else:
            if p[1] != freq:
                p[0].ChangeFrequency(freq)
                p[1] = freq
            if p[2] != duty:
                p[0].ChangeDutyCycle(duty)
                p[2] = duty
            p[3] = keep


def pwm_duty(pin):
    """Current PWM duty cycle on the pin (or None if PWM is off)."""
    p = _pwm.get(pin)
    return p[2] if p else None


def pwm_stop(pin):
    """Turn PWM off on the pin (the pin becomes 0)."""
    _stop_foreign_task(pin)
    with _lock:
        _pwm_off(pin)


def _pwm_off(pin):
    p = _pwm.pop(pin, None)
    if p:
        try:
            p[0].stop()
        except Exception:
            pass
        try:
            _gpio.output(pin, _gpio.LOW)
        except Exception:
            pass


def release(pin):
    """Release the pin: stop PWM and make it an input without pull-up."""
    stop_task(pin)
    with _lock:
        _pwm_off(pin)
        if _gpio is not None:
            _gpio.setup(pin, _gpio.IN, pull_up_down=_gpio.PUD_OFF)
            _setup[pin] = ("in", None)


def rc_time(pin, timeout=1.0):
    """A "resistor + capacitor" circuit (like foto/potencyometr in the old code):
    discharge the capacitor and measure how many seconds it takes to charge up to 1.
    More resistance (darker / turned further) means a longer time."""
    check_pin(pin)
    stop_foreign(pin)
    G = gpio()
    with _lock:
        _pwm_off(pin)
        G.setup(pin, G.OUT)
        G.output(pin, G.LOW)
    time.sleep(0.05)  # discharge the capacitor
    with _lock:
        G.setup(pin, G.IN, pull_up_down=G.PUD_OFF)
        _setup[pin] = ("in", None)
    start = time.perf_counter()
    while G.input(pin) == 0:
        if time.perf_counter() - start > timeout:
            break
    return time.perf_counter() - start


# ---------------------------------------------------------------- background tasks
_tasks = {}  # key -> (thread, stop event)
_hint_shown = [False]


def start_task(key, func, *args):
    """Run func(stop_event, *args) in the background. An older task with the same key is stopped."""
    stop_task(key)
    ev = threading.Event()

    def runner():
        try:
            func(ev, *args)
        except Exception as e:  # so that an error in the background isn't silent
            print("[background task %r stopped because of an error] %s" % (key, e))

    t = threading.Thread(target=runner, name="task-%s" % (key,), daemon=True)
    _tasks[key] = (t, ev)
    t.start()
    return ev


def stop_task(key):
    """Stop a background task (blinking, watching...)."""
    item = _tasks.pop(key, None)
    if item:
        t, ev = item
        ev.set()
        if t is not threading.current_thread():
            t.join(2)


def stop_foreign(key):
    """Stop task key unless we were called from inside that very task.
    Needed so that led.on() stops blinking, while the blinking doesn't stop itself."""
    item = _tasks.get(key)
    if item and item[0] is not threading.current_thread():
        stop_task(key)


_stop_foreign_task = stop_foreign


def task_running(key):
    item = _tasks.get(key)
    return bool(item and item[0].is_alive())


def stop_all_tasks():
    for key in list(_tasks):
        stop_task(key)


def sleep(seconds, ev=None):
    """Pause. Inside a background task it ends early when the task is stopped."""
    if ev is None:
        time.sleep(seconds)
        return False
    return ev.wait(seconds)


# ---------------------------------------------------------------- waiting and watching
def wait_for(check, timeout=None, interval=0.01):
    """Wait until check() becomes True. Returns True, or False if the time ran out."""
    end = None if timeout is None else time.time() + timeout
    while not check():
        if end is not None and time.time() >= end:
            return False
        time.sleep(interval)
    return True


def watch(key, check, on_true=None, on_false=None, interval=0.01, debounce=0.03):
    """Watch check() in the background: calls on_true() when it becomes True and on_false() when it becomes False."""

    def loop(ev):
        state = bool(check())
        while not ev.is_set():
            now = bool(check())
            if now != state:
                if debounce and ev.wait(debounce):
                    return
                if bool(check()) != now:
                    continue
                state = now
                func = on_true if now else on_false
                if func:
                    try:
                        func()
                    except Exception as e:
                        print("[error in your function %s] %s" % (getattr(func, "__name__", func), e))
            ev.wait(interval)

    start_task(key, loop)


# ---------------------------------------------------------------- I2C and SPI buses
_i2c = {}
i2c_lock = threading.RLock()


def i2c(bus=1):
    """Shared I2C bus (smbus2.SMBus)."""
    if bus not in _i2c:
        from smbus2 import SMBus
        try:
            _i2c[bus] = SMBus(bus)
        except (FileNotFoundError, PermissionError) as e:
            raise RuntimeError(
                "I2C bus is not available (%s).\nTurn it on: sudo raspi-config -> Interface Options -> I2C -> Yes, "
                "then reboot the board." % e)
    return _i2c[bus]


def i2c_found(address, bus=1):
    """Is there a device with this address on the I2C bus."""
    try:
        with i2c_lock:
            i2c(bus).read_byte(address)
        return True
    except OSError:
        return False


def spi(bus=0, device=0, speed=1000000, mode=0):
    """Open SPI (spidev.SpiDev). device 0 = pin CE0 (GPIO8), 1 = CE1 (GPIO7)."""
    try:
        import spidev
    except ImportError:
        raise RuntimeError("The spidev library is missing. Install it: bash libs/pi_install/install_on_pi.sh")
    s = spidev.SpiDev()
    try:
        s.open(bus, device)
    except (FileNotFoundError, PermissionError) as e:
        raise RuntimeError(
            "SPI is not available (%s).\nTurn it on: sudo raspi-config -> Interface Options -> SPI -> Yes, "
            "then reboot the board." % e)
    s.max_speed_hz = int(speed)
    s.mode = mode
    return s


def spi_send(dev, data, chunk=4096):
    """Send many bytes over SPI in chunks (spidev allows at most 4096 bytes at a time)."""
    data = bytes(data)
    w2 = getattr(dev, "writebytes2", None)
    for i in range(0, len(data), chunk):
        part = data[i:i + chunk]
        if w2:
            w2(part)
        else:
            dev.writebytes(list(part))


# ---------------------------------------------------------------- settings files
def load_json(filename, default):
    import json
    path = os.path.join(DATA, filename)
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def save_json(filename, data):
    import json
    path = os.path.join(DATA, filename)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    return path


def has_program(prog):
    return shutil.which(prog) is not None


# ---------------------------------------------------------------- help
def show_help(modname):
    """Prints all commands of the module with short descriptions."""
    mod = sys.modules[modname]
    short = modname.rsplit(".", 1)[-1]
    doc = (mod.__doc__ or "").strip().split("\n\n")[0]
    print()
    print("=" * 70)
    for line in doc.splitlines():
        print("  " + line.strip())
    print("=" * 70)
    funcs = [f for n, f in inspect.getmembers(mod, inspect.isfunction)
             if not n.startswith("_") and f.__module__ == mod.__name__]
    funcs.sort(key=lambda f: f.__code__.co_firstlineno)
    for f in funcs:
        first = (f.__doc__ or "").strip().splitlines()
        print("  %s.%s%s" % (short, f.__name__, inspect.signature(f)))
        if first:
            print("        " + first[0])
    print()


# ---------------------------------------------------------------- program exit
def _busy():
    tasks = [str(k) for k, (t, ev) in list(_tasks.items()) if t.is_alive()]
    pwms = ["PWM on GPIO%d" % p for p, v in list(_pwm.items()) if v[3]]
    return tasks + pwms


def _at_exit():
    # The program reached its end, but something is running in the background (blinking, watching a button,
    # PWM brightness) — don't exit, wait for Ctrl+C. Otherwise everything would switch off at once.
    busy = _busy()
    crashed = hasattr(sys, "last_type") or hasattr(sys, "last_exc")
    if busy and not crashed:
        print("\nRunning in the background: %s.\nPress Ctrl+C to stop the program." % ", ".join(busy))
        try:
            while _busy():
                time.sleep(0.2)
        except KeyboardInterrupt:
            print("\nStopped.")
    stop_all_tasks()
    # PWM is switched off on exit (otherwise a buzzer could keep sounding),
    # while plain outputs stay as they are: led.on(17) stays lit after the program ends.
    with _lock:
        for pin in list(_pwm):
            _pwm_off(pin)


atexit.register(_at_exit)
