"""
Servo (SG90, MG996R, etc.).
    import servo
    servo.angle(18, 90)      # turn to 90 degrees
    servo.smooth(18, 0, 2)   # smoothly turn to 0 in 2 seconds
    servo.spin(18, 50)       # for a 360° servo: spin at 50 % speed
Wiring diagram: servo.pins()     All commands: servo.help()
"""
import time

import _core

_limits = {}   # pin -> (min pulse ms, max pulse ms, max angle)
_angles = {}   # pin -> last angle
DEFAULT = (0.5, 2.5, 180)


def setup(pin, min_ms=0.5, max_ms=2.5, max_angle=180):
    """Set up the servo: pulse length for 0° and for the max angle. If the servo doesn't reach the ends — tune it."""
    _core.check_pin(pin)
    _limits[pin] = (min_ms, max_ms, max_angle)


def _pulse(pin, ms, keep=False):
    # 50 Hz = 20 ms period. Duty cycle = pulse / 20 ms
    _core.pwm(pin, 50, ms / 20.0 * 100, keep=keep)


def angle(pin, degrees, wait=0.5):
    """Turn to the angle degrees (0..180). wait — how many seconds to give the servo to get there."""
    _core.check_pin(pin)
    lo, hi, top = _limits.get(pin, DEFAULT)
    degrees = max(0, min(top, degrees))
    _core.stop_foreign(pin)
    _pulse(pin, lo + (hi - lo) * degrees / top)
    _angles[pin] = degrees
    if wait:
        time.sleep(wait)


def get_angle(pin):
    """The last angle set (or None if it hasn't turned yet)."""
    return _angles.get(pin)


def center(pin):
    """Turn to the middle (90°)."""
    angle(pin, _limits.get(pin, DEFAULT)[2] / 2)


def left(pin):
    """Turn to the end position 0°."""
    angle(pin, 0)


def right(pin):
    """Turn to the end position 180°."""
    angle(pin, _limits.get(pin, DEFAULT)[2])


def smooth(pin, degrees, seconds=1.0):
    """Smoothly turn from the current angle to degrees over seconds seconds."""
    start = _angles.get(pin)
    if start is None:
        angle(pin, degrees)
        return
    steps = max(1, int(seconds * 50))
    for i in range(1, steps + 1):
        angle(pin, start + (degrees - start) * i / steps, wait=0)
        time.sleep(seconds / steps)
    time.sleep(0.2)


def sweep(pin, times=1, seconds=1.0):
    """Sweep 0° -> 180° -> 0° times times. seconds — time for one pass."""
    top = _limits.get(pin, DEFAULT)[2]
    if pin not in _angles:
        angle(pin, 0)
    for _ in range(times):
        smooth(pin, top, seconds)
        smooth(pin, 0, seconds)


def start_sweep(pin, seconds=1.0):
    """Sweep back and forth in the background non-stop. Stop it: servo.stop(pin)."""
    _core.check_pin(pin)
    lo, hi, top = _limits.get(pin, DEFAULT)

    def loop(ev):
        a, step = _angles.get(pin, 0), top / max(1, seconds * 50)
        while not ev.is_set():
            a += step
            if a >= top or a <= 0:
                a = max(0, min(top, a))
                step = -step
            _pulse(pin, lo + (hi - lo) * a / top, keep=True)
            _angles[pin] = a
            ev.wait(seconds / max(1, seconds * 50))

    _core.start_task(pin, loop)


def spin(pin, speed):
    """For a 360° (continuous rotation) servo: speed from -100 (backward) to 100 (forward), 0 — stop."""
    _core.check_pin(pin)
    speed = max(-100, min(100, speed))
    _core.stop_foreign(pin)
    if speed == 0:
        _pulse(pin, 1.5)
        time.sleep(0.2)
        stop(pin)
        return
    _pulse(pin, 1.5 + 0.5 * speed / 100.0, keep=True)


def stop(pin):
    """Stop sending the signal: the servo relaxes and stops jittering (a 360° servo stops)."""
    _core.stop_task(pin)
    _core.pwm_stop(pin)


def pins(pin=None):
    """Show how to wire the servo."""
    _core.show_pins("Servo", [
        ("orange/yellow (signal)", _core.any_pin(pin)),
        ("red (+)", _core.V5),
        ("brown/black (-)", _core.GND),
    ], [
        "GPIO12, 13, 18 or 19 are best — but any pin works.",
        "Power big servos (MG996R) from a separate 5-6 V supply and connect its GND to the Raspberry's GND.",
        "If the servo doesn't reach 0° or 180°: servo.setup(pin, min_ms=0.6, max_ms=2.4).",
        "Jittering at rest? Call servo.stop(pin) after turning.",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
