"""
Shared code for the DHT11 and DHT22 sensors. You don't need to import it — use dht11.py / dht22.py.

How we read:
  1) if the driver is enabled in /boot/firmware/config.txt (dtoverlay=dht11,gpiopin=4), we take the data
     from the Linux kernel — the most reliable way;
  2) otherwise we read it ourselves by bit-banging through RPi.GPIO (sometimes it glitches — then we retry).
"""
import gc
import glob
import os
import time

import _core

_cache = {}   # (model, pin) -> (time, temperature, humidity)


def _kernel_device():
    for d in glob.glob("/sys/bus/iio/devices/iio:device*"):
        try:
            with open(os.path.join(d, "name")) as f:
                if f.read().strip().startswith("dht"):
                    return d
        except OSError:
            pass
    return None


def _read_kernel(dev):
    try:
        with open(os.path.join(dev, "in_temp_input")) as f:
            t = int(f.read()) / 1000.0
        with open(os.path.join(dev, "in_humidityrelative_input")) as f:
            h = int(f.read()) / 1000.0
        return t, h
    except (OSError, ValueError):
        return None


def _collect(pin):
    G = _core.gpio()
    with _core._lock:
        G.setup(pin, G.OUT)
        G.output(pin, 1)
        time.sleep(0.05)
        G.output(pin, 0)
        time.sleep(0.02)  # start signal: 20 ms low
        gc_was = gc.isenabled()
        gc.disable()  # so the garbage collector doesn't kick in in the middle of a measurement
        try:
            G.setup(pin, G.IN, pull_up_down=G.PUD_UP)
            data = []
            unchanged, last = 0, -1
            while len(data) < 40000:
                cur = G.input(pin)
                data.append(cur)
                if cur != last:
                    unchanged, last = 0, cur
                else:
                    unchanged += 1
                    if unchanged > 1000:  # the line hasn't changed for long — the sensor is done
                        break
        finally:
            if gc_was:
                gc.enable()
        _core._setup[pin] = ("in", "up")
    return data


def _pulse_lengths(data):
    # Lengths of the "high" pulses of each of the 40 data bits
    state, lengths, cur_len = 1, [], 0
    for v in data:
        cur_len += 1
        if state == 1:      # waiting for the sensor's answer: low
            if v == 0:
                state = 2
        elif state == 2:    # sensor's answer: high
            if v == 1:
                state = 3
        elif state == 3:    # start of the first bit: low
            if v == 0:
                state = 4
        elif state == 4:    # bit: high begins
            if v == 1:
                cur_len = 0
                state = 5
        elif state == 5:    # bit: high has ended
            if v == 0:
                lengths.append(cur_len)
                state = 4
    return lengths


def _read_gpio(pin, model):
    lengths = _pulse_lengths(_collect(pin))
    if len(lengths) != 40:
        return None
    half = (min(lengths) + max(lengths)) / 2.0
    bits = [1 if n > half else 0 for n in lengths]
    b = [sum(bits[i * 8 + j] << (7 - j) for j in range(8)) for i in range(5)]
    if (b[0] + b[1] + b[2] + b[3]) & 0xFF != b[4]:
        return None
    if model == 11:
        h = b[0] + b[1] / 10.0
        t = b[2] + (b[3] & 0x7F) / 10.0
        if b[3] & 0x80:
            t = -t
    else:
        h = ((b[0] << 8) | b[1]) / 10.0
        t = (((b[2] & 0x7F) << 8) | b[3]) / 10.0
        if b[2] & 0x80:
            t = -t
    return t, h


def read(pin, model, retries=6):
    """Return (temperature °C, humidity %) or (None, None) if the sensor didn't answer."""
    _core.check_pin(pin)
    gap = 1.1 if model == 11 else 2.1   # the sensor can't be polled more often
    key = (model, pin)
    cached = _cache.get(key)
    if cached and time.time() - cached[0] < gap:
        return cached[1], cached[2]
    dev = _kernel_device()
    for attempt in range(retries):
        res = _read_kernel(dev) if dev else _read_gpio(pin, model)
        if res:
            t, h = res
            ok = (-40 <= t <= 80 and 0 <= h <= 100) if model == 22 else (-20 <= t <= 60 and 0 <= h <= 100)
            if ok:
                t, h = round(t, 1), round(h, 1)
                _cache[key] = (time.time(), t, h)
                return t, h
        time.sleep(gap if dev is None else 0.5)
    return None, None


def show(pin, model):
    t, h = read(pin, model)
    if t is None:
        print("DHT%d on GPIO%d didn't answer. Check the wiring: dht%d.pins()" % (model, pin, model))
    else:
        print("Temperature: %.1f °C   Humidity: %.1f %%" % (t, h))


def pins(pin, model):
    _core.show_pins("Temperature and humidity sensor DHT%d" % model, [
        ("+ (VCC)", _core.V3),
        ("OUT (DATA, S)", _core.any_pin(pin)),
        ("- (GND)", _core.GND),
    ], [
        "Bare sensor with 4 legs: 1 — VCC, 2 — DATA (+ 10 kΩ resistor from DATA to VCC), 3 — not used, 4 — GND.",
        "The most reliable way is the kernel driver: add this line to /boot/firmware/config.txt",
        "    dtoverlay=dht11,gpiopin=%s     (dht11 for DHT22 too), then reboot." % ("4" if pin is None else pin),
        "DHT%d can't be polled more often than once every %d s — the module waits by itself." % (model, 1 if model == 11 else 2),
    ])
