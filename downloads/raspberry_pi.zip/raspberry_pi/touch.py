"""
TTP223 touch button (button_2 in the old code).
    import touch
    if touch.is_touched(21): print("touched")
    touch.on_touch(21, lambda: led.toggle(17))
Wiring diagram: touch.pins()     All commands: touch.help()
"""
import _core
from _digital import Digital

# The TTP223 outputs 1 by itself when touched
_d = Digital("touch", active=1, pull="down")


def is_touched(pin):
    """Is the sensor being touched right now (True / False)."""
    return _d.is_on(pin)


def wait_touch(pin, timeout=None):
    """Wait for a touch. Returns True, or False (if the timeout ran out)."""
    return _d.wait(pin, True, timeout)


def wait_release(pin, timeout=None):
    """Wait until the finger is taken away."""
    return _d.wait(pin, False, timeout)


def on_touch(pin, func):
    """Call func() on every touch. func=None — stop."""
    _d.on(pin, func, True)


def on_release(pin, func):
    """Call func() when the finger is taken away."""
    _d.on(pin, func, False)


def on_hold(pin, func, seconds=1.0):
    """Call func() if the finger is held longer than seconds seconds."""
    _d.on_hold(pin, func, seconds)


def stop(pin):
    """Stop watching the sensor."""
    _d.stop(pin)


def hold_time(pin, timeout=None):
    """Wait for a touch and return how many seconds the finger was held."""
    return _d.hold_time(pin, timeout)


def clicks(pin, gap=0.4, timeout=None):
    """Wait for a series of touches and return how many (1, 2, 3...)."""
    return _d.clicks(pin, gap, timeout)


def count(pin, seconds=5):
    """How many times it was touched within seconds seconds."""
    return _d.count(pin, seconds)


def toggled(pin):
    """Touch switch: every touch flips True/False."""
    return _d.toggled(pin)


def pins(pin=None):
    """Show how to wire the touch button."""
    _core.show_pins("TTP223 touch button", [
        ("SIG (I/O, OUT)", _core.any_pin(pin)),
        ("VCC", _core.V3),
        ("GND", _core.GND),
    ], [
        "Power it from 3.3V so that 5 V never reaches the pin.",
        "If the module behaves \"the other way round\", the A/B jumper on it changes the mode.",
    ])


def help():
    """Show all commands of this module."""
    _core.show_help(__name__)
